package com.bank.ftp.parameter.entity;

import com.bank.ftp.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "param_organization")
public class Organization extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "org_code", nullable = false, unique = true, length = 50)
    private String orgCode;

    @Column(name = "org_name", nullable = false, length = 100)
    private String orgName;

    @Column(name = "org_type", length = 20)
    private String orgType;

    @Column(name = "parent_id")
    private Long parentId = 0L;

    @Column(name = "level")
    private Integer level = 1;

    @Column(name = "sort_order")
    private Integer sortOrder = 0;

    @Column(name = "status")
    private Integer status = 1;
}
