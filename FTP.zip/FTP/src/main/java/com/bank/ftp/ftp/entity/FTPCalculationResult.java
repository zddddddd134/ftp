package com.bank.ftp.ftp.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "ftp_calculation_result")
public class FTPCalculationResult implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "task_id", nullable = false)
    private Long taskId;

    @Column(name = "transaction_id", nullable = false)
    private Long transactionId;

    @Column(name = "transaction_no", nullable = false, length = 50)
    private String transactionNo;

    @Column(name = "pricing_date", nullable = false)
    private LocalDate pricingDate;

    @Column(name = "base_rate", precision = 10, scale = 6)
    private BigDecimal baseRate;

    @Column(name = "adjustment_items", columnDefinition = "TEXT")
    private String adjustmentItems;

    @Column(name = "total_adjustment", precision = 10, scale = 6)
    private BigDecimal totalAdjustment;

    @Column(name = "final_ftp_rate", nullable = false, precision = 10, scale = 6)
    private BigDecimal finalFtpRate;

    @Column(name = "ftp_cost", precision = 20, scale = 2)
    private BigDecimal ftpCost;

    @Column(name = "curve_id")
    private Long curveId;

    @Column(name = "pricing_method", length = 50)
    private String pricingMethod;

    @Column(name = "created_time", updatable = false)
    @CreationTimestamp
    private LocalDateTime createdTime;
}
