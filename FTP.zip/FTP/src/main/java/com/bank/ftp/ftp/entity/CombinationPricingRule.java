package com.bank.ftp.ftp.entity;

import com.bank.ftp.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "ftp_combination_pricing_rule")
public class CombinationPricingRule extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "rule_code", nullable = false, unique = true, length = 50)
    private String ruleCode;

    @Column(name = "rule_name", nullable = false, length = 100)
    private String ruleName;

    @Column(name = "method_rule_ids", columnDefinition = "TEXT")
    private String methodRuleIds;

    @Column(name = "curve_rule_ids", columnDefinition = "TEXT")
    private String curveRuleIds;

    @Column(name = "adjustment_rule_ids", columnDefinition = "TEXT")
    private String adjustmentRuleIds;

    @Column(name = "product_type_ids", columnDefinition = "TEXT")
    private String productTypeIds;

    @Column(name = "org_ids", columnDefinition = "TEXT")
    private String orgIds;

    @Column(name = "priority")
    private Integer priority = 0;

    @Column(name = "status")
    private Integer status = 1;
}
