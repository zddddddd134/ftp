package com.bank.ftp.ftp.service.result;

import com.bank.ftp.ftp.dto.PricingAnalysisDTO;
import com.bank.ftp.ftp.entity.FTPCalculationResult;
import com.bank.ftp.ftp.repository.FTPCalculationResultRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 结果分析服务
 */
@Service
@RequiredArgsConstructor
public class ResultAnalysisService {

    private final FTPCalculationResultRepository ftpCalculationResultRepository;

    /**
     * 生成定价分析报告
     */
    public PricingAnalysisDTO generateAnalysisReport(Long taskId) {
        List<FTPCalculationResult> results = ftpCalculationResultRepository.findByTaskId(taskId);
        return analyzeResults(results);
    }

    /**
     * 分析结果列表
     */
    public PricingAnalysisDTO analyzeResults(List<FTPCalculationResult> results) {
        PricingAnalysisDTO analysis = new PricingAnalysisDTO();
        
        if (results == null || results.isEmpty()) {
            return analysis;
        }

        // 计算总交易数量
        analysis.setTotalTransactions((long) results.size());

        // 计算总FTP金额
        BigDecimal totalFtpAmount = results.stream()
                .map(FTPCalculationResult::getFtpCost)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        analysis.setTotalFtpAmount(totalFtpAmount);

        // 计算平均FTP利率
        BigDecimal avgFtpRate = results.stream()
                .map(FTPCalculationResult::getFinalFtpRate)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(BigDecimal.valueOf(results.size()), 6, RoundingMode.HALF_UP);
        analysis.setAverageFtpRate(avgFtpRate);

        // 按产品类型分析（这里简化处理，实际应关联交易获取产品类型信息）
        // 由于FTPCalculationResult中没有直接的产品类型信息，我们按其他维度分析
        analysis.setProductAnalysis(analyzeByProduct(results));

        // 按机构分析
        analysis.setOrgAnalysis(analyzeByOrg(results));

        // 按期限分析
        analysis.setTermAnalysis(analyzeByTerm(results));

        return analysis;
    }

    /**
     * 按产品类型分析
     */
    private List<PricingAnalysisDTO.ProductAnalysisItem> analyzeByProduct(List<FTPCalculationResult> results) {
        // 由于FTPCalculationResult中没有直接的产品类型信息，这里简化处理
        // 实际实现中需要关联BusinessTransaction获取产品类型信息
        return List.of();
    }

    /**
     * 按机构分析
     */
    private List<PricingAnalysisDTO.OrgAnalysisItem> analyzeByOrg(List<FTPCalculationResult> results) {
        // 由于FTPCalculationResult中没有直接的机构信息，这里简化处理
        // 实际实现中需要关联BusinessTransaction获取机构信息
        return List.of();
    }

    /**
     * 按期限分析
     */
    private List<PricingAnalysisDTO.TermAnalysisItem> analyzeByTerm(List<FTPCalculationResult> results) {
        // 按利率区间分组分析
        Map<String, List<FTPCalculationResult>> groupedByRate = results.stream()
                .collect(Collectors.groupingBy(result -> {
                    BigDecimal rate = result.getFinalFtpRate();
                    if (rate.compareTo(BigDecimal.valueOf(0.01)) < 0) {
                        return "0-1%";
                    } else if (rate.compareTo(BigDecimal.valueOf(0.02)) < 0) {
                        return "1-2%";
                    } else if (rate.compareTo(BigDecimal.valueOf(0.03)) < 0) {
                        return "2-3%";
                    } else if (rate.compareTo(BigDecimal.valueOf(0.04)) < 0) {
                        return "3-4%";
                    } else {
                        return "4%+";
                    }
                }));

        return groupedByRate.entrySet().stream()
                .map(entry -> {
                    List<FTPCalculationResult> groupResults = entry.getValue();
                    PricingAnalysisDTO.TermAnalysisItem item = new PricingAnalysisDTO.TermAnalysisItem();
                    
                    item.setTermRange(entry.getKey()); // 使用利率区间作为期限范围标识
                    item.setCount((long) groupResults.size());
                    
                    BigDecimal totalAmount = groupResults.stream()
                            .map(FTPCalculationResult::getFtpCost)
                            .reduce(BigDecimal.ZERO, BigDecimal::add);
                    item.setTotalAmount(totalAmount);
                    
                    BigDecimal avgRate = groupResults.stream()
                            .map(FTPCalculationResult::getFinalFtpRate)
                            .reduce(BigDecimal.ZERO, BigDecimal::add)
                            .divide(BigDecimal.valueOf(groupResults.size()), 6, RoundingMode.HALF_UP);
                    item.setAvgFtpRate(avgRate);
                    
                    return item;
                })
                .collect(Collectors.toList());
    }
}