package com.bank.ftp.system.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.system.dto.SystemConfigDTO;
import com.bank.ftp.system.entity.SystemConfig;
import com.bank.ftp.system.repository.SystemConfigRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SystemConfigService {

    private final SystemConfigRepository systemConfigRepository;

    public List<SystemConfig> getAllConfigs() {
        return systemConfigRepository.findAll();
    }

    public SystemConfig getConfigById(Long id) {
        return systemConfigRepository.findById(id)
                .orElseThrow(() -> new BusinessException("系统配置不存在"));
    }

    public SystemConfig getConfigByKey(String configKey) {
        return systemConfigRepository.findByConfigKey(configKey)
                .orElseThrow(() -> new BusinessException("系统配置不存在：" + configKey));
    }

    @Transactional
    public SystemConfig createConfig(SystemConfigDTO configDTO) {
        if (systemConfigRepository.existsByConfigKey(configDTO.getConfigKey())) {
            throw new BusinessException("配置键已存在");
        }

        SystemConfig config = new SystemConfig();
        BeanUtils.copyProperties(configDTO, config);
        return systemConfigRepository.save(config);
    }

    @Transactional
    public SystemConfig updateConfig(Long id, SystemConfigDTO configDTO) {
        SystemConfig config = getConfigById(id);
        
        if (!config.getConfigKey().equals(configDTO.getConfigKey()) && 
            systemConfigRepository.existsByConfigKey(configDTO.getConfigKey())) {
            throw new BusinessException("配置键已存在");
        }

        config.setConfigValue(configDTO.getConfigValue());
        config.setConfigName(configDTO.getConfigName());
        config.setDescription(configDTO.getDescription());
        config.setConfigType(configDTO.getConfigType());
        
        return systemConfigRepository.save(config);
    }

    @Transactional
    public void deleteConfig(Long id) {
        systemConfigRepository.deleteById(id);
    }

    public String getConfigValue(String configKey, String defaultValue) {
        return systemConfigRepository.findByConfigKey(configKey)
                .map(SystemConfig::getConfigValue)
                .orElse(defaultValue);
    }
}
