package com.bank.ftp.report.repository;

import com.bank.ftp.report.entity.ReportSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReportScheduleRepository extends JpaRepository<ReportSchedule, Long> {
    List<ReportSchedule> findByReportId(Long reportId);
    List<ReportSchedule> findByStatus(Integer status);
}