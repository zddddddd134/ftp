package com.bank.ftp.ftp.entity;

import com.bank.ftp.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "ftp_rate_curve")
public class RateCurve extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "curve_code", nullable = false, unique = true, length = 50)
    private String curveCode;

    @Column(name = "curve_name", nullable = false, length = 100)
    private String curveName;

    @Column(name = "curve_type", nullable = false, length = 20)
    private String curveType;

    @Column(name = "currency_id", nullable = false)
    private Long currencyId;

    @Column(name = "description", length = 500)
    private String description;

    @Column(name = "status")
    private Integer status = 1;
}
