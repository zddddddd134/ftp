package com.bank.ftp.ftp.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * 定价分析DTO
 */
@Data
public class PricingAnalysisDTO {
    /**
     * 总交易数量
     */
    private Long totalTransactions;
    
    /**
     * 总FTP成本/收益
     */
    private BigDecimal totalFtpAmount;
    
    /**
     * 平均FTP利率
     */
    private BigDecimal averageFtpRate;
    
    /**
     * 按产品类型分析
     */
    private List<ProductAnalysisItem> productAnalysis;
    
    /**
     * 按机构分析
     */
    private List<OrgAnalysisItem> orgAnalysis;
    
    /**
     * 按期限分析
     */
    private List<TermAnalysisItem> termAnalysis;
    
    @Data
    public static class ProductAnalysisItem {
        private String productName;
        private Long count;
        private BigDecimal totalAmount;
        private BigDecimal avgFtpRate;
    }
    
    @Data
    public static class OrgAnalysisItem {
        private String orgName;
        private Long count;
        private BigDecimal totalAmount;
        private BigDecimal avgFtpRate;
    }
    
    @Data
    public static class TermAnalysisItem {
        private String termRange;
        private Long count;
        private BigDecimal totalAmount;
        private BigDecimal avgFtpRate;
    }
}