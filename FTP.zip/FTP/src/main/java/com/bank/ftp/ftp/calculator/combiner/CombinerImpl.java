package com.bank.ftp.ftp.calculator.combiner;

import com.bank.ftp.ftp.entity.BusinessTransaction;
import com.bank.ftp.ftp.entity.CombinationPricingRule;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

/**
 * 组合定价器实现
 */
@Component
@RequiredArgsConstructor
public class CombinerImpl implements Combiner {
    
    private final ObjectMapper objectMapper;

    @Override
    public BigDecimal combine(BusinessTransaction transaction, CombinationPricingRule rule) {
        // 解析规则ID列表
        List<Long> methodRuleIds = parseJsonToList(rule.getMethodRuleIds());
        List<Long> curveRuleIds = parseJsonToList(rule.getCurveRuleIds());
        List<Long> adjustmentRuleIds = parseJsonToList(rule.getAdjustmentRuleIds());

        // 这里只是示例实现，实际需要根据规则ID获取具体的规则并执行计算
        // 在完整实现中，需要从数据库获取对应的规则并应用
        
        BigDecimal baseRate = BigDecimal.ZERO; // 基准利率
        BigDecimal adjustment = BigDecimal.ZERO; // 调整项
        
        // 在实际实现中，这里会根据规则ID获取对应规则并计算
        // 例如：根据methodRuleIds获取定价方法规则并计算基础利率
        // 根据adjustmentRuleIds获取调整项规则并计算调整值
        
        // 返回组合后的最终利率
        return baseRate.add(adjustment);
    }

    private List<Long> parseJsonToList(String jsonStr) {
        if (jsonStr == null || jsonStr.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.readValue(jsonStr, new TypeReference<List<Long>>() {});
        } catch (Exception e) {
            return null;
        }
    }
}
