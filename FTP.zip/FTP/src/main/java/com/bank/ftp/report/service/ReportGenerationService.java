package com.bank.ftp.report.service;

import com.bank.ftp.ftp.entity.FTPCalculationResult;
import com.bank.ftp.ftp.service.result.FtpResultQueryService;
import com.bank.ftp.report.entity.ReportDefinition;
import com.bank.ftp.report.entity.ReportParameter;
import com.bank.ftp.report.repository.ReportParameterRepository;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 报表生成功能服务
 */
@Service
@RequiredArgsConstructor
public class ReportGenerationService {

    private final FtpResultQueryService ftpResultQueryService;
    private final ReportParameterRepository reportParameterRepository;

    /**
     * 生成FTP定价结果报表
     */
    public byte[] generateFtpPricingReport(Long taskId, Map<String, Object> parameters) throws IOException {
        // 获取计算结果
        List<FTPCalculationResult> results = ftpResultQueryService.getResultsByTaskId(taskId);

        // 创建Excel工作簿
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("FTP定价结果报表");

            // 创建标题行样式
            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);

            // 创建标题行
            Row headerRow = sheet.createRow(0);
            String[] headers = {"序号", "交易编号", "定价日期", "基础利率(%)", 
                               "总调整(%)", "最终FTP利率(%)", "FTP成本", "曲线ID", "定价方法"};
            
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // 填充数据行
            int rowNum = 1;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            
            for (int i = 0; i < results.size(); i++) {
                FTPCalculationResult result = results.get(i);
                Row row = sheet.createRow(rowNum++);
                
                row.createCell(0).setCellValue(i + 1); // 序号
                row.createCell(1).setCellValue(result.getTransactionNo());
                row.createCell(2).setCellValue(result.getPricingDate().format(formatter));
                
                Cell baseRateCell = row.createCell(3);
                if (result.getBaseRate() != null) {
                    baseRateCell.setCellValue(result.getBaseRate().multiply(BigDecimal.valueOf(100)).doubleValue()); // 转换为百分比
                }
                
                Cell totalAdjCell = row.createCell(4);
                if (result.getTotalAdjustment() != null) {
                    totalAdjCell.setCellValue(result.getTotalAdjustment().multiply(BigDecimal.valueOf(100)).doubleValue()); // 转换为百分比
                }
                
                Cell finalRateCell = row.createCell(5);
                if (result.getFinalFtpRate() != null) {
                    finalRateCell.setCellValue(result.getFinalFtpRate().multiply(BigDecimal.valueOf(100)).doubleValue()); // 转换为百分比
                }
                
                Cell ftpCostCell = row.createCell(6);
                if (result.getFtpCost() != null) {
                    ftpCostCell.setCellValue(result.getFtpCost().doubleValue());
                }
                
                if (result.getCurveId() != null) {
                    row.createCell(7).setCellValue(result.getCurveId());
                }
                
                if (result.getPricingMethod() != null) {
                    row.createCell(8).setCellValue(result.getPricingMethod());
                }
            }

            // 添加汇总行
            if (!results.isEmpty()) {
                Row summaryRow = sheet.createRow(rowNum + 1);
                summaryRow.createCell(0).setCellValue("汇总");
                summaryRow.createCell(6).setCellValue("总成本:");
                
                // 计算总成本
                BigDecimal totalCost = results.stream()
                        .map(FTPCalculationResult::getFtpCost)
                        .filter(cost -> cost != null)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
                
                Cell totalCostCell = summaryRow.createCell(7);
                totalCostCell.setCellValue(totalCost.doubleValue());
            }

            // 自动调整列宽
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // 写入字节数组
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return outputStream.toByteArray();
        }
    }

    /**
     * 生成期限匹配分析报表
     */
    public byte[] generateTenorMatchingReport(Long taskId, Map<String, Object> parameters) throws IOException {
        // 获取计算结果
        List<FTPCalculationResult> results = ftpResultQueryService.getResultsByTaskId(taskId);

        // 按期限分组分析
        Map<Integer, List<FTPCalculationResult>> groupedByTerm = results.stream()
                .collect(Collectors.groupingBy(result -> {
                    // 这里简化处理，实际应从关联的交易中获取期限
                    return 365; // 假设一年期
                }));

        // 创建Excel工作簿
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("期限匹配分析报表");

            // 创建标题行样式
            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);

            // 创建标题行
            Row headerRow = sheet.createRow(0);
            String[] headers = {"期限(天)", "交易数量", "总金额", "平均FTP利率(%)"};
            
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // 填充数据行
            int rowNum = 1;
            
            for (Map.Entry<Integer, List<FTPCalculationResult>> entry : groupedByTerm.entrySet()) {
                Integer term = entry.getKey();
                List<FTPCalculationResult> termResults = entry.getValue();
                
                Row row = sheet.createRow(rowNum++);
                
                row.createCell(0).setCellValue(term);
                row.createCell(1).setCellValue(termResults.size());
                
                // 计算总金额
                BigDecimal totalAmount = termResults.stream()
                        .map(FTPCalculationResult::getFtpCost)
                        .filter(cost -> cost != null)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
                row.createCell(2).setCellValue(totalAmount.doubleValue());
                
                // 计算平均FTP利率
                BigDecimal avgRate = termResults.stream()
                        .map(FTPCalculationResult::getFinalFtpRate)
                        .filter(rate -> rate != null)
                        .reduce(BigDecimal.ZERO, BigDecimal::add)
                        .divide(BigDecimal.valueOf(termResults.size()), 6, java.math.RoundingMode.HALF_UP);
                row.createCell(3).setCellValue(avgRate.multiply(BigDecimal.valueOf(100)).doubleValue()); // 转换为百分比
            }

            // 自动调整列宽
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // 写入字节数组
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return outputStream.toByteArray();
        }
    }

    /**
     * 根据报表定义生成报表
     */
    public byte[] generateReportByDefinition(ReportDefinition reportDef, Map<String, Object> parameters) throws IOException {
        // 根据报表定义和参数生成报表
        // 这里简化处理，实际应根据报表定义中的配置来生成报表
        
        // 获取报表参数
        List<ReportParameter> reportParams = reportParameterRepository.findByReportId(reportDef.getId());
        
        // 根据报表类型生成相应报表
        if ("ftp_pricing".equals(reportDef.getReportCode())) {
            Long taskId = parameters.containsKey("taskId") ? (Long) parameters.get("taskId") : 1L;
            return generateFtpPricingReport(taskId, parameters);
        } else if ("tenor_matching".equals(reportDef.getReportCode())) {
            Long taskId = parameters.containsKey("taskId") ? (Long) parameters.get("taskId") : 1L;
            return generateTenorMatchingReport(taskId, parameters);
        } else {
            // 默认生成FTP定价报表
            Long taskId = parameters.containsKey("taskId") ? (Long) parameters.get("taskId") : 1L;
            return generateFtpPricingReport(taskId, parameters);
        }
    }
}