package com.bank.ftp.ftp.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.ftp.entity.BusinessTransaction;
import com.bank.ftp.ftp.entity.FTPCalculationResult;
import com.bank.ftp.ftp.entity.PricingTask;
import com.bank.ftp.ftp.repository.BusinessTransactionRepository;
import com.bank.ftp.ftp.repository.FTPCalculationResultRepository;
import com.bank.ftp.ftp.repository.PricingTaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * 定价任务管理服务
 */
@Service
@RequiredArgsConstructor
public class PricingTaskService {

    private final PricingTaskRepository pricingTaskRepository;
    private final BusinessTransactionRepository businessTransactionRepository;
    private final FTPCalculationResultRepository ftpCalculationResultRepository;
    private final FtpCalculatorEngine ftpCalculatorEngine;

    /**
     * 创建定价任务
     */
    @Transactional
    public PricingTask createTask(PricingTask task) {
        if (pricingTaskRepository.existsByTaskCode(task.getTaskCode())) {
            throw new BusinessException("任务编码已存在");
        }
        task.setStatus(1); // 1-待执行
        task.setProgress(0);
        task.setStartTime(LocalDateTime.now());
        return pricingTaskRepository.save(task);
    }

    /**
     * 获取定价任务
     */
    public PricingTask getTaskById(Long id) {
        return pricingTaskRepository.findById(id)
                .orElseThrow(() -> new BusinessException("定价任务不存在"));
    }

    /**
     * 获取定价任务通过编码
     */
    public PricingTask getTaskByCode(String taskCode) {
        return pricingTaskRepository.findByTaskCode(taskCode)
                .orElseThrow(() -> new BusinessException("定价任务不存在"));
    }

    /**
     * 执行定价任务
     */
    @Transactional
    public void executeTask(Long taskId) {
        PricingTask task = getTaskById(taskId);
        task.setStatus(2); // 2-执行中
        task.setStartTime(LocalDateTime.now());
        pricingTaskRepository.save(task);

        try {
            // 获取需要定价的交易
            List<BusinessTransaction> transactions = getTransactionsForTask(task);

            // 更新任务总数
            task.setTotalCount(transactions.size());
            pricingTaskRepository.save(task);

            int successCount = 0;
            int failCount = 0;

            // 批量计算FTP价格
            for (int i = 0; i < transactions.size(); i++) {
                BusinessTransaction transaction = transactions.get(i);
                try {
                    FTPCalculationResult result = ftpCalculatorEngine.calculateFtp(transaction);
                    result.setTaskId(taskId);
                    ftpCalculationResultRepository.save(result);
                    successCount++;
                } catch (Exception e) {
                    failCount++;
                    // 记录错误信息
                    task.setErrorMessage("交易ID " + transaction.getId() + " 计算失败: " + e.getMessage());
                }

                // 更新进度
                int progress = (i + 1) * 100 / transactions.size();
                task.setProgress(progress);
                task.setSuccessCount(successCount);
                task.setFailCount(failCount);
                pricingTaskRepository.save(task);
            }

            // 完成任务
            task.setStatus(3); // 3-成功
            task.setEndTime(LocalDateTime.now());
            task.setProgress(100);
            pricingTaskRepository.save(task);

        } catch (Exception e) {
            // 任务执行失败
            task.setStatus(4); // 4-失败
            task.setEndTime(LocalDateTime.now());
            task.setErrorMessage(e.getMessage());
            pricingTaskRepository.save(task);
            throw new BusinessException("任务执行失败: " + e.getMessage());
        }
    }

    /**
     * 异步执行定价任务
     */
    public CompletableFuture<Void> executeTaskAsync(Long taskId) {
        return CompletableFuture.runAsync(() -> {
            executeTask(taskId);
        });
    }

    /**
     * 获取任务相关的交易
     */
    private List<BusinessTransaction> getTransactionsForTask(PricingTask task) {
        if (task.getTransactionIds() != null && !task.getTransactionIds().isEmpty()) {
            // 如果指定了特定交易ID，则只处理这些交易
            // 这里需要解析JSON字符串并查询特定的交易
            // 为了简化，我们暂时返回所有交易
            return businessTransactionRepository.findAll();
        } else {
            // 处理所有交易
            return businessTransactionRepository.findAll();
        }
    }

    /**
     * 获取任务结果
     */
    public List<FTPCalculationResult> getTaskResults(Long taskId) {
        return ftpCalculationResultRepository.findByTaskId(taskId);
    }

    /**
     * 取消定价任务
     */
    @Transactional
    public void cancelTask(Long taskId) {
        PricingTask task = getTaskById(taskId);
        if (task.getStatus() != 2) { // 2-执行中
            throw new BusinessException("只有运行中的任务才能被取消");
        }
        task.setStatus(5); // 5-已取消
        task.setEndTime(LocalDateTime.now());
        pricingTaskRepository.save(task);
    }
}
