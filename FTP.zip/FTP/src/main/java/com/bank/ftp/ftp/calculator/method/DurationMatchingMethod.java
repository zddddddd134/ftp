package com.bank.ftp.ftp.calculator.method;

import com.bank.ftp.ftp.entity.BusinessTransaction;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;

/**
 * 期限匹配定价方法实现
 */
@Service
public class DurationMatchingMethod implements PricingMethod {
    
    @Override
    public BigDecimal calculateFtpPrice(BusinessTransaction transaction) {
        // 期限匹配方法：根据交易的期限找到最接近的利率曲线点
        // 这里只是一个示例实现，实际实现需要结合利率曲线数据
        if (transaction.getTerm() == null) {
            // 如果没有明确的期限，可以根据起始和结束日期计算
            if (transaction.getStartDate() != null && transaction.getEndDate() != null) {
                long daysBetween = ChronoUnit.DAYS.between(transaction.getStartDate(), transaction.getEndDate());
                return BigDecimal.valueOf(daysBetween * 0.0001); // 示例计算
            }
            return BigDecimal.ZERO;
        }
        
        // 根据期限计算FTP价格，这里简化处理
        int term = transaction.getTerm();
        // 示例：每100天期限增加0.1%的FTP价格
        return BigDecimal.valueOf(term / 1000.0); // 示例计算
    }

    @Override
    public String getMethodName() {
        return "duration_matching";
    }
}
