package com.bank.ftp.ftp.service.rule;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.ftp.dto.AdjustmentRuleDTO;
import com.bank.ftp.ftp.entity.AdjustmentRule;
import com.bank.ftp.ftp.repository.AdjustmentRuleRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AdjustmentRuleService {

    private final AdjustmentRuleRepository adjustmentRuleRepository;
    private final ObjectMapper objectMapper;

    public List<AdjustmentRule> getAllRules() {
        return adjustmentRuleRepository.findAll();
    }

    public List<AdjustmentRule> getActiveRules() {
        return adjustmentRuleRepository.findByStatusOrderByPriorityDesc(1);
    }

    public AdjustmentRule getRuleById(Long id) {
        return adjustmentRuleRepository.findById(id)
                .orElseThrow(() -> new BusinessException("调整项规则不存在"));
    }

    @Transactional
    public AdjustmentRule createRule(AdjustmentRuleDTO ruleDTO) {
        if (adjustmentRuleRepository.existsByRuleCode(ruleDTO.getRuleCode())) {
            throw new BusinessException("规则编码已存在");
        }

        AdjustmentRule rule = new AdjustmentRule();
        BeanUtils.copyProperties(ruleDTO, rule);
        
        // 将List转换为JSON字符串存储
        rule.setProductTypeIds(convertListToJson(ruleDTO.getProductTypeIds()));
        rule.setOrgIds(convertListToJson(ruleDTO.getOrgIds()));
        
        return adjustmentRuleRepository.save(rule);
    }

    @Transactional
    public AdjustmentRule updateRule(Long id, AdjustmentRuleDTO ruleDTO) {
        AdjustmentRule rule = getRuleById(id);
        
        if (!rule.getRuleCode().equals(ruleDTO.getRuleCode()) && 
            adjustmentRuleRepository.existsByRuleCode(ruleDTO.getRuleCode())) {
            throw new BusinessException("规则编码已存在");
        }

        BeanUtils.copyProperties(ruleDTO, rule);
        
        // 将List转换为JSON字符串存储
        rule.setProductTypeIds(convertListToJson(ruleDTO.getProductTypeIds()));
        rule.setOrgIds(convertListToJson(ruleDTO.getOrgIds()));
        
        return adjustmentRuleRepository.save(rule);
    }

    @Transactional
    public void deleteRule(Long id) {
        AdjustmentRule rule = getRuleById(id);
        rule.setDeleted(1);
        adjustmentRuleRepository.save(rule);
    }

    private String convertListToJson(List<Long> list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(list);
        } catch (JsonProcessingException e) {
            throw new BusinessException("序列化列表失败");
        }
    }

    public List<Long> convertJsonToList(String jsonStr) {
        if (jsonStr == null || jsonStr.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.readValue(jsonStr, List.class);
        } catch (JsonProcessingException e) {
            throw new BusinessException("反序列化列表失败");
        }
    }
}
