package com.bank.ftp.report.entity;

import com.bank.ftp.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "rpt_definition")
public class ReportDefinition extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "report_code", nullable = false, unique = true, length = 50)
    private String reportCode;

    @Column(name = "report_name", nullable = false, length = 100)
    private String reportName;

    @Column(name = "description", length = 500)
    private String description;

    @Column(name = "template_id")
    private Long templateId;

    @Column(name = "data_source_config", columnDefinition = "TEXT")
    private String dataSourceConfig;

    @Column(name = "status")
    private Integer status = 1;
}