package com.bank.ftp.parameter.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.parameter.dto.CurrencyDTO;
import com.bank.ftp.parameter.entity.Currency;
import com.bank.ftp.parameter.service.CurrencyService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "币种管理", description = "币种管理相关接口")
@RestController
@RequestMapping("/parameter/currency")
@RequiredArgsConstructor
public class CurrencyController {

    private final CurrencyService currencyService;

    @Operation(summary = "获取所有币种")
    @GetMapping("/list")
    public Result<List<Currency>> getAllCurrencies() {
        return Result.success(currencyService.getAllCurrencies());
    }

    @Operation(summary = "获取启用的币种")
    @GetMapping("/active")
    public Result<List<Currency>> getActiveCurrencies() {
        return Result.success(currencyService.getActiveCurrencies());
    }

    @Operation(summary = "根据ID获取币种")
    @GetMapping("/{id}")
    public Result<Currency> getCurrencyById(@PathVariable Long id) {
        return Result.success(currencyService.getCurrencyById(id));
    }

    @Operation(summary = "获取默认币种")
    @GetMapping("/default")
    public Result<Currency> getDefaultCurrency() {
        return Result.success(currencyService.getDefaultCurrency());
    }

    @Operation(summary = "创建币种")
    @PostMapping
    public Result<Currency> createCurrency(@Valid @RequestBody CurrencyDTO currencyDTO) {
        return Result.success(currencyService.createCurrency(currencyDTO));
    }

    @Operation(summary = "更新币种")
    @PutMapping("/{id}")
    public Result<Currency> updateCurrency(@PathVariable Long id, @Valid @RequestBody CurrencyDTO currencyDTO) {
        return Result.success(currencyService.updateCurrency(id, currencyDTO));
    }

    @Operation(summary = "删除币种")
    @DeleteMapping("/{id}")
    public Result<Void> deleteCurrency(@PathVariable Long id) {
        currencyService.deleteCurrency(id);
        return Result.success();
    }

    @Operation(summary = "设置默认币种")
    @PostMapping("/{id}/set-default")
    public Result<Void> setDefaultCurrency(@PathVariable Long id) {
        currencyService.setDefaultCurrency(id);
        return Result.success();
    }
}
