package com.bank.ftp.ftp.service.result;

import com.bank.ftp.ftp.dto.PricingResultQueryDTO;
import com.bank.ftp.ftp.entity.FTPCalculationResult;
import com.bank.ftp.ftp.repository.FTPCalculationResultRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * FTP结果查询服务（增强版）
 */
@Service
@RequiredArgsConstructor
public class FtpResultQueryService {

    private final FTPCalculationResultRepository ftpCalculationResultRepository;

    /**
     * 根据查询条件获取分页结果
     */
    public org.springframework.data.domain.Page<FTPCalculationResult> getResultsByCondition(PricingResultQueryDTO query) {
        List<FTPCalculationResult> allResults = ftpCalculationResultRepository.findAll();
        
        // 应用查询条件过滤
        List<FTPCalculationResult> filteredResults = allResults.stream()
                .filter(result -> matchesQueryCondition(result, query))
                .collect(Collectors.toList());
        
        // 分页处理
        int start = query.getPage() * query.getSize();
        int end = Math.min(start + query.getSize(), filteredResults.size());
        
        if (start >= filteredResults.size()) {
            return org.springframework.data.domain.Page.empty(PageRequest.of(query.getPage(), query.getSize()));
        }
        
        List<FTPCalculationResult> pagedResults = filteredResults.subList(start, end);
        Pageable pageable = PageRequest.of(query.getPage(), query.getSize());
        return new org.springframework.data.domain.PageImpl<FTPCalculationResult>(pagedResults, pageable, filteredResults.size());
    }

    /**
     * 检查结果是否匹配查询条件
     */
    private boolean matchesQueryCondition(FTPCalculationResult result, PricingResultQueryDTO query) {
        // 检查任务ID
        if (query.getTaskId() != null && !result.getTaskId().equals(query.getTaskId())) {
            return false;
        }
        
        // 检查交易ID
        if (query.getTransactionId() != null && !result.getTransactionId().equals(query.getTransactionId())) {
            return false;
        }
        
        // 检查交易编号
        if (query.getTransactionNo() != null && !result.getTransactionNo().equals(query.getTransactionNo())) {
            return false;
        }
        
        // 检查定价日期
        if (query.getPricingDate() != null && !result.getPricingDate().equals(query.getPricingDate())) {
            return false;
        }
        
        // 检查机构ID
        // 注意：FTPCalculationResult中没有直接的机构ID字段，需要通过交易获取
        // 这里简化处理，实际实现中可能需要JOIN查询
        
        // 检查产品类型ID
        // 同样，需要通过交易获取产品类型ID
        
        return true;
    }

    /**
     * 获取所有结果
     */
    public org.springframework.data.domain.Page<FTPCalculationResult> getAllResults(int page, int size) {
        List<FTPCalculationResult> allResults = ftpCalculationResultRepository.findAll();
        
        int start = page * size;
        int end = Math.min(start + size, allResults.size());
        
        if (start >= allResults.size()) {
            return org.springframework.data.domain.Page.empty(PageRequest.of(page, size));
        }
        
        List<FTPCalculationResult> pagedResults = allResults.subList(start, end);
        Pageable pageable = PageRequest.of(page, size);
        return new org.springframework.data.domain.PageImpl<FTPCalculationResult>(pagedResults, pageable, allResults.size());
    }

    /**
     * 根据任务ID获取结果
     */
    public List<FTPCalculationResult> getResultsByTaskId(Long taskId) {
        return ftpCalculationResultRepository.findByTaskId(taskId);
    }

    /**
     * 根据交易ID获取结果
     */
    public List<FTPCalculationResult> getResultsByTransactionId(Long transactionId) {
        return ftpCalculationResultRepository.findByTransactionId(transactionId);
    }
}