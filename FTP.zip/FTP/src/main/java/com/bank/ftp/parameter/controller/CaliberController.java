package com.bank.ftp.parameter.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.parameter.dto.CaliberDTO;
import com.bank.ftp.parameter.entity.Caliber;
import com.bank.ftp.parameter.service.CaliberService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "口径管理", description = "口径管理相关接口")
@RestController
@RequestMapping("/parameter/caliber")
@RequiredArgsConstructor
public class CaliberController {

    private final CaliberService caliberService;

    @Operation(summary = "获取所有口径")
    @GetMapping("/list")
    public Result<List<Caliber>> getAllCalibers() {
        return Result.success(caliberService.getAllCalibers());
    }

    @Operation(summary = "获取启用的口径")
    @GetMapping("/active")
    public Result<List<Caliber>> getActiveCalibers() {
        return Result.success(caliberService.getActiveCalibers());
    }

    @Operation(summary = "根据ID获取口径")
    @GetMapping("/{id}")
    public Result<Caliber> getCaliberById(@PathVariable Long id) {
        return Result.success(caliberService.getCaliberById(id));
    }

    @Operation(summary = "创建口径")
    @PostMapping
    public Result<Caliber> createCaliber(@Valid @RequestBody CaliberDTO caliberDTO) {
        return Result.success(caliberService.createCaliber(caliberDTO));
    }

    @Operation(summary = "更新口径")
    @PutMapping("/{id}")
    public Result<Caliber> updateCaliber(@PathVariable Long id, @Valid @RequestBody CaliberDTO caliberDTO) {
        return Result.success(caliberService.updateCaliber(id, caliberDTO));
    }

    @Operation(summary = "删除口径")
    @DeleteMapping("/{id}")
    public Result<Void> deleteCaliber(@PathVariable Long id) {
        caliberService.deleteCaliber(id);
        return Result.success();
    }
}
