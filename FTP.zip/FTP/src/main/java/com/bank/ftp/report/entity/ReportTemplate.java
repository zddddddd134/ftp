package com.bank.ftp.report.entity;

import com.bank.ftp.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "rpt_template")
public class ReportTemplate extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "template_name", nullable = false, length = 100)
    private String templateName;

    @Column(name = "template_type", nullable = false, length = 20)
    private String templateType;

    @Lob
    @Column(name = "template_file")
    private byte[] templateFile;

    @Column(name = "file_name", length = 200)
    private String fileName;

    @Column(name = "status")
    private Integer status = 1;
}