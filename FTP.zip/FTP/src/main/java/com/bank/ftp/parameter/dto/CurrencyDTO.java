package com.bank.ftp.parameter.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CurrencyDTO {
    private Long id;

    @NotBlank(message = "币种编码不能为空")
    private String currencyCode;

    @NotBlank(message = "币种名称不能为空")
    private String currencyName;

    private String currencySymbol;

    private Integer decimalPlaces = 2;

    private Integer isDefault = 0;

    private Integer status = 1;
}
