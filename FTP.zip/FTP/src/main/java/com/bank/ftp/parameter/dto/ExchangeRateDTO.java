package com.bank.ftp.parameter.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class ExchangeRateDTO {
    private Long id;

    @NotNull(message = "源币种ID不能为空")
    private Long sourceCurrencyId;

    @NotNull(message = "目标币种ID不能为空")
    private Long targetCurrencyId;

    @NotNull(message = "汇率不能为空")
    private BigDecimal exchangeRate;

    @NotNull(message = "汇率日期不能为空")
    private LocalDate rateDate;
}
