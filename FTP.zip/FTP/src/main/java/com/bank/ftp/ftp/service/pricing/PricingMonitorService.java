package com.bank.ftp.ftp.service.pricing;

import com.bank.ftp.ftp.entity.PricingTask;
import com.bank.ftp.ftp.repository.PricingTaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 定价过程监控服务
 */
@Service
@RequiredArgsConstructor
public class PricingMonitorService {

    private final PricingTaskRepository pricingTaskRepository;

    /**
     * 获取任务监控信息
     */
    public PricingTask getTaskMonitorInfo(Long taskId) {
        return pricingTaskRepository.findById(taskId)
                .orElse(null);
    }

    /**
     * 获取所有任务的监控信息
     */
    public List<PricingTask> getAllTasksMonitorInfo() {
        return pricingTaskRepository.findAll();
    }

    /**
     * 获取指定状态的任务
     */
    public List<PricingTask> getTasksByStatus(String status) {
        // 由于JPA Repository没有直接的方法，我们获取所有任务并过滤
        return pricingTaskRepository.findAll().stream()
                .filter(task -> status.equals(String.valueOf(task.getStatus())))
                .toList();
    }

    /**
     * 获取任务进度
     */
    public Integer getTaskProgress(Long taskId) {
        PricingTask task = pricingTaskRepository.findById(taskId)
                .orElse(null);
        return task != null ? task.getProgress() : null;
    }

    /**
     * 获取任务统计信息
     */
    public TaskStatistics getTaskStatistics(Long taskId) {
        PricingTask task = pricingTaskRepository.findById(taskId)
                .orElse(null);
        
        if (task == null) {
            return null;
        }
        
        TaskStatistics stats = new TaskStatistics();
        stats.setTotalCount(task.getTotalCount());
        stats.setSuccessCount(task.getSuccessCount());
        stats.setFailCount(task.getFailCount());
        stats.setProgress(task.getProgress());
        stats.setStatus(task.getStatus());
        stats.setStartTime(task.getStartTime());
        stats.setEndTime(task.getEndTime());
        stats.setErrorMessage(task.getErrorMessage());
        
        return stats;
    }

    /**
     * 任务统计信息内部类
     */
    public static class TaskStatistics {
        private Integer totalCount;
        private Integer successCount;
        private Integer failCount;
        private Integer progress;
        private Integer status;
        private java.time.LocalDateTime startTime;
        private java.time.LocalDateTime endTime;
        private String errorMessage;

        // getters and setters
        public Integer getTotalCount() { return totalCount; }
        public void setTotalCount(Integer totalCount) { this.totalCount = totalCount; }
        
        public Integer getSuccessCount() { return successCount; }
        public void setSuccessCount(Integer successCount) { this.successCount = successCount; }
        
        public Integer getFailCount() { return failCount; }
        public void setFailCount(Integer failCount) { this.failCount = failCount; }
        
        public Integer getProgress() { return progress; }
        public void setProgress(Integer progress) { this.progress = progress; }
        
        public Integer getStatus() { return status; }
        public void setStatus(Integer status) { this.status = status; }
        
        public java.time.LocalDateTime getStartTime() { return startTime; }
        public void setStartTime(java.time.LocalDateTime startTime) { this.startTime = startTime; }
        
        public java.time.LocalDateTime getEndTime() { return endTime; }
        public void setEndTime(java.time.LocalDateTime endTime) { this.endTime = endTime; }
        
        public String getErrorMessage() { return errorMessage; }
        public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
    }
}