package com.bank.ftp.report.repository;

import com.bank.ftp.report.entity.ReportDefinition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ReportDefinitionRepository extends JpaRepository<ReportDefinition, Long> {
    Optional<ReportDefinition> findByReportCode(String reportCode);
    boolean existsByReportCode(String reportCode);
}