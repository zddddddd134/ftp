package com.bank.ftp.ftp.dto;

import lombok.Data;

import java.util.List;

/**
 * 批量定价请求DTO
 */
@Data
public class BatchPricingRequest {
    /**
     * 交易ID列表
     */
    private List<Long> transactionIds;
    
    /**
     * 任务名称
     */
    private String taskName;
    
    /**
     * 是否异步执行
     */
    private Boolean async = false;
}