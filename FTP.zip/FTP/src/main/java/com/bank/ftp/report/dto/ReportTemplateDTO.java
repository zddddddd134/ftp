package com.bank.ftp.report.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class ReportTemplateDTO {
    private Long id;

    @NotBlank(message = "模板名称不能为空")
    private String templateName;

    @NotBlank(message = "模板类型不能为空")
    private String templateType;

    private MultipartFile templateFile;

    private String fileName;

    private Integer status = 1;
}