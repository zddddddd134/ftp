package com.bank.ftp.ftp.service.rule;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.ftp.dto.CombinationPricingRuleDTO;
import com.bank.ftp.ftp.entity.CombinationPricingRule;
import com.bank.ftp.ftp.repository.CombinationPricingRuleRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CombinationPricingRuleService {

    private final CombinationPricingRuleRepository combinationPricingRuleRepository;
    private final ObjectMapper objectMapper;

    public List<CombinationPricingRule> getAllRules() {
        return combinationPricingRuleRepository.findAll();
    }

    public List<CombinationPricingRule> getActiveRules() {
        return combinationPricingRuleRepository.findByStatusOrderByPriorityDesc(1);
    }

    public CombinationPricingRule getRuleById(Long id) {
        return combinationPricingRuleRepository.findById(id)
                .orElseThrow(() -> new BusinessException("组合定价规则不存在"));
    }

    @Transactional
    public CombinationPricingRule createRule(CombinationPricingRuleDTO ruleDTO) {
        if (combinationPricingRuleRepository.existsByRuleCode(ruleDTO.getRuleCode())) {
            throw new BusinessException("规则编码已存在");
        }

        CombinationPricingRule rule = new CombinationPricingRule();
        BeanUtils.copyProperties(ruleDTO, rule);
        
        // 将List转换为JSON字符串存储
        rule.setMethodRuleIds(convertListToJson(ruleDTO.getMethodRuleIds()));
        rule.setCurveRuleIds(convertListToJson(ruleDTO.getCurveRuleIds()));
        rule.setAdjustmentRuleIds(convertListToJson(ruleDTO.getAdjustmentRuleIds()));
        rule.setProductTypeIds(convertListToJson(ruleDTO.getProductTypeIds()));
        rule.setOrgIds(convertListToJson(ruleDTO.getOrgIds()));
        
        return combinationPricingRuleRepository.save(rule);
    }

    @Transactional
    public CombinationPricingRule updateRule(Long id, CombinationPricingRuleDTO ruleDTO) {
        CombinationPricingRule rule = getRuleById(id);
        
        if (!rule.getRuleCode().equals(ruleDTO.getRuleCode()) && 
            combinationPricingRuleRepository.existsByRuleCode(ruleDTO.getRuleCode())) {
            throw new BusinessException("规则编码已存在");
        }

        BeanUtils.copyProperties(ruleDTO, rule);
        
        // 将List转换为JSON字符串存储
        rule.setMethodRuleIds(convertListToJson(ruleDTO.getMethodRuleIds()));
        rule.setCurveRuleIds(convertListToJson(ruleDTO.getCurveRuleIds()));
        rule.setAdjustmentRuleIds(convertListToJson(ruleDTO.getAdjustmentRuleIds()));
        rule.setProductTypeIds(convertListToJson(ruleDTO.getProductTypeIds()));
        rule.setOrgIds(convertListToJson(ruleDTO.getOrgIds()));
        
        return combinationPricingRuleRepository.save(rule);
    }

    @Transactional
    public void deleteRule(Long id) {
        CombinationPricingRule rule = getRuleById(id);
        rule.setDeleted(1);
        combinationPricingRuleRepository.save(rule);
    }

    private String convertListToJson(List<Long> list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(list);
        } catch (JsonProcessingException e) {
            throw new BusinessException("序列化列表失败");
        }
    }

    public List<Long> convertJsonToList(String jsonStr) {
        if (jsonStr == null || jsonStr.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.readValue(jsonStr, List.class);
        } catch (JsonProcessingException e) {
            throw new BusinessException("反序列化列表失败");
        }
    }
}
