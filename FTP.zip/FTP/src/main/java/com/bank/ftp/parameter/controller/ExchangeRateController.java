package com.bank.ftp.parameter.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.parameter.dto.ExchangeRateDTO;
import com.bank.ftp.parameter.entity.ExchangeRate;
import com.bank.ftp.parameter.service.ExchangeRateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Tag(name = "汇率管理", description = "汇率管理相关接口")
@RestController
@RequestMapping("/parameter/exchange-rate")
@RequiredArgsConstructor
public class ExchangeRateController {

    private final ExchangeRateService exchangeRateService;

    @Operation(summary = "获取所有汇率")
    @GetMapping("/list")
    public Result<List<ExchangeRate>> getAllRates() {
        return Result.success(exchangeRateService.getAllRates());
    }

    @Operation(summary = "根据日期获取汇率")
    @GetMapping("/date/{rateDate}")
    public Result<List<ExchangeRate>> getRatesByDate(
            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate rateDate) {
        return Result.success(exchangeRateService.getRatesByDate(rateDate));
    }

    @Operation(summary = "根据ID获取汇率")
    @GetMapping("/{id}")
    public Result<ExchangeRate> getRateById(@PathVariable Long id) {
        return Result.success(exchangeRateService.getRateById(id));
    }

    @Operation(summary = "根据币种和日期获取汇率")
    @GetMapping("/currency")
    public Result<ExchangeRate> getRateByCurrencyAndDate(
            @RequestParam Long sourceCurrencyId,
            @RequestParam Long targetCurrencyId,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate rateDate) {
        return exchangeRateService.getRateByCurrencyAndDate(sourceCurrencyId, targetCurrencyId, rateDate)
                .map(Result::success)
                .orElse(Result.error("汇率不存在"));
    }

    @Operation(summary = "创建汇率")
    @PostMapping
    public Result<ExchangeRate> createRate(@Valid @RequestBody ExchangeRateDTO rateDTO) {
        return Result.success(exchangeRateService.createRate(rateDTO));
    }

    @Operation(summary = "更新汇率")
    @PutMapping("/{id}")
    public Result<ExchangeRate> updateRate(@PathVariable Long id, @Valid @RequestBody ExchangeRateDTO rateDTO) {
        return Result.success(exchangeRateService.updateRate(id, rateDTO));
    }

    @Operation(summary = "删除汇率")
    @DeleteMapping("/{id}")
    public Result<Void> deleteRate(@PathVariable Long id) {
        exchangeRateService.deleteRate(id);
        return Result.success();
    }
}
