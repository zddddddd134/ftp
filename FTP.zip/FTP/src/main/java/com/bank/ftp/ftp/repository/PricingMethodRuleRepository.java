package com.bank.ftp.ftp.repository;

import com.bank.ftp.ftp.entity.PricingMethodRule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PricingMethodRuleRepository extends JpaRepository<PricingMethodRule, Long> {
    Optional<PricingMethodRule> findByRuleCode(String ruleCode);
    boolean existsByRuleCode(String ruleCode);
    List<PricingMethodRule> findByStatusOrderByPriorityDesc(Integer status);
}
