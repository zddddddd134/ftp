package com.bank.ftp.report.repository;

import com.bank.ftp.report.entity.ReportParameter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReportParameterRepository extends JpaRepository<ReportParameter, Long> {
    List<ReportParameter> findByReportId(Long reportId);
}