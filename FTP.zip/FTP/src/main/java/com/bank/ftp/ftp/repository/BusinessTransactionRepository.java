package com.bank.ftp.ftp.repository;

import com.bank.ftp.ftp.entity.BusinessTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BusinessTransactionRepository extends JpaRepository<BusinessTransaction, Long> {
    Optional<BusinessTransaction> findByTransactionNo(String transactionNo);
    boolean existsByTransactionNo(String transactionNo);
    List<BusinessTransaction> findByStatus(Integer status);
}
