package com.bank.ftp.system.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.system.dto.PasswordPolicyDTO;
import com.bank.ftp.system.entity.PasswordPolicy;
import com.bank.ftp.system.service.PasswordService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "密码策略管理", description = "密码策略管理相关接口")
@RestController
@RequestMapping("/system/password-policy")
@RequiredArgsConstructor
public class PasswordPolicyController {

    private final PasswordService passwordService;

    @Operation(summary = "获取当前激活的密码策略")
    @GetMapping("/active")
    public Result<PasswordPolicy> getActivePolicy() {
        return Result.success(passwordService.getActivePolicy());
    }

    @Operation(summary = "获取所有密码策略")
    @GetMapping("/list")
    public Result<List<PasswordPolicy>> getAllPolicies() {
        return Result.success(passwordService.getAllPolicies());
    }

    @Operation(summary = "根据ID获取密码策略")
    @GetMapping("/{id}")
    public Result<PasswordPolicy> getPolicyById(@PathVariable Long id) {
        return Result.success(passwordService.getPolicyById(id));
    }

    @Operation(summary = "创建密码策略")
    @PostMapping
    public Result<PasswordPolicy> createPolicy(@Valid @RequestBody PasswordPolicyDTO policyDTO) {
        return Result.success(passwordService.createPolicy(policyDTO));
    }

    @Operation(summary = "更新密码策略")
    @PutMapping("/{id}")
    public Result<PasswordPolicy> updatePolicy(@PathVariable Long id, @Valid @RequestBody PasswordPolicyDTO policyDTO) {
        return Result.success(passwordService.updatePolicy(id, policyDTO));
    }

    @Operation(summary = "激活密码策略")
    @PostMapping("/{id}/activate")
    public Result<Void> activatePolicy(@PathVariable Long id) {
        passwordService.activatePolicy(id);
        return Result.success();
    }

    @Operation(summary = "验证密码是否符合策略")
    @PostMapping("/validate")
    public Result<String> validatePassword(@RequestParam String password) {
        passwordService.validatePassword(password);
        return Result.success("密码符合策略要求");
    }
}
