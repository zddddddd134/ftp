package com.bank.ftp.ftp.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "ftp_transfer_pricing_record")
public class TransferPricingRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "transaction_id", nullable = false)
    private Long transactionId;

    @Column(name = "transaction_no", nullable = false, length = 50)
    private String transactionNo;

    @Column(name = "pricing_date", nullable = false)
    private LocalDate pricingDate;

    @Column(name = "org_id")
    private Long orgId;

    @Column(name = "product_type_id")
    private Long productTypeId;

    @Column(name = "amount", nullable = false, precision = 20, scale = 2)
    private BigDecimal amount;

    @Column(name = "direction", nullable = false, length = 10)
    private String direction;

    @Column(name = "ftp_rate", nullable = false, precision = 10, scale = 6)
    private BigDecimal ftpRate;

    @Column(name = "ftp_amount", precision = 20, scale = 2)
    private BigDecimal ftpAmount;

    @Column(name = "term")
    private Integer term;

    @Column(name = "created_time", updatable = false)
    @CreationTimestamp
    private LocalDateTime createdTime;
}
