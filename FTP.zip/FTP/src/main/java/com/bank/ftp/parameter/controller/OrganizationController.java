package com.bank.ftp.parameter.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.parameter.dto.OrganizationDTO;
import com.bank.ftp.parameter.entity.Organization;
import com.bank.ftp.parameter.service.OrganizationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "机构管理", description = "机构管理相关接口")
@RestController
@RequestMapping("/parameter/organization")
@RequiredArgsConstructor
public class OrganizationController {

    private final OrganizationService organizationService;

    @Operation(summary = "获取所有机构")
    @GetMapping("/list")
    public Result<List<Organization>> getAllOrganizations() {
        return Result.success(organizationService.getAllOrganizations());
    }

    @Operation(summary = "获取启用的机构")
    @GetMapping("/active")
    public Result<List<Organization>> getActiveOrganizations() {
        return Result.success(organizationService.getActiveOrganizations());
    }

    @Operation(summary = "获取机构树")
    @GetMapping("/tree")
    public Result<List<Organization>> getOrganizationTree() {
        return Result.success(organizationService.getOrganizationTree());
    }

    @Operation(summary = "根据ID获取机构")
    @GetMapping("/{id}")
    public Result<Organization> getOrganizationById(@PathVariable Long id) {
        return Result.success(organizationService.getOrganizationById(id));
    }

    @Operation(summary = "根据父级ID获取子机构")
    @GetMapping("/parent/{parentId}")
    public Result<List<Organization>> getOrganizationsByParentId(@PathVariable Long parentId) {
        return Result.success(organizationService.getOrganizationsByParentId(parentId));
    }

    @Operation(summary = "创建机构")
    @PostMapping
    public Result<Organization> createOrganization(@Valid @RequestBody OrganizationDTO orgDTO) {
        return Result.success(organizationService.createOrganization(orgDTO));
    }

    @Operation(summary = "更新机构")
    @PutMapping("/{id}")
    public Result<Organization> updateOrganization(@PathVariable Long id, @Valid @RequestBody OrganizationDTO orgDTO) {
        return Result.success(organizationService.updateOrganization(id, orgDTO));
    }

    @Operation(summary = "删除机构")
    @DeleteMapping("/{id}")
    public Result<Void> deleteOrganization(@PathVariable Long id) {
        organizationService.deleteOrganization(id);
        return Result.success();
    }
}
