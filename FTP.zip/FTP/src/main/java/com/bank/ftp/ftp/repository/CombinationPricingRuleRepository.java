package com.bank.ftp.ftp.repository;

import com.bank.ftp.ftp.entity.CombinationPricingRule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CombinationPricingRuleRepository extends JpaRepository<CombinationPricingRule, Long> {
    Optional<CombinationPricingRule> findByRuleCode(String ruleCode);
    boolean existsByRuleCode(String ruleCode);
    List<CombinationPricingRule> findByStatusOrderByPriorityDesc(Integer status);
}
