package com.bank.ftp.ftp.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.ftp.dto.PricingMethodRuleDTO;
import com.bank.ftp.ftp.entity.PricingMethodRule;
import com.bank.ftp.ftp.service.rule.PricingMethodRuleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "定价方法规则管理", description = "定价方法匹配规则相关接口")
@RestController
@RequestMapping("/ftp/rule/method")
@RequiredArgsConstructor
public class PricingMethodRuleController {

    private final PricingMethodRuleService pricingMethodRuleService;

    @Operation(summary = "获取所有定价方法规则")
    @GetMapping("/list")
    public Result<List<PricingMethodRule>> getAllRules() {
        return Result.success(pricingMethodRuleService.getAllRules());
    }

    @Operation(summary = "获取启用的定价方法规则")
    @GetMapping("/active")
    public Result<List<PricingMethodRule>> getActiveRules() {
        return Result.success(pricingMethodRuleService.getActiveRules());
    }

    @Operation(summary = "根据ID获取定价方法规则")
    @GetMapping("/{id}")
    public Result<PricingMethodRule> getRuleById(@PathVariable Long id) {
        return Result.success(pricingMethodRuleService.getRuleById(id));
    }

    @Operation(summary = "创建定价方法规则")
    @PostMapping
    public Result<PricingMethodRule> createRule(@Valid @RequestBody PricingMethodRuleDTO ruleDTO) {
        return Result.success(pricingMethodRuleService.createRule(ruleDTO));
    }

    @Operation(summary = "更新定价方法规则")
    @PutMapping("/{id}")
    public Result<PricingMethodRule> updateRule(@PathVariable Long id, @Valid @RequestBody PricingMethodRuleDTO ruleDTO) {
        return Result.success(pricingMethodRuleService.updateRule(id, ruleDTO));
    }

    @Operation(summary = "删除定价方法规则")
    @DeleteMapping("/{id}")
    public Result<Void> deleteRule(@PathVariable Long id) {
        pricingMethodRuleService.deleteRule(id);
        return Result.success();
    }
}
