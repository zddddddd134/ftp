package com.bank.ftp.config;

import com.bank.ftp.system.entity.User;
import com.bank.ftp.system.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // 检查是否存在管理员用户，如果不存在则创建
        Optional<User> adminUser = userRepository.findByUsername("admin");
        
        if (adminUser.isEmpty()) {
            User defaultAdmin = new User();
            defaultAdmin.setUsername("admin");
            defaultAdmin.setPassword(passwordEncoder.encode("admin123")); // 初始密码为admin123
            defaultAdmin.setRealName("管理员");
            defaultAdmin.setEmail("admin@example.com");
            defaultAdmin.setPhone("13800138000");
            defaultAdmin.setStatus(1);
            
            userRepository.save(defaultAdmin);
            log.info("默认管理员账户已创建: 用户名=admin, 密码=admin123");
        } else {
            log.info("管理员账户已存在，跳过初始化");
        }
    }
}