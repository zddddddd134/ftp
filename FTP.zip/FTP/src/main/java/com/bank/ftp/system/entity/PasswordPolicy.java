package com.bank.ftp.system.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "sys_password_policy")
public class PasswordPolicy implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "policy_name", nullable = false, length = 50)
    private String policyName;

    @Column(name = "min_length")
    private Integer minLength = 8;

    @Column(name = "max_length")
    private Integer maxLength = 20;

    @Column(name = "require_upper")
    private Integer requireUpper = 1;

    @Column(name = "require_lower")
    private Integer requireLower = 1;

    @Column(name = "require_digit")
    private Integer requireDigit = 1;

    @Column(name = "require_special")
    private Integer requireSpecial = 0;

    @Column(name = "password_expire_days")
    private Integer passwordExpireDays = 90;

    @Column(name = "password_history_count")
    private Integer passwordHistoryCount = 5;

    @Column(name = "status")
    private Integer status = 1;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_time", updatable = false)
    @CreationTimestamp
    private LocalDateTime createdTime;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_time")
    @UpdateTimestamp
    private LocalDateTime updatedTime;
}
