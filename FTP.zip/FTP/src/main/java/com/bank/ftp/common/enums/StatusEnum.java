package com.bank.ftp.common.enums;

/**
 * 状态枚举
 */
public enum StatusEnum {
    // 通用状态
    ACTIVE(1, "启用"),
    INACTIVE(0, "禁用"),
    
    // 任务状态
    PENDING("pending", "待执行"),
    RUNNING("running", "执行中"),
    SUCCESS("success", "成功"),
    FAILED("failed", "失败"),
    CANCELLED("cancelled", "已取消"),
    
    // 交易状态
    NORMAL("normal", "正常"),
    OVERDUE("overdue", "逾期");

    private final Object value;
    private final String description;

    StatusEnum(Object value, String description) {
        this.value = value;
        this.description = description;
    }

    public Object getValue() {
        return value;
    }

    public String getDescription() {
        return description;
    }

    public static StatusEnum fromValue(Object value) {
        for (StatusEnum status : values()) {
            if (status.value.equals(value)) {
                return status;
            }
        }
        return null;
    }
}