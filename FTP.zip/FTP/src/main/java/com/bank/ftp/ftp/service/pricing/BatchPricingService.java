package com.bank.ftp.ftp.service.pricing;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.ftp.dto.BatchPricingRequest;
import com.bank.ftp.ftp.entity.BusinessTransaction;
import com.bank.ftp.ftp.entity.FTPCalculationResult;
import com.bank.ftp.ftp.entity.PricingTask;
import com.bank.ftp.ftp.repository.BusinessTransactionRepository;
import com.bank.ftp.ftp.repository.FTPCalculationResultRepository;
import com.bank.ftp.ftp.service.FtpCalculatorEngine;
import com.bank.ftp.ftp.service.PricingTaskService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * 批量定价服务
 */
@Service
@RequiredArgsConstructor
public class BatchPricingService {

    private final BusinessTransactionRepository businessTransactionRepository;
    private final FTPCalculationResultRepository ftpCalculationResultRepository;
    private final FtpCalculatorEngine ftpCalculatorEngine;
    private final PricingTaskService pricingTaskService;

    /**
     * 执行批量定价
     */
    @Transactional
    public PricingTask executeBatchPricing(BatchPricingRequest request) {
        // 创建定价任务
        PricingTask task = new PricingTask();
        task.setTaskCode("TASK_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0, 8));
        task.setTaskName(request.getTaskName() != null ? request.getTaskName() : "批量定价任务");
        task.setTaskType("batch");
        task.setPricingDate(LocalDateTime.now());
        task.setStatus(1); // 1-待执行
        task.setCreatedBy(1L); // TODO: 从当前用户获取
        task.setTotalCount(request.getTransactionIds().size());

        PricingTask savedTask = pricingTaskService.createTask(task);

        // 根据是否异步执行决定处理方式
        if (Boolean.TRUE.equals(request.getAsync())) {
            // 异步执行
            CompletableFuture.runAsync(() -> processBatchPricing(savedTask.getId(), request.getTransactionIds()));
            return savedTask;
        } else {
            // 同步执行
            processBatchPricing(savedTask.getId(), request.getTransactionIds());
            return savedTask;
        }
    }

    /**
     * 处理批量定价的具体逻辑
     */
    private void processBatchPricing(Long taskId, List<Long> transactionIds) {
        try {
            // 更新任务状态为运行中
            PricingTask task = pricingTaskService.getTaskById(taskId);
            task.setStatus(2); // 2-执行中
            task.setStartTime(LocalDateTime.now());
            pricingTaskService.createTask(task);

            int total = transactionIds.size();
            int processed = 0;
            int successCount = 0;
            int failCount = 0;

            for (Long transactionId : transactionIds) {
                try {
                    // 获取交易
                    BusinessTransaction transaction = businessTransactionRepository.findById(transactionId)
                            .orElseThrow(() -> new BusinessException("交易不存在: " + transactionId));

                    // 计算FTP价格
                    FTPCalculationResult result = ftpCalculatorEngine.calculateFtp(transaction);
                    result.setTaskId(taskId);
                    
                    // 保存计算结果
                    ftpCalculationResultRepository.save(result);
                    
                    successCount++;
                } catch (Exception e) {
                    failCount++;
                    // 记录错误信息
                    PricingTask currentTask = pricingTaskService.getTaskById(taskId);
                    currentTask.setErrorMessage("交易ID " + transactionId + " 计算失败: " + e.getMessage());
                    pricingTaskService.createTask(currentTask);
                }

                processed++;
                
                // 更新进度
                int progress = (processed * 100) / total;
                PricingTask currentTask = pricingTaskService.getTaskById(taskId);
                currentTask.setProgress(progress);
                currentTask.setSuccessCount(successCount);
                currentTask.setFailCount(failCount);
                pricingTaskService.createTask(currentTask);
            }

            // 完成任务
            PricingTask finalTask = pricingTaskService.getTaskById(taskId);
            finalTask.setStatus(3); // 3-成功
            finalTask.setEndTime(LocalDateTime.now());
            finalTask.setProgress(100);
            pricingTaskService.createTask(finalTask);

        } catch (Exception e) {
            // 任务执行失败
            PricingTask failedTask = pricingTaskService.getTaskById(taskId);
            failedTask.setStatus(4); // 4-失败
            failedTask.setEndTime(LocalDateTime.now());
            failedTask.setErrorMessage(e.getMessage());
            pricingTaskService.createTask(failedTask);
            throw new BusinessException("批量定价任务执行失败: " + e.getMessage());
        }
    }

    /**
     * 根据交易ID列表执行批量定价（简化版）
     */
    public PricingTask executeBatchPricingByTransactionIds(List<Long> transactionIds, String taskName) {
        BatchPricingRequest request = new BatchPricingRequest();
        request.setTransactionIds(transactionIds);
        request.setTaskName(taskName);
        request.setAsync(false); // 默认同步执行
        
        return executeBatchPricing(request);
    }
}