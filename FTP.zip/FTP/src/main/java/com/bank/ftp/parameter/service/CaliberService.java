package com.bank.ftp.parameter.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.parameter.dto.CaliberDTO;
import com.bank.ftp.parameter.entity.Caliber;
import com.bank.ftp.parameter.repository.CaliberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CaliberService {

    private final CaliberRepository caliberRepository;

    public List<Caliber> getAllCalibers() {
        return caliberRepository.findAll();
    }

    public List<Caliber> getActiveCalibers() {
        return caliberRepository.findByStatus(1);
    }

    public Caliber getCaliberById(Long id) {
        return caliberRepository.findById(id)
                .orElseThrow(() -> new BusinessException("口径不存在"));
    }

    @Transactional
    public Caliber createCaliber(CaliberDTO caliberDTO) {
        if (caliberRepository.existsByCaliberCode(caliberDTO.getCaliberCode())) {
            throw new BusinessException("口径编码已存在");
        }

        Caliber caliber = new Caliber();
        BeanUtils.copyProperties(caliberDTO, caliber);
        return caliberRepository.save(caliber);
    }

    @Transactional
    public Caliber updateCaliber(Long id, CaliberDTO caliberDTO) {
        Caliber caliber = getCaliberById(id);
        
        if (!caliber.getCaliberCode().equals(caliberDTO.getCaliberCode()) && 
            caliberRepository.existsByCaliberCode(caliberDTO.getCaliberCode())) {
            throw new BusinessException("口径编码已存在");
        }

        caliber.setCaliberName(caliberDTO.getCaliberName());
        caliber.setDescription(caliberDTO.getDescription());
        caliber.setCaliberRule(caliberDTO.getCaliberRule());
        caliber.setStatus(caliberDTO.getStatus());
        
        return caliberRepository.save(caliber);
    }

    @Transactional
    public void deleteCaliber(Long id) {
        Caliber caliber = getCaliberById(id);
        caliber.setDeleted(1);
        caliberRepository.save(caliber);
    }
}
