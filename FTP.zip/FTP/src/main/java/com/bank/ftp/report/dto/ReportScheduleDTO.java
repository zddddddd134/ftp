package com.bank.ftp.report.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ReportScheduleDTO {
    private Long id;

    @NotNull(message = "报表ID不能为空")
    private Long reportId;

    @NotBlank(message = "调度名称不能为空")
    private String scheduleName;

    @NotBlank(message = "Cron表达式不能为空")
    private String cronExpression;

    private String paramValues;

    private String outputFormat = "excel";

    private String emailRecipients;

    private Integer status = 1;
}