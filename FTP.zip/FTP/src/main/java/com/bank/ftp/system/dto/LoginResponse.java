package com.bank.ftp.system.dto;

import lombok.Data;

@Data
public class LoginResponse {
    private String token;
    private String tokenType = "Bearer";
    private Long expiresIn;
    private String username;
    private String realName;

    public LoginResponse(String token, Long expiresIn, String username, String realName) {
        this.token = token;
        this.expiresIn = expiresIn;
        this.username = username;
        this.realName = realName;
    }
}