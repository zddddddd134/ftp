package com.bank.ftp.ftp.service.rule;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.ftp.dto.PricingMethodRuleDTO;
import com.bank.ftp.ftp.entity.PricingMethodRule;
import com.bank.ftp.ftp.repository.PricingMethodRuleRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PricingMethodRuleService {

    private final PricingMethodRuleRepository pricingMethodRuleRepository;
    private final ObjectMapper objectMapper;

    public List<PricingMethodRule> getAllRules() {
        return pricingMethodRuleRepository.findAll();
    }

    public List<PricingMethodRule> getActiveRules() {
        return pricingMethodRuleRepository.findByStatusOrderByPriorityDesc(1);
    }

    public PricingMethodRule getRuleById(Long id) {
        return pricingMethodRuleRepository.findById(id)
                .orElseThrow(() -> new BusinessException("定价方法规则不存在"));
    }

    @Transactional
    public PricingMethodRule createRule(PricingMethodRuleDTO ruleDTO) {
        if (pricingMethodRuleRepository.existsByRuleCode(ruleDTO.getRuleCode())) {
            throw new BusinessException("规则编码已存在");
        }

        PricingMethodRule rule = new PricingMethodRule();
        BeanUtils.copyProperties(ruleDTO, rule);
        
        // 将List转换为JSON字符串存储
        rule.setProductTypeIds(convertListToJson(ruleDTO.getProductTypeIds()));
        rule.setOrgIds(convertListToJson(ruleDTO.getOrgIds()));
        
        return pricingMethodRuleRepository.save(rule);
    }

    @Transactional
    public PricingMethodRule updateRule(Long id, PricingMethodRuleDTO ruleDTO) {
        PricingMethodRule rule = getRuleById(id);
        
        if (!rule.getRuleCode().equals(ruleDTO.getRuleCode()) && 
            pricingMethodRuleRepository.existsByRuleCode(ruleDTO.getRuleCode())) {
            throw new BusinessException("规则编码已存在");
        }

        BeanUtils.copyProperties(ruleDTO, rule);
        
        // 将List转换为JSON字符串存储
        rule.setProductTypeIds(convertListToJson(ruleDTO.getProductTypeIds()));
        rule.setOrgIds(convertListToJson(ruleDTO.getOrgIds()));
        
        return pricingMethodRuleRepository.save(rule);
    }

    @Transactional
    public void deleteRule(Long id) {
        PricingMethodRule rule = getRuleById(id);
        rule.setDeleted(1);
        pricingMethodRuleRepository.save(rule);
    }

    private String convertListToJson(List<Long> list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(list);
        } catch (JsonProcessingException e) {
            throw new BusinessException("序列化列表失败");
        }
    }

    public List<Long> convertJsonToList(String jsonStr) {
        if (jsonStr == null || jsonStr.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.readValue(jsonStr, List.class);
        } catch (JsonProcessingException e) {
            throw new BusinessException("反序列化列表失败");
        }
    }
}
