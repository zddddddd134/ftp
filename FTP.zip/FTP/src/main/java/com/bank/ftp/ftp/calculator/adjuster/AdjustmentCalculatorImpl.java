package com.bank.ftp.ftp.calculator.adjuster;

import com.bank.ftp.ftp.entity.BusinessTransaction;
import com.bank.ftp.ftp.entity.AdjustmentRule;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/**
 * 调整项计算器实现
 */
@Component
@RequiredArgsConstructor
public class AdjustmentCalculatorImpl implements AdjustmentCalculator {

    @Override
    public BigDecimal calculateAdjustment(BusinessTransaction transaction, List<AdjustmentRule> rules) {
        BigDecimal totalAdjustment = BigDecimal.ZERO;
        
        for (AdjustmentRule rule : rules) {
            BigDecimal adjustment = calculateSingleAdjustment(transaction, rule);
            
            if ("multiply".equalsIgnoreCase(rule.getAdjustmentMode())) {
                totalAdjustment = totalAdjustment.multiply(BigDecimal.ONE.add(adjustment));
            } else {
                // 默认为加法模式
                totalAdjustment = totalAdjustment.add(adjustment);
            }
        }
        
        return totalAdjustment;
    }

    @Override
    public BigDecimal calculateSingleAdjustment(BusinessTransaction transaction, AdjustmentRule rule) {
        // 根据调整类型进行不同的计算
        String adjustmentType = rule.getAdjustmentType();
        
        switch (adjustmentType.toLowerCase()) {
            case "liquidity":
                // 流动性调整
                return calculateLiquidityAdjustment(transaction, rule);
            case "credit":
                // 信用调整
                return calculateCreditAdjustment(transaction, rule);
            case "option":
                // 期权调整
                return calculateOptionAdjustment(transaction, rule);
            default:
                // 默认直接返回规则中的调整值
                return rule.getAdjustmentValue();
        }
    }

    /**
     * 计算流动性调整
     */
    private BigDecimal calculateLiquidityAdjustment(BusinessTransaction transaction, AdjustmentRule rule) {
        // 流动性调整可能基于期限等因素
        if (transaction.getTerm() != null) {
            // 示例：期限越长，流动性调整越大
            return rule.getAdjustmentValue().multiply(
                BigDecimal.valueOf(Math.min(1.0, transaction.getTerm() / 3650.0)) // 最多10年
            );
        }
        return rule.getAdjustmentValue();
    }

    /**
     * 计算信用调整
     */
    private BigDecimal calculateCreditAdjustment(BusinessTransaction transaction, AdjustmentRule rule) {
        // 信用调整可能基于客户评级等因素
        // 这里简化处理，直接返回规则中的调整值
        return rule.getAdjustmentValue();
    }

    /**
     * 计算期权调整
     */
    private BigDecimal calculateOptionAdjustment(BusinessTransaction transaction, AdjustmentRule rule) {
        // 期权调整可能基于提前还款选项等因素
        // 这里简化处理，直接返回规则中的调整值
        return rule.getAdjustmentValue();
    }
}
