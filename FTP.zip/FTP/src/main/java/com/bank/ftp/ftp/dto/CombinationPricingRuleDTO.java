package com.bank.ftp.ftp.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

@Data
public class CombinationPricingRuleDTO {
    private Long id;

    @NotBlank(message = "规则编码不能为空")
    private String ruleCode;

    @NotBlank(message = "规则名称不能为空")
    private String ruleName;

    private List<Long> methodRuleIds;

    private List<Long> curveRuleIds;

    private List<Long> adjustmentRuleIds;

    private List<Long> productTypeIds;

    private List<Long> orgIds;

    private Integer priority = 0;

    private Integer status = 1;
}
