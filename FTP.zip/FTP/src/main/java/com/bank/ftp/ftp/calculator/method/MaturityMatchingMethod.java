package com.bank.ftp.ftp.calculator.method;

import com.bank.ftp.ftp.entity.BusinessTransaction;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * 到期日匹配定价方法实现
 */
@Service
public class MaturityMatchingMethod implements PricingMethod {
    
    @Override
    public BigDecimal calculateFtpPrice(BusinessTransaction transaction) {
        // 到期日匹配方法：根据到期日确定FTP价格
        // 这里只是一个示例实现
        if (transaction.getEndDate() != null) {
            // 根据到期日计算，这里简化处理
            return BigDecimal.valueOf(0.03); // 示例：固定3%的FTP价格
        }
        return BigDecimal.ZERO;
    }

    @Override
    public String getMethodName() {
        return "maturity_matching";
    }
}
