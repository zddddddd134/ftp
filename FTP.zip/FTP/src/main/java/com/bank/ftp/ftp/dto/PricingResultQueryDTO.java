package com.bank.ftp.ftp.dto;

import lombok.Data;

import java.time.LocalDate;

/**
 * 定价结果查询DTO
 */
@Data
public class PricingResultQueryDTO {
    /**
     * 任务ID
     */
    private Long taskId;
    
    /**
     * 交易ID
     */
    private Long transactionId;
    
    /**
     * 交易编号
     */
    private String transactionNo;
    
    /**
     * 定价日期
     */
    private LocalDate pricingDate;
    
    /**
     * 机构ID
     */
    private Long orgId;
    
    /**
     * 产品类型ID
     */
    private Long productTypeId;
    
    /**
     * 页码
     */
    private Integer page = 0;
    
    /**
     * 每页大小
     */
    private Integer size = 10;
}