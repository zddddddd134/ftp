package com.bank.ftp.system.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.system.dto.SystemConfigDTO;
import com.bank.ftp.system.entity.SystemConfig;
import com.bank.ftp.system.service.SystemConfigService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "系统配置管理", description = "系统配置管理相关接口")
@RestController
@RequestMapping("/system/config")
@RequiredArgsConstructor
public class SystemConfigController {

    private final SystemConfigService systemConfigService;

    @Operation(summary = "获取所有系统配置")
    @GetMapping("/list")
    public Result<List<SystemConfig>> getAllConfigs() {
        return Result.success(systemConfigService.getAllConfigs());
    }

    @Operation(summary = "根据ID获取系统配置")
    @GetMapping("/{id}")
    public Result<SystemConfig> getConfigById(@PathVariable Long id) {
        return Result.success(systemConfigService.getConfigById(id));
    }

    @Operation(summary = "根据配置键获取系统配置")
    @GetMapping("/key/{configKey}")
    public Result<SystemConfig> getConfigByKey(@PathVariable String configKey) {
        return Result.success(systemConfigService.getConfigByKey(configKey));
    }

    @Operation(summary = "创建系统配置")
    @PostMapping
    public Result<SystemConfig> createConfig(@Valid @RequestBody SystemConfigDTO configDTO) {
        return Result.success(systemConfigService.createConfig(configDTO));
    }

    @Operation(summary = "更新系统配置")
    @PutMapping("/{id}")
    public Result<SystemConfig> updateConfig(@PathVariable Long id, @Valid @RequestBody SystemConfigDTO configDTO) {
        return Result.success(systemConfigService.updateConfig(id, configDTO));
    }

    @Operation(summary = "删除系统配置")
    @DeleteMapping("/{id}")
    public Result<Void> deleteConfig(@PathVariable Long id) {
        systemConfigService.deleteConfig(id);
        return Result.success();
    }
}
