package com.bank.ftp.ftp.calculator.method;

import com.bank.ftp.ftp.entity.BusinessTransaction;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * 资金池定价方法实现
 */
@Service
public class PoolMethod implements PricingMethod {
    
    @Override
    public BigDecimal calculateFtpPrice(BusinessTransaction transaction) {
        // 资金池方法：不考虑具体期限，使用平均成本
        // 这里只是一个示例实现
        return BigDecimal.valueOf(0.025); // 示例：固定2.5%的FTP价格
    }

    @Override
    public String getMethodName() {
        return "pool";
    }
}
