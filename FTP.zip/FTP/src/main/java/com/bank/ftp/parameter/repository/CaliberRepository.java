package com.bank.ftp.parameter.repository;

import com.bank.ftp.parameter.entity.Caliber;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CaliberRepository extends JpaRepository<Caliber, Long> {
    Optional<Caliber> findByCaliberCode(String caliberCode);
    boolean existsByCaliberCode(String caliberCode);
    List<Caliber> findByStatus(Integer status);
}
