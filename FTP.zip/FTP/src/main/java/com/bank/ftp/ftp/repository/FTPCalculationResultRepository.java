package com.bank.ftp.ftp.repository;

import com.bank.ftp.ftp.entity.FTPCalculationResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FTPCalculationResultRepository extends JpaRepository<FTPCalculationResult, Long> {
    List<FTPCalculationResult> findByTaskId(Long taskId);
    List<FTPCalculationResult> findByTransactionId(Long transactionId);
}
