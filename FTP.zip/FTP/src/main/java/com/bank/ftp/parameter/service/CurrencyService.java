package com.bank.ftp.parameter.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.parameter.dto.CurrencyDTO;
import com.bank.ftp.parameter.entity.Currency;
import com.bank.ftp.parameter.repository.CurrencyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CurrencyService {

    private final CurrencyRepository currencyRepository;

    public List<Currency> getAllCurrencies() {
        return currencyRepository.findAll();
    }

    public List<Currency> getActiveCurrencies() {
        return currencyRepository.findByStatus(1);
    }

    public Currency getCurrencyById(Long id) {
        return currencyRepository.findById(id)
                .orElseThrow(() -> new BusinessException("币种不存在"));
    }

    public Currency getDefaultCurrency() {
        return currencyRepository.findByIsDefault(1)
                .orElseGet(() -> getActiveCurrencies().stream().findFirst().orElse(null));
    }

    @Transactional
    public Currency createCurrency(CurrencyDTO currencyDTO) {
        if (currencyRepository.existsByCurrencyCode(currencyDTO.getCurrencyCode())) {
            throw new BusinessException("币种编码已存在");
        }

        Currency currency = new Currency();
        BeanUtils.copyProperties(currencyDTO, currency);
        
        if (currencyDTO.getIsDefault() == 1) {
            unsetDefaultCurrency();
        }
        
        return currencyRepository.save(currency);
    }

    @Transactional
    public Currency updateCurrency(Long id, CurrencyDTO currencyDTO) {
        Currency currency = getCurrencyById(id);
        
        if (!currency.getCurrencyCode().equals(currencyDTO.getCurrencyCode()) && 
            currencyRepository.existsByCurrencyCode(currencyDTO.getCurrencyCode())) {
            throw new BusinessException("币种编码已存在");
        }

        currency.setCurrencyName(currencyDTO.getCurrencyName());
        currency.setCurrencySymbol(currencyDTO.getCurrencySymbol());
        currency.setDecimalPlaces(currencyDTO.getDecimalPlaces());
        currency.setStatus(currencyDTO.getStatus());
        
        if (currencyDTO.getIsDefault() == 1 && currency.getIsDefault() != 1) {
            unsetDefaultCurrency();
            currency.setIsDefault(1);
        } else if (currencyDTO.getIsDefault() == 0) {
            currency.setIsDefault(0);
        }
        
        return currencyRepository.save(currency);
    }

    @Transactional
    public void deleteCurrency(Long id) {
        Currency currency = getCurrencyById(id);
        currency.setDeleted(1);
        currencyRepository.save(currency);
    }

    @Transactional
    public void setDefaultCurrency(Long id) {
        unsetDefaultCurrency();
        Currency currency = getCurrencyById(id);
        currency.setIsDefault(1);
        currencyRepository.save(currency);
    }

    private void unsetDefaultCurrency() {
        List<Currency> currencies = currencyRepository.findAll();
        for (Currency c : currencies) {
            if (c.getIsDefault() == 1) {
                c.setIsDefault(0);
                currencyRepository.save(c);
            }
        }
    }
}
