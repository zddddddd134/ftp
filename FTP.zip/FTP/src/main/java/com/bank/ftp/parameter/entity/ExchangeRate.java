package com.bank.ftp.parameter.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "param_exchange_rate")
public class ExchangeRate implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "source_currency_id", nullable = false)
    private Long sourceCurrencyId;

    @Column(name = "target_currency_id", nullable = false)
    private Long targetCurrencyId;

    @Column(name = "exchange_rate", nullable = false, precision = 20, scale = 8)
    private BigDecimal exchangeRate;

    @Column(name = "rate_date", nullable = false)
    private LocalDate rateDate;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_time", updatable = false)
    @CreationTimestamp
    private LocalDateTime createdTime;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_time")
    @UpdateTimestamp
    private LocalDateTime updatedTime;
}
