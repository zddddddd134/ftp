package com.bank.ftp.ftp.repository;

import com.bank.ftp.ftp.entity.RateCurvePoint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RateCurvePointRepository extends JpaRepository<RateCurvePoint, Long> {
    List<RateCurvePoint> findByCurveIdOrderByTermAsc(Long curveId);
    void deleteByCurveId(Long curveId);
}
