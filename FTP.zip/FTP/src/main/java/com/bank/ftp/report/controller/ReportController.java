package com.bank.ftp.report.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.report.dto.*;
import com.bank.ftp.report.entity.ReportDefinition;
import com.bank.ftp.report.entity.ReportParameter;
import com.bank.ftp.report.entity.ReportSchedule;
import com.bank.ftp.report.entity.ReportTemplate;
import com.bank.ftp.report.service.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@Tag(name = "报表管理", description = "报表集成相关接口")
@RestController
@RequestMapping("/report")
@RequiredArgsConstructor
public class ReportController {

    private final ReportDefinitionService reportDefinitionService;
    private final ReportParameterService reportParameterService;
    private final ReportTemplateService reportTemplateService;
    private final ReportScheduleService reportScheduleService;
    private final ReportGenerationService reportGenerationService;

    // 报表定义相关接口
    @Operation(summary = "获取所有报表定义")
    @GetMapping("/definition/list")
    public Result<List<ReportDefinition>> getAllReports() {
        return Result.success(reportDefinitionService.getAllReports());
    }

    @Operation(summary = "根据ID获取报表定义")
    @GetMapping("/definition/{id}")
    public Result<ReportDefinition> getReportById(@PathVariable Long id) {
        return Result.success(reportDefinitionService.getReportById(id));
    }

    @Operation(summary = "根据编码获取报表定义")
    @GetMapping("/definition/code/{reportCode}")
    public Result<ReportDefinition> getReportByCode(@PathVariable String reportCode) {
        return Result.success(reportDefinitionService.getReportByCode(reportCode));
    }

    @Operation(summary = "创建报表定义")
    @PostMapping("/definition")
    public Result<ReportDefinition> createReport(@Valid @RequestBody ReportDefinitionDTO reportDTO) {
        return Result.success(reportDefinitionService.createReport(reportDTO));
    }

    @Operation(summary = "更新报表定义")
    @PutMapping("/definition/{id}")
    public Result<ReportDefinition> updateReport(@PathVariable Long id, @Valid @RequestBody ReportDefinitionDTO reportDTO) {
        return Result.success(reportDefinitionService.updateReport(id, reportDTO));
    }

    @Operation(summary = "删除报表定义")
    @DeleteMapping("/definition/{id}")
    public Result<Void> deleteReport(@PathVariable Long id) {
        reportDefinitionService.deleteReport(id);
        return Result.success();
    }

    // 报表参数相关接口
    @Operation(summary = "根据报表ID获取参数列表")
    @GetMapping("/parameter/report/{reportId}")
    public Result<List<ReportParameter>> getParametersByReportId(@PathVariable Long reportId) {
        return Result.success(reportParameterService.getParametersByReportId(reportId));
    }

    @Operation(summary = "根据ID获取参数")
    @GetMapping("/parameter/{id}")
    public Result<ReportParameter> getParameterById(@PathVariable Long id) {
        return Result.success(reportParameterService.getParameterById(id));
    }

    @Operation(summary = "创建报表参数")
    @PostMapping("/parameter")
    public Result<ReportParameter> createParameter(@Valid @RequestBody ReportParameterDTO paramDTO) {
        return Result.success(reportParameterService.createParameter(paramDTO));
    }

    @Operation(summary = "批量创建报表参数")
    @PostMapping("/parameter/batch")
    public Result<List<ReportParameter>> createParameters(@Valid @RequestBody List<ReportParameterDTO> paramDTOs) {
        return Result.success(reportParameterService.createParameters(paramDTOs));
    }

    @Operation(summary = "更新报表参数")
    @PutMapping("/parameter/{id}")
    public Result<ReportParameter> updateParameter(@PathVariable Long id, @Valid @RequestBody ReportParameterDTO paramDTO) {
        return Result.success(reportParameterService.updateParameter(id, paramDTO));
    }

    @Operation(summary = "删除报表参数")
    @DeleteMapping("/parameter/{id}")
    public Result<Void> deleteParameter(@PathVariable Long id) {
        reportParameterService.deleteParameter(id);
        return Result.success();
    }

    // 报表模板相关接口
    @Operation(summary = "获取所有模板")
    @GetMapping("/template/list")
    public Result<List<ReportTemplate>> getAllTemplates() {
        return Result.success(reportTemplateService.getAllTemplates());
    }

    @Operation(summary = "根据ID获取模板")
    @GetMapping("/template/{id}")
    public Result<ReportTemplate> getTemplateById(@PathVariable Long id) {
        return Result.success(reportTemplateService.getTemplateById(id));
    }

    @Operation(summary = "创建报表模板")
    @PostMapping(value = "/template", consumes = "multipart/form-data")
    public Result<ReportTemplate> createTemplate(
            @RequestParam("templateName") String templateName,
            @RequestParam("templateType") String templateType,
            @RequestParam(value = "file", required = false) MultipartFile file,
            @RequestParam(value = "status", defaultValue = "1") Integer status) throws IOException {
        
        ReportTemplateDTO templateDTO = new ReportTemplateDTO();
        templateDTO.setTemplateName(templateName);
        templateDTO.setTemplateType(templateType);
        templateDTO.setTemplateFile(file);
        templateDTO.setStatus(status);
        
        return Result.success(reportTemplateService.createTemplate(templateDTO));
    }

    @Operation(summary = "更新报表模板")
    @PutMapping(value = "/template/{id}", consumes = "multipart/form-data")
    public Result<ReportTemplate> updateTemplate(
            @PathVariable Long id,
            @RequestParam("templateName") String templateName,
            @RequestParam("templateType") String templateType,
            @RequestParam(value = "file", required = false) MultipartFile file,
            @RequestParam(value = "status", defaultValue = "1") Integer status) throws IOException {
        
        ReportTemplateDTO templateDTO = new ReportTemplateDTO();
        templateDTO.setTemplateName(templateName);
        templateDTO.setTemplateType(templateType);
        templateDTO.setTemplateFile(file);
        templateDTO.setStatus(status);
        
        return Result.success(reportTemplateService.updateTemplate(id, templateDTO));
    }

    @Operation(summary = "删除报表模板")
    @DeleteMapping("/template/{id}")
    public Result<Void> deleteTemplate(@PathVariable Long id) {
        reportTemplateService.deleteTemplate(id);
        return Result.success();
    }

    @Operation(summary = "下载报表模板文件")
    @GetMapping("/template/download/{id}")
    public void downloadTemplateFile(@PathVariable Long id, HttpServletResponse response) throws IOException {
        byte[] fileData = reportTemplateService.getTemplateFile(id);
        
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=template.xlsx");
        response.getOutputStream().write(fileData);
        response.getOutputStream().flush();
    }

    // 报表调度相关接口
    @Operation(summary = "获取所有调度")
    @GetMapping("/schedule/list")
    public Result<List<ReportSchedule>> getAllSchedules() {
        return Result.success(reportScheduleService.getAllSchedules());
    }

    @Operation(summary = "根据ID获取调度")
    @GetMapping("/schedule/{id}")
    public Result<ReportSchedule> getScheduleById(@PathVariable Long id) {
        return Result.success(reportScheduleService.getScheduleById(id));
    }

    @Operation(summary = "根据报表ID获取调度")
    @GetMapping("/schedule/report/{reportId}")
    public Result<List<ReportSchedule>> getSchedulesByReportId(@PathVariable Long reportId) {
        return Result.success(reportScheduleService.getSchedulesByReportId(reportId));
    }

    @Operation(summary = "创建报表调度")
    @PostMapping("/schedule")
    public Result<ReportSchedule> createSchedule(@Valid @RequestBody ReportScheduleDTO scheduleDTO) {
        return Result.success(reportScheduleService.createSchedule(scheduleDTO));
    }

    @Operation(summary = "更新报表调度")
    @PutMapping("/schedule/{id}")
    public Result<ReportSchedule> updateSchedule(@PathVariable Long id, @Valid @RequestBody ReportScheduleDTO scheduleDTO) {
        return Result.success(reportScheduleService.updateSchedule(id, scheduleDTO));
    }

    @Operation(summary = "删除报表调度")
    @DeleteMapping("/schedule/{id}")
    public Result<Void> deleteSchedule(@PathVariable Long id) {
        reportScheduleService.deleteSchedule(id);
        return Result.success();
    }

    // 报表生成相关接口
    @Operation(summary = "生成报表")
    @PostMapping("/generate/{reportId}")
    public void generateReport(
            @PathVariable Long reportId,
            @RequestBody Map<String, Object> parameters,
            HttpServletResponse response) throws IOException {
        
        // 获取报表定义
        ReportDefinition reportDef = reportDefinitionService.getReportById(reportId);
        
        // 生成报表
        byte[] reportData = reportGenerationService.generateReportByDefinition(reportDef, parameters);
        
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=report_" + reportId + ".xlsx");
        response.getOutputStream().write(reportData);
        response.getOutputStream().flush();
    }
}