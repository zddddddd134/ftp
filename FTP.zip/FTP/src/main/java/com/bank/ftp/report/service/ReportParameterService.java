package com.bank.ftp.report.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.report.dto.ReportParameterDTO;
import com.bank.ftp.report.entity.ReportParameter;
import com.bank.ftp.report.repository.ReportParameterRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 报表参数服务
 */
@Service
@RequiredArgsConstructor
public class ReportParameterService {

    private final ReportParameterRepository reportParameterRepository;

    /**
     * 根据报表ID获取参数列表
     */
    public List<ReportParameter> getParametersByReportId(Long reportId) {
        return reportParameterRepository.findByReportId(reportId);
    }

    /**
     * 根据ID获取参数
     */
    public ReportParameter getParameterById(Long id) {
        return reportParameterRepository.findById(id)
                .orElseThrow(() -> new BusinessException("报表参数不存在"));
    }

    /**
     * 创建报表参数
     */
    @Transactional
    public ReportParameter createParameter(ReportParameterDTO paramDTO) {
        ReportParameter param = new ReportParameter();
        BeanUtils.copyProperties(paramDTO, param);
        return reportParameterRepository.save(param);
    }

    /**
     * 批量创建报表参数
     */
    @Transactional
    public List<ReportParameter> createParameters(List<ReportParameterDTO> paramDTOs) {
        return paramDTOs.stream()
                .map(this::createParameter)
                .toList();
    }

    /**
     * 更新报表参数
     */
    @Transactional
    public ReportParameter updateParameter(Long id, ReportParameterDTO paramDTO) {
        ReportParameter param = getParameterById(id);
        BeanUtils.copyProperties(paramDTO, param);
        return reportParameterRepository.save(param);
    }

    /**
     * 删除报表参数
     */
    @Transactional
    public void deleteParameter(Long id) {
        reportParameterRepository.deleteById(id);
    }

    /**
     * 根据报表ID删除所有参数
     */
    @Transactional
    public void deleteParametersByReportId(Long reportId) {
        List<ReportParameter> params = getParametersByReportId(reportId);
        reportParameterRepository.deleteAll(params);
    }
}