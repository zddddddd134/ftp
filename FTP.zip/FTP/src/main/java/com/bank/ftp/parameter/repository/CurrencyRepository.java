package com.bank.ftp.parameter.repository;

import com.bank.ftp.parameter.entity.Currency;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CurrencyRepository extends JpaRepository<Currency, Long> {
    Optional<Currency> findByCurrencyCode(String currencyCode);
    boolean existsByCurrencyCode(String currencyCode);
    Optional<Currency> findByIsDefault(Integer isDefault);
    List<Currency> findByStatus(Integer status);
}
