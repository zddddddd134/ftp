package com.bank.ftp.ftp.service.rule;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.ftp.dto.RuleVersionDTO;
import com.bank.ftp.ftp.entity.RuleVersion;
import com.bank.ftp.ftp.repository.RuleVersionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RuleVersionService {

    private final RuleVersionRepository ruleVersionRepository;

    public List<RuleVersion> getAllVersions() {
        return ruleVersionRepository.findAll();
    }

    public List<RuleVersion> getVersionsByRule(String ruleType, Long ruleId) {
        return ruleVersionRepository.findByRuleTypeAndRuleIdOrderByVersionNoDesc(ruleType, ruleId);
    }

    public List<RuleVersion> getVersionsByRuleCode(String ruleCode) {
        return ruleVersionRepository.findByRuleCode(ruleCode);
    }

    public RuleVersion getVersionById(Long id) {
        return ruleVersionRepository.findById(id)
                .orElseThrow(() -> new BusinessException("规则版本不存在"));
    }

    @Transactional
    public RuleVersion createVersion(RuleVersionDTO versionDTO) {
        RuleVersion version = new RuleVersion();
        BeanUtils.copyProperties(versionDTO, version);
        
        // 检查版本号是否已存在
        List<RuleVersion> existingVersions = getVersionsByRule(versionDTO.getRuleType(), versionDTO.getRuleId());
        for (RuleVersion v : existingVersions) {
            if (v.getVersionNo().equals(versionDTO.getVersionNo())) {
                throw new BusinessException("该版本号已存在");
            }
        }
        
        return ruleVersionRepository.save(version);
    }

    @Transactional
    public void deleteVersion(Long id) {
        ruleVersionRepository.deleteById(id);
    }
}
