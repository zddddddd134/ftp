package com.bank.ftp.parameter.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.parameter.dto.ExchangeRateDTO;
import com.bank.ftp.parameter.entity.ExchangeRate;
import com.bank.ftp.parameter.repository.ExchangeRateRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ExchangeRateService {

    private final ExchangeRateRepository exchangeRateRepository;

    public List<ExchangeRate> getAllRates() {
        return exchangeRateRepository.findAll();
    }

    public List<ExchangeRate> getRatesByDate(LocalDate rateDate) {
        return exchangeRateRepository.findByRateDate(rateDate);
    }

    public ExchangeRate getRateById(Long id) {
        return exchangeRateRepository.findById(id)
                .orElseThrow(() -> new BusinessException("汇率不存在"));
    }

    public Optional<ExchangeRate> getRateByCurrencyAndDate(
            Long sourceCurrencyId, Long targetCurrencyId, LocalDate rateDate) {
        return exchangeRateRepository.findBySourceCurrencyIdAndTargetCurrencyIdAndRateDate(
                sourceCurrencyId, targetCurrencyId, rateDate);
    }

    @Transactional
    public ExchangeRate createRate(ExchangeRateDTO rateDTO) {
        Optional<ExchangeRate> existingRate = getRateByCurrencyAndDate(
                rateDTO.getSourceCurrencyId(), rateDTO.getTargetCurrencyId(), rateDTO.getRateDate());
        if (existingRate.isPresent()) {
            throw new BusinessException("该汇率已存在");
        }

        ExchangeRate rate = new ExchangeRate();
        BeanUtils.copyProperties(rateDTO, rate);
        return exchangeRateRepository.save(rate);
    }

    @Transactional
    public ExchangeRate updateRate(Long id, ExchangeRateDTO rateDTO) {
        ExchangeRate rate = getRateById(id);
        
        Optional<ExchangeRate> existingRate = getRateByCurrencyAndDate(
                rateDTO.getSourceCurrencyId(), rateDTO.getTargetCurrencyId(), rateDTO.getRateDate());
        if (existingRate.isPresent() && !existingRate.get().getId().equals(id)) {
            throw new BusinessException("该汇率已存在");
        }

        rate.setSourceCurrencyId(rateDTO.getSourceCurrencyId());
        rate.setTargetCurrencyId(rateDTO.getTargetCurrencyId());
        rate.setExchangeRate(rateDTO.getExchangeRate());
        rate.setRateDate(rateDTO.getRateDate());
        
        return exchangeRateRepository.save(rate);
    }

    @Transactional
    public void deleteRate(Long id) {
        exchangeRateRepository.deleteById(id);
    }
}
