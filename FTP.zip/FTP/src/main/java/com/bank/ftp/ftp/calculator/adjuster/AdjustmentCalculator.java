package com.bank.ftp.ftp.calculator.adjuster;

import com.bank.ftp.ftp.entity.BusinessTransaction;
import com.bank.ftp.ftp.entity.AdjustmentRule;

import java.math.BigDecimal;
import java.util.List;

/**
 * 调整项计算器接口
 */
public interface AdjustmentCalculator {
    /**
     * 计算调整项
     * @param transaction 业务交易
     * @param rules 调整项规则列表
     * @return 调整值
     */
    BigDecimal calculateAdjustment(BusinessTransaction transaction, List<AdjustmentRule> rules);

    /**
     * 计算单个调整项
     * @param transaction 业务交易
     * @param rule 调整项规则
     * @return 调整值
     */
    BigDecimal calculateSingleAdjustment(BusinessTransaction transaction, AdjustmentRule rule);
}
