package com.bank.ftp.report.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.report.dto.ReportScheduleDTO;
import com.bank.ftp.report.entity.ReportSchedule;
import com.bank.ftp.report.repository.ReportScheduleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 报表调度服务
 */
@Service
@RequiredArgsConstructor
public class ReportScheduleService {

    private final ReportScheduleRepository reportScheduleRepository;

    /**
     * 获取所有调度
     */
    public List<ReportSchedule> getAllSchedules() {
        return reportScheduleRepository.findAll();
    }

    /**
     * 根据ID获取调度
     */
    public ReportSchedule getScheduleById(Long id) {
        return reportScheduleRepository.findById(id)
                .orElseThrow(() -> new BusinessException("报表调度不存在"));
    }

    /**
     * 根据报表ID获取调度
     */
    public List<ReportSchedule> getSchedulesByReportId(Long reportId) {
        return reportScheduleRepository.findByReportId(reportId);
    }

    /**
     * 创建报表调度
     */
    @Transactional
    public ReportSchedule createSchedule(ReportScheduleDTO scheduleDTO) {
        ReportSchedule schedule = new ReportSchedule();
        BeanUtils.copyProperties(scheduleDTO, schedule);
        schedule.setLastExecutionTime(null);
        schedule.setNextExecutionTime(null);
        return reportScheduleRepository.save(schedule);
    }

    /**
     * 更新报表调度
     */
    @Transactional
    public ReportSchedule updateSchedule(Long id, ReportScheduleDTO scheduleDTO) {
        ReportSchedule schedule = getScheduleById(id);
        BeanUtils.copyProperties(scheduleDTO, schedule);
        return reportScheduleRepository.save(schedule);
    }

    /**
     * 删除报表调度
     */
    @Transactional
    public void deleteSchedule(Long id) {
        reportScheduleRepository.deleteById(id);
    }

    /**
     * 更新最后执行时间
     */
    @Transactional
    public void updateLastExecutionTime(Long id, LocalDateTime executionTime) {
        ReportSchedule schedule = getScheduleById(id);
        schedule.setLastExecutionTime(executionTime);
        reportScheduleRepository.save(schedule);
    }

    /**
     * 更新下次执行时间
     */
    @Transactional
    public void updateNextExecutionTime(Long id, LocalDateTime executionTime) {
        ReportSchedule schedule = getScheduleById(id);
        schedule.setNextExecutionTime(executionTime);
        reportScheduleRepository.save(schedule);
    }
}