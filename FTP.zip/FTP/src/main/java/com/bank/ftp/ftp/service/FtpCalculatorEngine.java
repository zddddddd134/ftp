package com.bank.ftp.ftp.service;

import com.bank.ftp.ftp.calculator.adjuster.AdjustmentCalculator;
import com.bank.ftp.ftp.calculator.matcher.RuleMatcher;
import com.bank.ftp.ftp.calculator.method.DurationMatchingMethod;
import com.bank.ftp.ftp.calculator.method.MaturityMatchingMethod;
import com.bank.ftp.ftp.calculator.method.PoolMethod;
import com.bank.ftp.ftp.calculator.method.PricingMethod;
import com.bank.ftp.ftp.entity.*;
import com.bank.ftp.ftp.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * FTP计算引擎核心实现
 */
@Service
@RequiredArgsConstructor
public class FtpCalculatorEngine {

    private final RuleMatcher ruleMatcher;
    private final AdjustmentCalculator adjustmentCalculator;
    private final DurationMatchingMethod durationMatchingMethod;
    private final PoolMethod poolMethod;
    private final MaturityMatchingMethod maturityMatchingMethod;
    
    // 注入Repository
    private final PricingMethodRuleRepository pricingMethodRuleRepository;
    private final PricingCurveRuleRepository pricingCurveRuleRepository;
    private final AdjustmentRuleRepository adjustmentRuleRepository;
    private final RateCurveRepository rateCurveRepository;
    private final RateCurvePointRepository rateCurvePointRepository;
    private final FTPCalculationResultRepository ftpCalculationResultRepository;

    /**
     * 计算单个交易的FTP价格
     */
    public FTPCalculationResult calculateFtp(BusinessTransaction transaction) {
        // 1. 获取所有相关规则
        List<PricingMethodRule> methodRules = pricingMethodRuleRepository.findByStatusOrderByPriorityDesc(1);
        List<PricingCurveRule> curveRules = pricingCurveRuleRepository.findByStatusOrderByPriorityDesc(1);
        List<AdjustmentRule> adjustmentRules = adjustmentRuleRepository.findByStatusOrderByPriorityDesc(1);

        // 2. 匹配规则
        PricingMethodRule matchedMethodRule = ruleMatcher.matchPricingMethodRule(transaction, methodRules);
        PricingCurveRule matchedCurveRule = ruleMatcher.matchPricingCurveRule(transaction, curveRules);
        List<AdjustmentRule> matchedAdjustmentRules = ruleMatcher.matchAdjustmentRules(transaction, adjustmentRules);

        // 3. 根据匹配的方法规则选择定价方法
        PricingMethod pricingMethod = getPricingMethod(matchedMethodRule);
        BigDecimal baseRate = pricingMethod.calculateFtpPrice(transaction);

        // 4. 获取利率曲线点数据（根据匹配的曲线规则）
        BigDecimal curveRate = getCurveRate(matchedCurveRule, transaction);

        // 5. 计算调整项
        BigDecimal totalAdjustment = adjustmentCalculator.calculateAdjustment(transaction, matchedAdjustmentRules);

        // 6. 计算最终FTP价格
        BigDecimal finalFtpRate = curveRate.add(totalAdjustment);

        // 7. 计算FTP成本/收益
        BigDecimal ftpCost = transaction.getAmount().multiply(finalFtpRate);

        // 8. 创建计算结果
        FTPCalculationResult result = new FTPCalculationResult();
        result.setTransactionId(transaction.getId());
        result.setTransactionNo(transaction.getTransactionNo());
        result.setPricingDate(LocalDate.now());
        result.setBaseRate(curveRate);
        result.setTotalAdjustment(totalAdjustment);
        result.setFinalFtpRate(finalFtpRate);
        result.setFtpCost(ftpCost);
        if (matchedCurveRule != null) {
            result.setCurveId(matchedCurveRule.getCurveId());
        }
        if (matchedMethodRule != null) {
            result.setPricingMethod(matchedMethodRule.getPricingMethod());
        }

        return result;
    }

    /**
     * 批量计算FTP价格
     */
    public List<FTPCalculationResult> calculateBatchFtp(List<BusinessTransaction> transactions) {
        return transactions.stream()
                .map(this::calculateFtp)
                .toList();
    }

    /**
     * 根据规则获取定价方法实例
     */
    private PricingMethod getPricingMethod(PricingMethodRule rule) {
        if (rule == null) {
            // 默认使用期限匹配方法
            return durationMatchingMethod;
        }
        
        String methodName = rule.getPricingMethod();
        return switch (methodName.toLowerCase()) {
            case "duration_matching", "duration", "期限匹配" -> durationMatchingMethod;
            case "pool", "资金池" -> poolMethod;
            case "maturity_matching", "maturity", "到期日匹配" -> maturityMatchingMethod;
            default -> durationMatchingMethod; // 默认使用期限匹配
        };
    }

    /**
     * 根据曲线规则获取利率
     */
    private BigDecimal getCurveRate(PricingCurveRule rule, BusinessTransaction transaction) {
        if (rule == null || rule.getCurveId() == null) {
            return BigDecimal.ZERO;
        }

        // 获取利率曲线点数据
        List<RateCurvePoint> curvePoints = rateCurvePointRepository.findByCurveIdOrderByTermAsc(rule.getCurveId());
        
        if (curvePoints.isEmpty()) {
            return BigDecimal.ZERO;
        }

        // 使用插值算法获取对应期限的利率
        return interpolateRate(curvePoints, transaction.getTerm());
    }

    /**
     * 线性插值算法
     */
    private BigDecimal interpolateRate(List<RateCurvePoint> curvePoints, Integer term) {
        if (term == null) {
            // 如果没有明确期限，返回第一个点的利率
            return curvePoints.get(0).getRate();
        }

        // 找到相邻的两个点进行插值
        RateCurvePoint leftPoint = null;
        RateCurvePoint rightPoint = null;

        for (int i = 0; i < curvePoints.size(); i++) {
            RateCurvePoint point = curvePoints.get(i);
            if (point.getTerm() <= term) {
                leftPoint = point;
            } else {
                rightPoint = point;
                break;
            }
        }

        if (leftPoint == null) {
            // 如果期限小于最小点，使用第一个点
            return curvePoints.get(0).getRate();
        }

        if (rightPoint == null) {
            // 如果期限大于最大点，使用最后一个点
            return curvePoints.get(curvePoints.size() - 1).getRate();
        }

        // 线性插值计算
        int leftTerm = leftPoint.getTerm();
        int rightTerm = rightPoint.getTerm();
        BigDecimal leftRate = leftPoint.getRate();
        BigDecimal rightRate = rightPoint.getRate();

        // 插值公式: y = y1 + (y2-y1) * (x-x1)/(x2-x1)
        BigDecimal rateDiff = rightRate.subtract(leftRate);
        BigDecimal termDiff = BigDecimal.valueOf(rightTerm - leftTerm);
        BigDecimal termOffset = BigDecimal.valueOf(term - leftTerm);

        return leftRate.add(rateDiff.multiply(termOffset).divide(termDiff, 6, BigDecimal.ROUND_HALF_UP));
    }
}
