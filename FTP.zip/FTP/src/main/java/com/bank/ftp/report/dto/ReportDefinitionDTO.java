package com.bank.ftp.report.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ReportDefinitionDTO {
    private Long id;

    @NotBlank(message = "报表编码不能为空")
    private String reportCode;

    @NotBlank(message = "报表名称不能为空")
    private String reportName;

    private String description;

    private Long templateId;

    private String dataSourceConfig;

    private Integer status = 1;
}