package com.bank.ftp.ftp.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.ftp.dto.RuleVersionDTO;
import com.bank.ftp.ftp.entity.RuleVersion;
import com.bank.ftp.ftp.service.rule.RuleVersionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "规则版本管理", description = "规则版本管理相关接口")
@RestController
@RequestMapping("/ftp/rule/version")
@RequiredArgsConstructor
public class RuleVersionController {

    private final RuleVersionService ruleVersionService;

    @Operation(summary = "获取所有规则版本")
    @GetMapping("/list")
    public Result<List<RuleVersion>> getAllVersions() {
        return Result.success(ruleVersionService.getAllVersions());
    }

    @Operation(summary = "根据规则类型和ID获取版本列表")
    @GetMapping("/rule/{ruleType}/{ruleId}")
    public Result<List<RuleVersion>> getVersionsByRule(@PathVariable String ruleType, @PathVariable Long ruleId) {
        return Result.success(ruleVersionService.getVersionsByRule(ruleType, ruleId));
    }

    @Operation(summary = "根据规则编码获取版本列表")
    @GetMapping("/code/{ruleCode}")
    public Result<List<RuleVersion>> getVersionsByRuleCode(@PathVariable String ruleCode) {
        return Result.success(ruleVersionService.getVersionsByRuleCode(ruleCode));
    }

    @Operation(summary = "根据ID获取规则版本")
    @GetMapping("/{id}")
    public Result<RuleVersion> getVersionById(@PathVariable Long id) {
        return Result.success(ruleVersionService.getVersionById(id));
    }

    @Operation(summary = "创建规则版本")
    @PostMapping
    public Result<RuleVersion> createVersion(@Valid @RequestBody RuleVersionDTO versionDTO) {
        return Result.success(ruleVersionService.createVersion(versionDTO));
    }

    @Operation(summary = "删除规则版本")
    @DeleteMapping("/{id}")
    public Result<Void> deleteVersion(@PathVariable Long id) {
        ruleVersionService.deleteVersion(id);
        return Result.success();
    }
}
