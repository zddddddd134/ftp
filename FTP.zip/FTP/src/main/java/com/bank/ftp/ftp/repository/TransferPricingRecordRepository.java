package com.bank.ftp.ftp.repository;

import com.bank.ftp.ftp.entity.TransferPricingRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TransferPricingRecordRepository extends JpaRepository<TransferPricingRecord, Long> {
    List<TransferPricingRecord> findByTransactionId(Long transactionId);
    List<TransferPricingRecord> findByPricingDate(java.time.LocalDate pricingDate);
}
