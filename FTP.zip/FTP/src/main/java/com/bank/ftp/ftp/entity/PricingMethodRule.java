package com.bank.ftp.ftp.entity;

import com.bank.ftp.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "ftp_pricing_method_rule")
public class PricingMethodRule extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "rule_code", nullable = false, unique = true, length = 50)
    private String ruleCode;

    @Column(name = "rule_name", nullable = false, length = 100)
    private String ruleName;

    @Column(name = "pricing_method", nullable = false, length = 50)
    private String pricingMethod;

    @Column(name = "product_type_ids", columnDefinition = "TEXT")
    private String productTypeIds;

    @Column(name = "org_ids", columnDefinition = "TEXT")
    private String orgIds;

    @Column(name = "amount_min", precision = 20, scale = 2)
    private BigDecimal amountMin;

    @Column(name = "amount_max", precision = 20, scale = 2)
    private BigDecimal amountMax;

    @Column(name = "term_min")
    private Integer termMin;

    @Column(name = "term_max")
    private Integer termMax;

    @Column(name = "priority")
    private Integer priority = 0;

    @Column(name = "status")
    private Integer status = 1;
}
