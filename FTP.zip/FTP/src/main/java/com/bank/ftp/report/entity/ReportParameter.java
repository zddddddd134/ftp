package com.bank.ftp.report.entity;

import com.bank.ftp.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "rpt_parameter")
public class ReportParameter extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "report_id", nullable = false)
    private Long reportId;

    @Column(name = "param_name", nullable = false, length = 50)
    private String paramName;

    @Column(name = "param_code", nullable = false, length = 50)
    private String paramCode;

    @Column(name = "param_type", nullable = false, length = 20)
    private String paramType;

    @Column(name = "param_default_value", length = 200)
    private String paramDefaultValue;

    @Column(name = "param_options", columnDefinition = "TEXT")
    private String paramOptions;

    @Column(name = "required")
    private Integer required = 0;

    @Column(name = "sort_order")
    private Integer sortOrder = 0;
}