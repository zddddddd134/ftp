package com.bank.ftp.ftp.repository;

import com.bank.ftp.ftp.entity.AdjustmentRule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AdjustmentRuleRepository extends JpaRepository<AdjustmentRule, Long> {
    Optional<AdjustmentRule> findByRuleCode(String ruleCode);
    boolean existsByRuleCode(String ruleCode);
    List<AdjustmentRule> findByStatusOrderByPriorityDesc(Integer status);
}
