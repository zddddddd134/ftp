package com.bank.ftp.system.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class SystemConfigDTO {
    private Long id;

    @NotBlank(message = "配置键不能为空")
    private String configKey;

    private String configValue;

    private String configName;

    private String description;

    private String configType = "string";
}
