package com.bank.ftp.system.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.system.dto.RoleDTO;
import com.bank.ftp.system.entity.Role;
import com.bank.ftp.system.repository.RoleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RoleService {

    private final RoleRepository roleRepository;

    public List<Role> getAllRoles() {
        return roleRepository.findAll();
    }

    public Role getRoleById(Long id) {
        return roleRepository.findById(id)
                .orElseThrow(() -> new BusinessException("角色不存在"));
    }

    @Transactional
    public Role createRole(RoleDTO roleDTO) {
        if (roleRepository.existsByRoleCode(roleDTO.getRoleCode())) {
            throw new BusinessException("角色编码已存在");
        }

        Role role = new Role();
        BeanUtils.copyProperties(roleDTO, role);
        role.setStatus(1);
        return roleRepository.save(role);
    }

    @Transactional
    public Role updateRole(Long id, RoleDTO roleDTO) {
        Role role = getRoleById(id);
        
        if (!role.getRoleCode().equals(roleDTO.getRoleCode()) && 
            roleRepository.existsByRoleCode(roleDTO.getRoleCode())) {
            throw new BusinessException("角色编码已存在");
        }

        role.setRoleName(roleDTO.getRoleName());
        role.setDescription(roleDTO.getDescription());
        role.setStatus(roleDTO.getStatus());
        
        return roleRepository.save(role);
    }

    @Transactional
    public void deleteRole(Long id) {
        Role role = getRoleById(id);
        role.setDeleted(1);
        roleRepository.save(role);
    }
}
