package com.bank.ftp.parameter.repository;

import com.bank.ftp.parameter.entity.ExchangeRate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface ExchangeRateRepository extends JpaRepository<ExchangeRate, Long> {
    Optional<ExchangeRate> findBySourceCurrencyIdAndTargetCurrencyIdAndRateDate(
            Long sourceCurrencyId, Long targetCurrencyId, LocalDate rateDate);
    List<ExchangeRate> findByRateDate(LocalDate rateDate);
    List<ExchangeRate> findBySourceCurrencyIdAndRateDate(Long sourceCurrencyId, LocalDate rateDate);
}
