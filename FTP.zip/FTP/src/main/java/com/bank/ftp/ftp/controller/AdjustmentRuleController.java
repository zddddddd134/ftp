package com.bank.ftp.ftp.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.ftp.dto.AdjustmentRuleDTO;
import com.bank.ftp.ftp.entity.AdjustmentRule;
import com.bank.ftp.ftp.service.rule.AdjustmentRuleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "调整项规则管理", description = "调整项规则相关接口")
@RestController
@RequestMapping("/ftp/rule/adjustment")
@RequiredArgsConstructor
public class AdjustmentRuleController {

    private final AdjustmentRuleService adjustmentRuleService;

    @Operation(summary = "获取所有调整项规则")
    @GetMapping("/list")
    public Result<List<AdjustmentRule>> getAllRules() {
        return Result.success(adjustmentRuleService.getAllRules());
    }

    @Operation(summary = "获取启用的调整项规则")
    @GetMapping("/active")
    public Result<List<AdjustmentRule>> getActiveRules() {
        return Result.success(adjustmentRuleService.getActiveRules());
    }

    @Operation(summary = "根据ID获取调整项规则")
    @GetMapping("/{id}")
    public Result<AdjustmentRule> getRuleById(@PathVariable Long id) {
        return Result.success(adjustmentRuleService.getRuleById(id));
    }

    @Operation(summary = "创建调整项规则")
    @PostMapping
    public Result<AdjustmentRule> createRule(@Valid @RequestBody AdjustmentRuleDTO ruleDTO) {
        return Result.success(adjustmentRuleService.createRule(ruleDTO));
    }

    @Operation(summary = "更新调整项规则")
    @PutMapping("/{id}")
    public Result<AdjustmentRule> updateRule(@PathVariable Long id, @Valid @RequestBody AdjustmentRuleDTO ruleDTO) {
        return Result.success(adjustmentRuleService.updateRule(id, ruleDTO));
    }

    @Operation(summary = "删除调整项规则")
    @DeleteMapping("/{id}")
    public Result<Void> deleteRule(@PathVariable Long id) {
        adjustmentRuleService.deleteRule(id);
        return Result.success();
    }
}
