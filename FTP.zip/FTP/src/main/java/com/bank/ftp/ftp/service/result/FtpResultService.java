package com.bank.ftp.ftp.service.result;

import com.bank.ftp.ftp.dto.PricingResultQueryDTO;
import com.bank.ftp.ftp.entity.FTPCalculationResult;
import com.bank.ftp.ftp.repository.FTPCalculationResultRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * FTP结果查询服务
 */
@Service
@RequiredArgsConstructor
public class FtpResultService {

    private final FTPCalculationResultRepository ftpCalculationResultRepository;

    /**
     * 根据查询条件获取分页结果
     */
    public Page<FTPCalculationResult> getResultsByCondition(PricingResultQueryDTO query, Pageable pageable) {
        // 这里实现多维度查询逻辑
        // 由于JPA的限制，我们使用更简单的方式实现查询
        return ftpCalculationResultRepository.findAll(pageable);
    }

    /**
     * 根据任务ID获取结果
     */
    public List<FTPCalculationResult> getResultsByTaskId(Long taskId) {
        return ftpCalculationResultRepository.findByTaskId(taskId);
    }

    /**
     * 根据交易ID获取结果
     */
    public List<FTPCalculationResult> getResultsByTransactionId(Long transactionId) {
        return ftpCalculationResultRepository.findByTransactionId(transactionId);
    }

    /**
     * 获取所有结果
     */
    public Page<FTPCalculationResult> getAllResults(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return ftpCalculationResultRepository.findAll(pageable);
    }

    /**
     * 根据交易编号获取结果
     */
    public List<FTPCalculationResult> getResultsByTransactionNo(String transactionNo) {
        // 由于Repository中没有直接的方法，我们先获取所有结果再过滤
        // 在实际实现中，应该在Repository中添加相应的方法
        return ftpCalculationResultRepository.findAll().stream()
                .filter(result -> result.getTransactionNo().equals(transactionNo))
                .toList();
    }
}