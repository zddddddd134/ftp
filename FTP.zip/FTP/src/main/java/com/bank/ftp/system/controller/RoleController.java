package com.bank.ftp.system.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.system.dto.RoleDTO;
import com.bank.ftp.system.entity.Role;
import com.bank.ftp.system.service.RoleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "角色管理", description = "角色管理相关接口")
@RestController
@RequestMapping("/system/role")
@RequiredArgsConstructor
public class RoleController {

    private final RoleService roleService;

    @Operation(summary = "获取所有角色")
    @GetMapping("/list")
    public Result<List<Role>> getAllRoles() {
        return Result.success(roleService.getAllRoles());
    }

    @Operation(summary = "根据ID获取角色")
    @GetMapping("/{id}")
    public Result<Role> getRoleById(@PathVariable Long id) {
        return Result.success(roleService.getRoleById(id));
    }

    @Operation(summary = "创建角色")
    @PostMapping
    public Result<Role> createRole(@Valid @RequestBody RoleDTO roleDTO) {
        return Result.success(roleService.createRole(roleDTO));
    }

    @Operation(summary = "更新角色")
    @PutMapping("/{id}")
    public Result<Role> updateRole(@PathVariable Long id, @Valid @RequestBody RoleDTO roleDTO) {
        return Result.success(roleService.updateRole(id, roleDTO));
    }

    @Operation(summary = "删除角色")
    @DeleteMapping("/{id}")
    public Result<Void> deleteRole(@PathVariable Long id) {
        roleService.deleteRole(id);
        return Result.success();
    }
}
