package com.bank.ftp.system.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.system.dto.PasswordPolicyDTO;
import com.bank.ftp.system.entity.PasswordPolicy;
import com.bank.ftp.system.repository.PasswordPolicyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class PasswordService {

    private final PasswordPolicyRepository passwordPolicyRepository;

    public PasswordPolicy getActivePolicy() {
        return passwordPolicyRepository.findByStatus(1)
                .orElseGet(() -> createDefaultPolicy());
    }

    public List<PasswordPolicy> getAllPolicies() {
        return passwordPolicyRepository.findAll();
    }

    public PasswordPolicy getPolicyById(Long id) {
        return passwordPolicyRepository.findById(id)
                .orElseThrow(() -> new BusinessException("密码策略不存在"));
    }

    @Transactional
    public PasswordPolicy createPolicy(PasswordPolicyDTO policyDTO) {
        PasswordPolicy policy = new PasswordPolicy();
        BeanUtils.copyProperties(policyDTO, policy);
        return passwordPolicyRepository.save(policy);
    }

    @Transactional
    public PasswordPolicy updatePolicy(Long id, PasswordPolicyDTO policyDTO) {
        PasswordPolicy policy = getPolicyById(id);
        BeanUtils.copyProperties(policyDTO, policy, "id");
        return passwordPolicyRepository.save(policy);
    }

    @Transactional
    public void activatePolicy(Long id) {
        List<PasswordPolicy> allPolicies = passwordPolicyRepository.findAll();
        for (PasswordPolicy p : allPolicies) {
            p.setStatus(p.getId().equals(id) ? 1 : 0);
            passwordPolicyRepository.save(p);
        }
    }

    public void validatePassword(String password) {
        PasswordPolicy policy = getActivePolicy();
        
        if (password.length() < policy.getMinLength()) {
            throw new BusinessException("密码长度不能小于" + policy.getMinLength() + "位");
        }
        
        if (password.length() > policy.getMaxLength()) {
            throw new BusinessException("密码长度不能大于" + policy.getMaxLength() + "位");
        }
        
        if (policy.getRequireUpper() == 1 && !Pattern.matches(".*[A-Z].*", password)) {
            throw new BusinessException("密码必须包含大写字母");
        }
        
        if (policy.getRequireLower() == 1 && !Pattern.matches(".*[a-z].*", password)) {
            throw new BusinessException("密码必须包含小写字母");
        }
        
        if (policy.getRequireDigit() == 1 && !Pattern.matches(".*\\d.*", password)) {
            throw new BusinessException("密码必须包含数字");
        }
        
        if (policy.getRequireSpecial() == 1 && !Pattern.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*", password)) {
            throw new BusinessException("密码必须包含特殊字符");
        }
    }

    private PasswordPolicy createDefaultPolicy() {
        PasswordPolicy policy = new PasswordPolicy();
        policy.setPolicyName("默认策略");
        policy.setMinLength(8);
        policy.setMaxLength(20);
        policy.setRequireUpper(1);
        policy.setRequireLower(1);
        policy.setRequireDigit(1);
        policy.setRequireSpecial(0);
        policy.setPasswordExpireDays(90);
        policy.setPasswordHistoryCount(5);
        policy.setStatus(1);
        return passwordPolicyRepository.save(policy);
    }
}
