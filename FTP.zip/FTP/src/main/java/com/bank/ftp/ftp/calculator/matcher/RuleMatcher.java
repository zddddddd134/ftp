package com.bank.ftp.ftp.calculator.matcher;

import com.bank.ftp.ftp.entity.BusinessTransaction;
import com.bank.ftp.ftp.entity.PricingMethodRule;
import com.bank.ftp.ftp.entity.PricingCurveRule;
import com.bank.ftp.ftp.entity.AdjustmentRule;

import java.util.List;

/**
 * 规则匹配器接口
 */
public interface RuleMatcher {
    /**
     * 匹配定价方法规则
     * @param transaction 业务交易
     * @param rules 定价方法规则列表
     * @return 匹配的规则
     */
    PricingMethodRule matchPricingMethodRule(BusinessTransaction transaction, List<PricingMethodRule> rules);

    /**
     * 匹配定价曲线规则
     * @param transaction 业务交易
     * @param rules 定价曲线规则列表
     * @return 匹配的规则
     */
    PricingCurveRule matchPricingCurveRule(BusinessTransaction transaction, List<PricingCurveRule> rules);

    /**
     * 匹配调整项规则
     * @param transaction 业务交易
     * @param rules 调整项规则列表
     * @return 匹配的规则列表
     */
    List<AdjustmentRule> matchAdjustmentRules(BusinessTransaction transaction, List<AdjustmentRule> rules);
}
