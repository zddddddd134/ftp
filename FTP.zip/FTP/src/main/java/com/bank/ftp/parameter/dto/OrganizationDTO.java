package com.bank.ftp.parameter.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class OrganizationDTO {
    private Long id;

    @NotBlank(message = "机构编码不能为空")
    private String orgCode;

    @NotBlank(message = "机构名称不能为空")
    private String orgName;

    private String orgType;

    private Long parentId = 0L;

    private Integer level = 1;

    private Integer sortOrder = 0;

    private Integer status = 1;
}
