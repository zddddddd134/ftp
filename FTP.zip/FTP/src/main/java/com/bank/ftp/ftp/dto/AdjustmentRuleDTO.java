package com.bank.ftp.ftp.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class AdjustmentRuleDTO {
    private Long id;

    @NotBlank(message = "规则编码不能为空")
    private String ruleCode;

    @NotBlank(message = "规则名称不能为空")
    private String ruleName;

    @NotBlank(message = "调整类型不能为空")
    private String adjustmentType;

    @NotNull(message = "调整值不能为空")
    private BigDecimal adjustmentValue;

    private String adjustmentMode = "add";

    private List<Long> productTypeIds;

    private List<Long> orgIds;

    private BigDecimal amountMin;

    private BigDecimal amountMax;

    private Integer termMin;

    private Integer termMax;

    private Integer priority = 0;

    private Integer status = 1;
}
