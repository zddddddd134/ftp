package com.bank.ftp.system.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PasswordPolicyDTO {
    private Long id;

    @NotBlank(message = "策略名称不能为空")
    private String policyName;

    private Integer minLength = 8;

    private Integer maxLength = 20;

    private Integer requireUpper = 1;

    private Integer requireLower = 1;

    private Integer requireDigit = 1;

    private Integer requireSpecial = 0;

    private Integer passwordExpireDays = 90;

    private Integer passwordHistoryCount = 5;

    private Integer status = 1;
}
