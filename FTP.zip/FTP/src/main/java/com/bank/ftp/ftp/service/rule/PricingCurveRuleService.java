package com.bank.ftp.ftp.service.rule;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.ftp.dto.PricingCurveRuleDTO;
import com.bank.ftp.ftp.entity.PricingCurveRule;
import com.bank.ftp.ftp.repository.PricingCurveRuleRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PricingCurveRuleService {

    private final PricingCurveRuleRepository pricingCurveRuleRepository;
    private final ObjectMapper objectMapper;

    public List<PricingCurveRule> getAllRules() {
        return pricingCurveRuleRepository.findAll();
    }

    public List<PricingCurveRule> getActiveRules() {
        return pricingCurveRuleRepository.findByStatusOrderByPriorityDesc(1);
    }

    public PricingCurveRule getRuleById(Long id) {
        return pricingCurveRuleRepository.findById(id)
                .orElseThrow(() -> new BusinessException("定价曲线规则不存在"));
    }

    @Transactional
    public PricingCurveRule createRule(PricingCurveRuleDTO ruleDTO) {
        if (pricingCurveRuleRepository.existsByRuleCode(ruleDTO.getRuleCode())) {
            throw new BusinessException("规则编码已存在");
        }

        PricingCurveRule rule = new PricingCurveRule();
        BeanUtils.copyProperties(ruleDTO, rule);
        
        // 将List转换为JSON字符串存储
        rule.setProductTypeIds(convertListToJson(ruleDTO.getProductTypeIds()));
        rule.setOrgIds(convertListToJson(ruleDTO.getOrgIds()));
        
        return pricingCurveRuleRepository.save(rule);
    }

    @Transactional
    public PricingCurveRule updateRule(Long id, PricingCurveRuleDTO ruleDTO) {
        PricingCurveRule rule = getRuleById(id);
        
        if (!rule.getRuleCode().equals(ruleDTO.getRuleCode()) && 
            pricingCurveRuleRepository.existsByRuleCode(ruleDTO.getRuleCode())) {
            throw new BusinessException("规则编码已存在");
        }

        BeanUtils.copyProperties(ruleDTO, rule);
        
        // 将List转换为JSON字符串存储
        rule.setProductTypeIds(convertListToJson(ruleDTO.getProductTypeIds()));
        rule.setOrgIds(convertListToJson(ruleDTO.getOrgIds()));
        
        return pricingCurveRuleRepository.save(rule);
    }

    @Transactional
    public void deleteRule(Long id) {
        PricingCurveRule rule = getRuleById(id);
        rule.setDeleted(1);
        pricingCurveRuleRepository.save(rule);
    }

    private String convertListToJson(List<Long> list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(list);
        } catch (JsonProcessingException e) {
            throw new BusinessException("序列化列表失败");
        }
    }

    public List<Long> convertJsonToList(String jsonStr) {
        if (jsonStr == null || jsonStr.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.readValue(jsonStr, List.class);
        } catch (JsonProcessingException e) {
            throw new BusinessException("反序列化列表失败");
        }
    }
}
