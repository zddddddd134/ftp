package com.bank.ftp.report.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.report.dto.ReportDefinitionDTO;
import com.bank.ftp.report.entity.ReportDefinition;
import com.bank.ftp.report.repository.ReportDefinitionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 报表定义服务
 */
@Service
@RequiredArgsConstructor
public class ReportDefinitionService {

    private final ReportDefinitionRepository reportDefinitionRepository;

    /**
     * 获取所有报表定义
     */
    public List<ReportDefinition> getAllReports() {
        return reportDefinitionRepository.findAll();
    }

    /**
     * 根据ID获取报表定义
     */
    public ReportDefinition getReportById(Long id) {
        return reportDefinitionRepository.findById(id)
                .orElseThrow(() -> new BusinessException("报表定义不存在"));
    }

    /**
     * 根据编码获取报表定义
     */
    public ReportDefinition getReportByCode(String reportCode) {
        return reportDefinitionRepository.findByReportCode(reportCode)
                .orElseThrow(() -> new BusinessException("报表定义不存在"));
    }

    /**
     * 创建报表定义
     */
    @Transactional
    public ReportDefinition createReport(ReportDefinitionDTO reportDTO) {
        if (reportDefinitionRepository.existsByReportCode(reportDTO.getReportCode())) {
            throw new BusinessException("报表编码已存在");
        }

        ReportDefinition report = new ReportDefinition();
        BeanUtils.copyProperties(reportDTO, report);
        return reportDefinitionRepository.save(report);
    }

    /**
     * 更新报表定义
     */
    @Transactional
    public ReportDefinition updateReport(Long id, ReportDefinitionDTO reportDTO) {
        ReportDefinition report = getReportById(id);

        if (!report.getReportCode().equals(reportDTO.getReportCode()) &&
            reportDefinitionRepository.existsByReportCode(reportDTO.getReportCode())) {
            throw new BusinessException("报表编码已存在");
        }

        BeanUtils.copyProperties(reportDTO, report);
        return reportDefinitionRepository.save(report);
    }

    /**
     * 删除报表定义
     */
    @Transactional
    public void deleteReport(Long id) {
        ReportDefinition report = getReportById(id);
        report.setDeleted(1);
        reportDefinitionRepository.save(report);
    }
}