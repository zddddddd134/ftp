package com.bank.ftp.ftp.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "ftp_business_transaction")
public class BusinessTransaction implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "transaction_no", nullable = false, unique = true, length = 50)
    private String transactionNo;

    @Column(name = "product_type_id", nullable = false)
    private Long productTypeId;

    @Column(name = "org_id")
    private Long orgId;

    @Column(name = "currency_id", nullable = false)
    private Long currencyId;

    @Column(name = "amount", nullable = false, precision = 20, scale = 2)
    private BigDecimal amount;

    @Column(name = "direction", nullable = false, length = 10)
    private String direction;

    @Column(name = "start_date", nullable = false)
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Column(name = "term")
    private Integer term;

    @Column(name = "interest_rate", precision = 10, scale = 6)
    private BigDecimal interestRate;

    @Column(name = "status")
    private Integer status = 1; // 1-正常，2-逾期

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_time", updatable = false)
    @CreationTimestamp
    private LocalDateTime createdTime;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_time")
    @UpdateTimestamp
    private LocalDateTime updatedTime;
}
