package com.bank.ftp.parameter.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CaliberDTO {
    private Long id;

    @NotBlank(message = "口径编码不能为空")
    private String caliberCode;

    @NotBlank(message = "口径名称不能为空")
    private String caliberName;

    private String description;

    private String caliberRule;

    private Integer status = 1;
}
