package com.bank.ftp.ftp.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.ftp.entity.RateCurve;
import com.bank.ftp.ftp.entity.RateCurvePoint;
import com.bank.ftp.ftp.repository.RateCurvePointRepository;
import com.bank.ftp.ftp.repository.RateCurveRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * 利率曲线管理服务
 */
@Service
@RequiredArgsConstructor
public class RateCurveService {

    private final RateCurveRepository rateCurveRepository;
    private final RateCurvePointRepository rateCurvePointRepository;

    /**
     * 获取所有利率曲线
     */
    public List<RateCurve> getAllCurves() {
        return rateCurveRepository.findAll();
    }

    /**
     * 根据ID获取利率曲线
     */
    public RateCurve getCurveById(Long id) {
        return rateCurveRepository.findById(id)
                .orElseThrow(() -> new BusinessException("利率曲线不存在"));
    }

    /**
     * 根据编码获取利率曲线
     */
    public RateCurve getCurveByCode(String curveCode) {
        return rateCurveRepository.findByCurveCode(curveCode)
                .orElseThrow(() -> new BusinessException("利率曲线不存在"));
    }

    /**
     * 创建利率曲线
     */
    @Transactional
    public RateCurve createCurve(RateCurve curve) {
        if (rateCurveRepository.existsByCurveCode(curve.getCurveCode())) {
            throw new BusinessException("利率曲线编码已存在");
        }
        return rateCurveRepository.save(curve);
    }

    /**
     * 更新利率曲线
     */
    @Transactional
    public RateCurve updateCurve(Long id, RateCurve curve) {
        RateCurve existingCurve = getCurveById(id);
        
        if (!existingCurve.getCurveCode().equals(curve.getCurveCode()) &&
            rateCurveRepository.existsByCurveCode(curve.getCurveCode())) {
            throw new BusinessException("利率曲线编码已存在");
        }

        existingCurve.setCurveName(curve.getCurveName());
        existingCurve.setCurveType(curve.getCurveType());
        existingCurve.setCurrencyId(curve.getCurrencyId());
        existingCurve.setDescription(curve.getDescription());
        existingCurve.setStatus(curve.getStatus());
        
        return rateCurveRepository.save(existingCurve);
    }

    /**
     * 删除利率曲线
     */
    @Transactional
    public void deleteCurve(Long id) {
        RateCurve curve = getCurveById(id);
        curve.setDeleted(1);
        rateCurveRepository.save(curve);
        
        // 同时删除相关的曲线点
        rateCurvePointRepository.deleteByCurveId(id);
    }

    /**
     * 获取利率曲线的所有点
     */
    public List<RateCurvePoint> getCurvePoints(Long curveId) {
        return rateCurvePointRepository.findByCurveIdOrderByTermAsc(curveId);
    }

    /**
     * 添加利率曲线点
     */
    @Transactional
    public RateCurvePoint addCurvePoint(RateCurvePoint point) {
        return rateCurvePointRepository.save(point);
    }

    /**
     * 批量添加利率曲线点
     */
    @Transactional
    public List<RateCurvePoint> addCurvePoints(Long curveId, List<RateCurvePoint> points) {
        for (RateCurvePoint point : points) {
            point.setCurveId(curveId);
        }
        return rateCurvePointRepository.saveAll(points);
    }

    /**
     * 删除利率曲线点
     */
    @Transactional
    public void deleteCurvePoint(Long pointId) {
        rateCurvePointRepository.deleteById(pointId);
    }

    /**
     * 根据期限获取插值利率
     */
    public BigDecimal getInterpolatedRate(Long curveId, Integer term) {
        List<RateCurvePoint> curvePoints = getCurvePoints(curveId);
        
        if (curvePoints.isEmpty()) {
            throw new BusinessException("利率曲线无数据点");
        }

        // 使用插值算法获取对应期限的利率
        return interpolateRate(curvePoints, term);
    }

    /**
     * 线性插值算法
     */
    private BigDecimal interpolateRate(List<RateCurvePoint> curvePoints, Integer term) {
        if (term == null) {
            // 如果没有明确期限，返回第一个点的利率
            return curvePoints.get(0).getRate();
        }

        // 找到相邻的两个点进行插值
        RateCurvePoint leftPoint = null;
        RateCurvePoint rightPoint = null;

        for (int i = 0; i < curvePoints.size(); i++) {
            RateCurvePoint point = curvePoints.get(i);
            if (point.getTerm() <= term) {
                leftPoint = point;
            } else {
                rightPoint = point;
                break;
            }
        }

        if (leftPoint == null) {
            // 如果期限小于最小点，使用第一个点
            return curvePoints.get(0).getRate();
        }

        if (rightPoint == null) {
            // 如果期限大于最大点，使用最后一个点
            return curvePoints.get(curvePoints.size() - 1).getRate();
        }

        // 线性插值计算
        int leftTerm = leftPoint.getTerm();
        int rightTerm = rightPoint.getTerm();
        BigDecimal leftRate = leftPoint.getRate();
        BigDecimal rightRate = rightPoint.getRate();

        // 插值公式: y = y1 + (y2-y1) * (x-x1)/(x2-x1)
        BigDecimal rateDiff = rightRate.subtract(leftRate);
        BigDecimal termDiff = BigDecimal.valueOf(rightTerm - leftTerm);
        BigDecimal termOffset = BigDecimal.valueOf(term - leftTerm);

        return leftRate.add(rateDiff.multiply(termOffset).divide(termDiff, 6, BigDecimal.ROUND_HALF_UP));
    }
}
