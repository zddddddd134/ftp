package com.bank.ftp.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.Contact;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("FTP System API")
                        .version("1.0.0")
                        .description("银行内部资金转移定价系统API文档")
                        .contact(new Contact()
                                .name("API Support")
                                .email("support@example.com")));
    }
}