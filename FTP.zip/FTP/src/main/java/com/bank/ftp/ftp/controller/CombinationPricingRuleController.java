package com.bank.ftp.ftp.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.ftp.dto.CombinationPricingRuleDTO;
import com.bank.ftp.ftp.entity.CombinationPricingRule;
import com.bank.ftp.ftp.service.rule.CombinationPricingRuleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "组合定价规则管理", description = "组合定价规则相关接口")
@RestController
@RequestMapping("/ftp/rule/combination")
@RequiredArgsConstructor
public class CombinationPricingRuleController {

    private final CombinationPricingRuleService combinationPricingRuleService;

    @Operation(summary = "获取所有组合定价规则")
    @GetMapping("/list")
    public Result<List<CombinationPricingRule>> getAllRules() {
        return Result.success(combinationPricingRuleService.getAllRules());
    }

    @Operation(summary = "获取启用的组合定价规则")
    @GetMapping("/active")
    public Result<List<CombinationPricingRule>> getActiveRules() {
        return Result.success(combinationPricingRuleService.getActiveRules());
    }

    @Operation(summary = "根据ID获取组合定价规则")
    @GetMapping("/{id}")
    public Result<CombinationPricingRule> getRuleById(@PathVariable Long id) {
        return Result.success(combinationPricingRuleService.getRuleById(id));
    }

    @Operation(summary = "创建组合定价规则")
    @PostMapping
    public Result<CombinationPricingRule> createRule(@Valid @RequestBody CombinationPricingRuleDTO ruleDTO) {
        return Result.success(combinationPricingRuleService.createRule(ruleDTO));
    }

    @Operation(summary = "更新组合定价规则")
    @PutMapping("/{id}")
    public Result<CombinationPricingRule> updateRule(@PathVariable Long id, @Valid @RequestBody CombinationPricingRuleDTO ruleDTO) {
        return Result.success(combinationPricingRuleService.updateRule(id, ruleDTO));
    }

    @Operation(summary = "删除组合定价规则")
    @DeleteMapping("/{id}")
    public Result<Void> deleteRule(@PathVariable Long id) {
        combinationPricingRuleService.deleteRule(id);
        return Result.success();
    }
}
