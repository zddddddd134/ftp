package com.bank.ftp.ftp.service.result;

import com.bank.ftp.ftp.entity.FTPCalculationResult;
import com.bank.ftp.ftp.repository.FTPCalculationResultRepository;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 结果导出服务
 */
@Service
@RequiredArgsConstructor
public class ResultExportService {

    private final FTPCalculationResultRepository ftpCalculationResultRepository;

    /**
     * 导出为Excel格式
     */
    public byte[] exportToExcel(Long taskId) throws IOException {
        List<FTPCalculationResult> results = ftpCalculationResultRepository.findByTaskId(taskId);
        return exportResultsToExcel(results);
    }

    /**
     * 导出结果为Excel
     */
    private byte[] exportResultsToExcel(List<FTPCalculationResult> results) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("FTP计算结果");

            // 创建标题行样式
            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);

            // 创建标题行
            Row headerRow = sheet.createRow(0);
            String[] headers = {"ID", "任务ID", "交易ID", "交易编号", "定价日期", "基础利率", 
                               "总调整", "最终FTP利率", "FTP成本", "曲线ID", "定价方法"};
            
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // 填充数据行
            int rowNum = 1;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            
            for (FTPCalculationResult result : results) {
                Row row = sheet.createRow(rowNum++);
                
                row.createCell(0).setCellValue(result.getId());
                row.createCell(1).setCellValue(result.getTaskId());
                row.createCell(2).setCellValue(result.getTransactionId());
                row.createCell(3).setCellValue(result.getTransactionNo());
                row.createCell(4).setCellValue(result.getPricingDate().format(formatter));
                
                Cell baseRateCell = row.createCell(5);
                if (result.getBaseRate() != null) {
                    baseRateCell.setCellValue(result.getBaseRate().doubleValue());
                }
                
                Cell totalAdjCell = row.createCell(6);
                if (result.getTotalAdjustment() != null) {
                    totalAdjCell.setCellValue(result.getTotalAdjustment().doubleValue());
                }
                
                Cell finalRateCell = row.createCell(7);
                if (result.getFinalFtpRate() != null) {
                    finalRateCell.setCellValue(result.getFinalFtpRate().doubleValue());
                }
                
                Cell ftpCostCell = row.createCell(8);
                if (result.getFtpCost() != null) {
                    ftpCostCell.setCellValue(result.getFtpCost().doubleValue());
                }
                
                if (result.getCurveId() != null) {
                    row.createCell(9).setCellValue(result.getCurveId());
                }
                
                if (result.getPricingMethod() != null) {
                    row.createCell(10).setCellValue(result.getPricingMethod());
                }
            }

            // 自动调整列宽
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // 写入字节数组
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return outputStream.toByteArray();
        }
    }

    /**
     * 导出为CSV格式
     */
    public String exportToCsv(Long taskId) {
        List<FTPCalculationResult> results = ftpCalculationResultRepository.findByTaskId(taskId);
        return exportResultsToCsv(results);
    }

    /**
     * 导出结果为CSV
     */
    private String exportResultsToCsv(List<FTPCalculationResult> results) {
        StringBuilder csv = new StringBuilder();
        csv.append("ID,任务ID,交易ID,交易编号,定价日期,基础利率,总调整,最终FTP利率,FTP成本,曲线ID,定价方法\n");
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        
        for (FTPCalculationResult result : results) {
            csv.append(result.getId()).append(",");
            csv.append(result.getTaskId()).append(",");
            csv.append(result.getTransactionId()).append(",");
            csv.append("\"").append(result.getTransactionNo()).append("\",");
            csv.append(result.getPricingDate().format(formatter)).append(",");
            
            csv.append(result.getBaseRate() != null ? result.getBaseRate().doubleValue() : "").append(",");
            csv.append(result.getTotalAdjustment() != null ? result.getTotalAdjustment().doubleValue() : "").append(",");
            csv.append(result.getFinalFtpRate() != null ? result.getFinalFtpRate().doubleValue() : "").append(",");
            csv.append(result.getFtpCost() != null ? result.getFtpCost().doubleValue() : "").append(",");
            csv.append(result.getCurveId() != null ? result.getCurveId() : "").append(",");
            csv.append(result.getPricingMethod() != null ? result.getPricingMethod() : "");
            csv.append("\n");
        }
        
        return csv.toString();
    }
}