package com.bank.ftp.ftp.repository;

import com.bank.ftp.ftp.entity.PricingCurveRule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PricingCurveRuleRepository extends JpaRepository<PricingCurveRule, Long> {
    Optional<PricingCurveRule> findByRuleCode(String ruleCode);
    boolean existsByRuleCode(String ruleCode);
    List<PricingCurveRule> findByStatusOrderByPriorityDesc(Integer status);
}
