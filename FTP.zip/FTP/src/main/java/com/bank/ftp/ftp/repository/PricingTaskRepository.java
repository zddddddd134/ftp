package com.bank.ftp.ftp.repository;

import com.bank.ftp.ftp.entity.PricingTask;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PricingTaskRepository extends JpaRepository<PricingTask, Long> {
    Optional<PricingTask> findByTaskCode(String taskCode);
    boolean existsByTaskCode(String taskCode);
    List<PricingTask> findByStatus(Integer status);
}
