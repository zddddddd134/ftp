package com.bank.ftp.ftp.repository;

import com.bank.ftp.ftp.entity.RuleVersion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RuleVersionRepository extends JpaRepository<RuleVersion, Long> {
    List<RuleVersion> findByRuleTypeAndRuleIdOrderByVersionNoDesc(String ruleType, Long ruleId);
    List<RuleVersion> findByRuleCode(String ruleCode);
}
