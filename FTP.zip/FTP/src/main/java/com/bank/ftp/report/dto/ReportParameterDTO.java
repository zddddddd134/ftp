package com.bank.ftp.report.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ReportParameterDTO {
    private Long id;

    @NotNull(message = "报表ID不能为空")
    private Long reportId;

    @NotBlank(message = "参数名称不能为空")
    private String paramName;

    @NotBlank(message = "参数编码不能为空")
    private String paramCode;

    @NotBlank(message = "参数类型不能为空")
    private String paramType;

    private String paramDefaultValue;

    private String paramOptions;

    private Integer required = 0;

    private Integer sortOrder = 0;
}