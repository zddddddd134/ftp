package com.bank.ftp.parameter.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.parameter.dto.OrganizationDTO;
import com.bank.ftp.parameter.entity.Organization;
import com.bank.ftp.parameter.repository.OrganizationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrganizationService {

    private final OrganizationRepository organizationRepository;

    public List<Organization> getAllOrganizations() {
        return organizationRepository.findAll();
    }

    public List<Organization> getActiveOrganizations() {
        return organizationRepository.findByStatus(1);
    }

    public Organization getOrganizationById(Long id) {
        return organizationRepository.findById(id)
                .orElseThrow(() -> new BusinessException("机构不存在"));
    }

    public List<Organization> getOrganizationsByParentId(Long parentId) {
        return organizationRepository.findByParentId(parentId);
    }

    public List<Organization> getOrganizationTree() {
        List<Organization> allOrgs = getActiveOrganizations();
        List<Organization> rootOrgs = new ArrayList<>();
        for (Organization org : allOrgs) {
            if (org.getParentId() == 0L) {
                rootOrgs.add(org);
            }
        }
        return rootOrgs;
    }

    @Transactional
    public Organization createOrganization(OrganizationDTO orgDTO) {
        if (organizationRepository.existsByOrgCode(orgDTO.getOrgCode())) {
            throw new BusinessException("机构编码已存在");
        }

        Organization org = new Organization();
        BeanUtils.copyProperties(orgDTO, org);
        
        if (orgDTO.getParentId() != null && orgDTO.getParentId() != 0L) {
            Organization parentOrg = getOrganizationById(orgDTO.getParentId());
            org.setLevel(parentOrg.getLevel() + 1);
        }
        
        return organizationRepository.save(org);
    }

    @Transactional
    public Organization updateOrganization(Long id, OrganizationDTO orgDTO) {
        Organization org = getOrganizationById(id);
        
        if (!org.getOrgCode().equals(orgDTO.getOrgCode()) && 
            organizationRepository.existsByOrgCode(orgDTO.getOrgCode())) {
            throw new BusinessException("机构编码已存在");
        }

        org.setOrgName(orgDTO.getOrgName());
        org.setOrgType(orgDTO.getOrgType());
        
        if (orgDTO.getParentId() != null && !orgDTO.getParentId().equals(org.getParentId())) {
            org.setParentId(orgDTO.getParentId());
            if (orgDTO.getParentId() == 0L) {
                org.setLevel(1);
            } else {
                Organization parentOrg = getOrganizationById(orgDTO.getParentId());
                org.setLevel(parentOrg.getLevel() + 1);
            }
        }
        
        org.setSortOrder(orgDTO.getSortOrder());
        org.setStatus(orgDTO.getStatus());
        
        return organizationRepository.save(org);
    }

    @Transactional
    public void deleteOrganization(Long id) {
        Organization org = getOrganizationById(id);
        List<Organization> children = getOrganizationsByParentId(id);
        if (!children.isEmpty()) {
            throw new BusinessException("请先删除下级机构");
        }
        org.setDeleted(1);
        organizationRepository.save(org);
    }
}
