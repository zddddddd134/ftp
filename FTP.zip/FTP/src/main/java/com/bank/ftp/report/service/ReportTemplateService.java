package com.bank.ftp.report.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.report.dto.ReportTemplateDTO;
import com.bank.ftp.report.entity.ReportTemplate;
import com.bank.ftp.report.repository.ReportTemplateRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

/**
 * 报表模板服务
 */
@Service
@RequiredArgsConstructor
public class ReportTemplateService {

    private final ReportTemplateRepository reportTemplateRepository;

    /**
     * 获取所有模板
     */
    public List<ReportTemplate> getAllTemplates() {
        return reportTemplateRepository.findAll();
    }

    /**
     * 根据ID获取模板
     */
    public ReportTemplate getTemplateById(Long id) {
        return reportTemplateRepository.findById(id)
                .orElseThrow(() -> new BusinessException("报表模板不存在"));
    }

    /**
     * 创建报表模板
     */
    @Transactional
    public ReportTemplate createTemplate(ReportTemplateDTO templateDTO) throws IOException {
        ReportTemplate template = new ReportTemplate();
        BeanUtils.copyProperties(templateDTO, template, "templateFile");

        // 处理上传的文件
        if (templateDTO.getTemplateFile() != null) {
            MultipartFile file = templateDTO.getTemplateFile();
            template.setTemplateFile(file.getBytes());
            template.setFileName(file.getOriginalFilename());
        }

        return reportTemplateRepository.save(template);
    }

    /**
     * 更新报表模板
     */
    @Transactional
    public ReportTemplate updateTemplate(Long id, ReportTemplateDTO templateDTO) throws IOException {
        ReportTemplate template = getTemplateById(id);

        BeanUtils.copyProperties(templateDTO, template, "templateFile");

        // 处理上传的文件
        if (templateDTO.getTemplateFile() != null) {
            MultipartFile file = templateDTO.getTemplateFile();
            template.setTemplateFile(file.getBytes());
            template.setFileName(file.getOriginalFilename());
        }

        return reportTemplateRepository.save(template);
    }

    /**
     * 删除报表模板
     */
    @Transactional
    public void deleteTemplate(Long id) {
        reportTemplateRepository.deleteById(id);
    }

    /**
     * 获取模板文件
     */
    public byte[] getTemplateFile(Long id) {
        ReportTemplate template = getTemplateById(id);
        return template.getTemplateFile();
    }
}