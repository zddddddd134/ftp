package com.bank.ftp.ftp.calculator.matcher;

import com.bank.ftp.ftp.entity.BusinessTransaction;
import com.bank.ftp.ftp.entity.PricingMethodRule;
import com.bank.ftp.ftp.entity.PricingCurveRule;
import com.bank.ftp.ftp.entity.AdjustmentRule;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 规则匹配器实现
 */
@Component
@RequiredArgsConstructor
public class RuleMatcherImpl implements RuleMatcher {
    
    private final ObjectMapper objectMapper;

    @Override
    public PricingMethodRule matchPricingMethodRule(BusinessTransaction transaction, List<PricingMethodRule> rules) {
        return rules.stream()
                .filter(rule -> isRuleMatch(transaction, rule))
                .max((r1, r2) -> Integer.compare(r1.getPriority(), r2.getPriority()))
                .orElse(null);
    }

    @Override
    public PricingCurveRule matchPricingCurveRule(BusinessTransaction transaction, List<PricingCurveRule> rules) {
        return rules.stream()
                .filter(rule -> isRuleMatch(transaction, rule))
                .max((r1, r2) -> Integer.compare(r1.getPriority(), r2.getPriority()))
                .orElse(null);
    }

    @Override
    public List<AdjustmentRule> matchAdjustmentRules(BusinessTransaction transaction, List<AdjustmentRule> rules) {
        return rules.stream()
                .filter(rule -> isRuleMatch(transaction, rule))
                .sorted((r1, r2) -> Integer.compare(r2.getPriority(), r1.getPriority())) // 优先级高的在前
                .collect(Collectors.toList());
    }

    /**
     * 检查交易是否匹配规则条件
     */
    private boolean isRuleMatch(BusinessTransaction transaction, Object rule) {
        if (rule instanceof PricingMethodRule methodRule) {
            return isRuleMatch(transaction, methodRule);
        } else if (rule instanceof PricingCurveRule curveRule) {
            return isRuleMatch(transaction, curveRule);
        } else if (rule instanceof AdjustmentRule adjustmentRule) {
            return isRuleMatch(transaction, adjustmentRule);
        }
        return false;
    }

    private boolean isRuleMatch(BusinessTransaction transaction, PricingMethodRule rule) {
        // 检查产品类型匹配
        if (rule.getProductTypeIds() != null && !rule.getProductTypeIds().isEmpty()) {
            List<Long> productTypeIds = parseJsonToList(rule.getProductTypeIds());
            if (productTypeIds != null && !productTypeIds.contains(transaction.getProductTypeId())) {
                return false;
            }
        }

        // 检查机构匹配
        if (rule.getOrgIds() != null && !rule.getOrgIds().isEmpty() && transaction.getOrgId() != null) {
            List<Long> orgIds = parseJsonToList(rule.getOrgIds());
            if (orgIds != null && !orgIds.contains(transaction.getOrgId())) {
                return false;
            }
        }

        // 检查金额范围
        if (rule.getAmountMin() != null && transaction.getAmount().compareTo(rule.getAmountMin()) < 0) {
            return false;
        }
        if (rule.getAmountMax() != null && transaction.getAmount().compareTo(rule.getAmountMax()) > 0) {
            return false;
        }

        // 检查期限范围
        if (rule.getTermMin() != null && transaction.getTerm() != null && transaction.getTerm() < rule.getTermMin()) {
            return false;
        }
        if (rule.getTermMax() != null && transaction.getTerm() != null && transaction.getTerm() > rule.getTermMax()) {
            return false;
        }

        return true;
    }

    private boolean isRuleMatch(BusinessTransaction transaction, PricingCurveRule rule) {
        // 检查产品类型匹配
        if (rule.getProductTypeIds() != null && !rule.getProductTypeIds().isEmpty()) {
            List<Long> productTypeIds = parseJsonToList(rule.getProductTypeIds());
            if (productTypeIds != null && !productTypeIds.contains(transaction.getProductTypeId())) {
                return false;
            }
        }

        // 检查机构匹配
        if (rule.getOrgIds() != null && !rule.getOrgIds().isEmpty() && transaction.getOrgId() != null) {
            List<Long> orgIds = parseJsonToList(rule.getOrgIds());
            if (orgIds != null && !orgIds.contains(transaction.getOrgId())) {
                return false;
            }
        }

        // 检查金额范围
        if (rule.getAmountMin() != null && transaction.getAmount().compareTo(rule.getAmountMin()) < 0) {
            return false;
        }
        if (rule.getAmountMax() != null && transaction.getAmount().compareTo(rule.getAmountMax()) > 0) {
            return false;
        }

        // 检查期限范围
        if (rule.getTermMin() != null && transaction.getTerm() != null && transaction.getTerm() < rule.getTermMin()) {
            return false;
        }
        if (rule.getTermMax() != null && transaction.getTerm() != null && transaction.getTerm() > rule.getTermMax()) {
            return false;
        }

        return true;
    }

    private boolean isRuleMatch(BusinessTransaction transaction, AdjustmentRule rule) {
        // 检查产品类型匹配
        if (rule.getProductTypeIds() != null && !rule.getProductTypeIds().isEmpty()) {
            List<Long> productTypeIds = parseJsonToList(rule.getProductTypeIds());
            if (productTypeIds != null && !productTypeIds.contains(transaction.getProductTypeId())) {
                return false;
            }
        }

        // 检查机构匹配
        if (rule.getOrgIds() != null && !rule.getOrgIds().isEmpty() && transaction.getOrgId() != null) {
            List<Long> orgIds = parseJsonToList(rule.getOrgIds());
            if (orgIds != null && !orgIds.contains(transaction.getOrgId())) {
                return false;
            }
        }

        // 检查金额范围
        if (rule.getAmountMin() != null && transaction.getAmount().compareTo(rule.getAmountMin()) < 0) {
            return false;
        }
        if (rule.getAmountMax() != null && transaction.getAmount().compareTo(rule.getAmountMax()) > 0) {
            return false;
        }

        // 检查期限范围
        if (rule.getTermMin() != null && transaction.getTerm() != null && transaction.getTerm() < rule.getTermMin()) {
            return false;
        }
        if (rule.getTermMax() != null && transaction.getTerm() != null && transaction.getTerm() > rule.getTermMax()) {
            return false;
        }

        return true;
    }

    private List<Long> parseJsonToList(String jsonStr) {
        if (jsonStr == null || jsonStr.isEmpty()) {
            return new ArrayList<>();
        }
        try {
            return objectMapper.readValue(jsonStr, new TypeReference<List<Long>>() {});
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}
