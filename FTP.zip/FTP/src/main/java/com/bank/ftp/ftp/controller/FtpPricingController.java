package com.bank.ftp.ftp.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.ftp.dto.BatchPricingRequest;
import com.bank.ftp.ftp.dto.PricingAnalysisDTO;
import com.bank.ftp.ftp.dto.PricingResultQueryDTO;
import com.bank.ftp.ftp.entity.FTPCalculationResult;
import com.bank.ftp.ftp.entity.PricingTask;
import com.bank.ftp.ftp.service.pricing.BatchPricingService;
import com.bank.ftp.ftp.service.pricing.PricingMonitorService;
import com.bank.ftp.ftp.service.result.FtpResultQueryService;
import com.bank.ftp.ftp.service.result.ResultAnalysisService;
import com.bank.ftp.ftp.service.result.ResultExportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@Tag(name = "FTP定价管理", description = "FTP定价相关接口")
@RestController
@RequestMapping("/ftp/pricing")
@RequiredArgsConstructor
public class FtpPricingController {

    private final BatchPricingService batchPricingService;
    private final PricingMonitorService pricingMonitorService;
    private final FtpResultQueryService ftpResultQueryService;
    private final ResultAnalysisService resultAnalysisService;
    private final ResultExportService resultExportService;

    @Operation(summary = "执行批量定价")
    @PostMapping("/batch")
    public Result<PricingTask> executeBatchPricing(@Valid @RequestBody BatchPricingRequest request) {
        return Result.success(batchPricingService.executeBatchPricing(request));
    }

    @Operation(summary = "获取任务监控信息")
    @GetMapping("/monitor/{taskId}")
    public Result<PricingMonitorService.TaskStatistics> getTaskMonitorInfo(@PathVariable Long taskId) {
        return Result.success(pricingMonitorService.getTaskStatistics(taskId));
    }

    @Operation(summary = "获取所有任务监控信息")
    @GetMapping("/monitor/list")
    public Result<List<PricingTask>> getAllTasksMonitorInfo() {
        return Result.success(pricingMonitorService.getAllTasksMonitorInfo());
    }

    @Operation(summary = "获取任务进度")
    @GetMapping("/progress/{taskId}")
    public Result<Integer> getTaskProgress(@PathVariable Long taskId) {
        return Result.success(pricingMonitorService.getTaskProgress(taskId));
    }

    @Operation(summary = "根据任务ID获取结果")
    @GetMapping("/results/task/{taskId}")
    public Result<List<FTPCalculationResult>> getResultsByTaskId(@PathVariable Long taskId) {
        return Result.success(ftpResultQueryService.getResultsByTaskId(taskId));
    }

    @Operation(summary = "根据交易ID获取结果")
    @GetMapping("/results/transaction/{transactionId}")
    public Result<List<FTPCalculationResult>> getResultsByTransactionId(@PathVariable Long transactionId) {
        return Result.success(ftpResultQueryService.getResultsByTransactionId(transactionId));
    }

    @Operation(summary = "多维度查询结果")
    @PostMapping("/results/query")
    public Result<Page<FTPCalculationResult>> queryResults(@Valid @RequestBody PricingResultQueryDTO query) {
        return Result.success(ftpResultQueryService.getResultsByCondition(query));
    }

    @Operation(summary = "生成分析报告")
    @GetMapping("/analysis/{taskId}")
    public Result<PricingAnalysisDTO> generateAnalysisReport(@PathVariable Long taskId) {
        return Result.success(resultAnalysisService.generateAnalysisReport(taskId));
    }

    @Operation(summary = "导出结果为Excel")
    @GetMapping("/export/excel/{taskId}")
    public void exportToExcel(@PathVariable Long taskId, HttpServletResponse response) throws IOException {
        byte[] excelData = resultExportService.exportToExcel(taskId);
        
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=ftp_results_" + taskId + ".xlsx");
        response.getOutputStream().write(excelData);
        response.getOutputStream().flush();
    }

    @Operation(summary = "导出结果为CSV")
    @GetMapping("/export/csv/{taskId}")
    public void exportToCsv(@PathVariable Long taskId, HttpServletResponse response) throws IOException {
        String csvData = resultExportService.exportToCsv(taskId);
        
        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=ftp_results_" + taskId + ".csv");
        response.getWriter().write(csvData);
        response.getWriter().flush();
    }
}