package com.bank.ftp.system.service;

import com.bank.ftp.common.exception.BusinessException;
import com.bank.ftp.common.util.JwtUtil;
import com.bank.ftp.system.dto.LoginResponse;
import com.bank.ftp.system.dto.LoginRequest;
import com.bank.ftp.system.entity.User;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthenticationService {

    private final UserService userService;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;

    @Value("${jwt.expiration:86400}")
    private Long expiration;

    public LoginResponse authenticate(LoginRequest loginRequest) {
        // 从数据库查找用户
        User user = userService.getUserByUsername(loginRequest.getUsername());

        if (user == null) {
            throw new BusinessException("用户名不存在");
        }
        
        // 检查用户是否已被删除
        if (user.getDeleted() != null && user.getDeleted() == 1) {
            throw new BusinessException("用户账户已被删除，无法登录");
        }

        // 验证密码
        if (!passwordEncoder.matches(loginRequest.getPassword(), user.getPassword())) {
            throw new BusinessException("密码错误");
        }

        // 更新最后登录时间
        user.setLastLoginTime(java.time.LocalDateTime.now());
        userService.updateUserLoginTime(user);

        // 生成JWT token
        String token = jwtUtil.generateToken(user.getUsername());

        return new LoginResponse(token, expiration, user.getUsername(), user.getRealName());
    }
}