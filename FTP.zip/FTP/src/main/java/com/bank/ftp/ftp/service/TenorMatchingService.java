package com.bank.ftp.ftp.service;

import com.bank.ftp.ftp.entity.BusinessTransaction;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * 期限匹配算法服务
 * 用于将资产和负债按期限进行匹配，准确反映银行的期限错配风险
 */
@Service
@RequiredArgsConstructor
public class TenorMatchingService {

    /**
     * 计算交易的期限（天数）
     */
    public Integer calculateTerm(BusinessTransaction transaction) {
        if (transaction.getTerm() != null) {
            return transaction.getTerm();
        }

        if (transaction.getStartDate() != null && transaction.getEndDate() != null) {
            return Math.toIntExact(ChronoUnit.DAYS.between(transaction.getStartDate(), transaction.getEndDate()));
        }

        return null;
    }

    /**
     * 按期限分组交易
     */
    public java.util.Map<Integer, List<BusinessTransaction>> groupByTerm(List<BusinessTransaction> transactions) {
        return transactions.stream()
                .collect(java.util.stream.Collectors.groupingBy(this::calculateTerm));
    }

    /**
     * 计算期限错配风险
     * 返回正数表示资产期限长于负债期限，负数表示负债期限长于资产期限
     */
    public java.math.BigDecimal calculateTenorMismatchRisk(
            List<BusinessTransaction> assets, 
            List<BusinessTransaction> liabilities) {
        
        // 按期限汇总资产和负债
        var assetMap = sumByTerm(assets);
        var liabilityMap = sumByTerm(liabilities);

        // 计算期限错配
        java.math.BigDecimal totalMismatch = java.math.BigDecimal.ZERO;
        
        // 对于每个期限，计算资产与负债的差额
        for (Integer term : assetMap.keySet()) {
            java.math.BigDecimal assetAmount = assetMap.getOrDefault(term, java.math.BigDecimal.ZERO);
            java.math.BigDecimal liabilityAmount = liabilityMap.getOrDefault(term, java.math.BigDecimal.ZERO);
            java.math.BigDecimal mismatch = assetAmount.subtract(liabilityAmount);
            totalMismatch = totalMismatch.add(mismatch);
        }

        // 对于只有负债没有对应资产的期限
        for (Integer term : liabilityMap.keySet()) {
            if (!assetMap.containsKey(term)) {
                java.math.BigDecimal liabilityAmount = liabilityMap.get(term);
                totalMismatch = totalMismatch.subtract(liabilityAmount);
            }
        }

        return totalMismatch;
    }

    /**
     * 按期限汇总交易金额
     */
    private java.util.Map<Integer, java.math.BigDecimal> sumByTerm(List<BusinessTransaction> transactions) {
        return transactions.stream()
                .collect(java.util.stream.Collectors.groupingBy(
                    this::calculateTerm,
                    java.util.stream.Collectors.reducing(
                        java.math.BigDecimal.ZERO,
                        BusinessTransaction::getAmount,
                        java.math.BigDecimal::add
                    )
                ));
    }

    /**
     * 生成期限匹配报告
     */
    public String generateTenorMatchingReport(List<BusinessTransaction> assets, List<BusinessTransaction> liabilities) {
        StringBuilder report = new StringBuilder();
        report.append("期限匹配分析报告\n");
        report.append("==================\n");

        var assetMap = sumByTerm(assets);
        var liabilityMap = sumByTerm(liabilities);

        // 获取所有期限
        var allTerms = new java.util.TreeSet<>(assetMap.keySet());
        allTerms.addAll(liabilityMap.keySet());

        for (Integer term : allTerms) {
            java.math.BigDecimal assetAmount = assetMap.getOrDefault(term, java.math.BigDecimal.ZERO);
            java.math.BigDecimal liabilityAmount = liabilityMap.getOrDefault(term, java.math.BigDecimal.ZERO);
            java.math.BigDecimal netPosition = assetAmount.subtract(liabilityAmount);

            report.append(String.format("期限 %d天: 资产 %.2f, 负债 %.2f, 净头寸 %.2f\n",
                    term, 
                    assetAmount.doubleValue(), 
                    liabilityAmount.doubleValue(), 
                    netPosition.doubleValue()));
        }

        java.math.BigDecimal totalMismatch = calculateTenorMismatchRisk(assets, liabilities);
        report.append(String.format("\n总体期限错配: %.2f\n", totalMismatch.doubleValue()));

        return report.toString();
    }
}
