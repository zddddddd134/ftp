package com.bank.ftp.ftp.repository;

import com.bank.ftp.ftp.entity.RateCurve;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RateCurveRepository extends JpaRepository<RateCurve, Long> {
    Optional<RateCurve> findByCurveCode(String curveCode);
    boolean existsByCurveCode(String curveCode);
    List<RateCurve> findByStatus(Integer status);
}
