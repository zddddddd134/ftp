package com.bank.ftp.parameter.entity;

import com.bank.ftp.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "param_caliber")
public class Caliber extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "caliber_code", nullable = false, unique = true, length = 50)
    private String caliberCode;

    @Column(name = "caliber_name", nullable = false, length = 100)
    private String caliberName;

    @Column(name = "description", length = 500)
    private String description;

    @Column(name = "caliber_rule", columnDefinition = "TEXT")
    private String caliberRule;

    @Column(name = "status")
    private Integer status = 1;
}
