package com.bank.ftp.ftp.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class RuleVersionDTO {
    private Long id;

    @NotBlank(message = "规则类型不能为空")
    private String ruleType;

    @NotNull(message = "规则ID不能为空")
    private Long ruleId;

    @NotBlank(message = "规则编码不能为空")
    private String ruleCode;

    @NotNull(message = "版本号不能为空")
    private Integer versionNo;

    @NotBlank(message = "规则内容不能为空")
    private String ruleContent;

    private String description;
}
