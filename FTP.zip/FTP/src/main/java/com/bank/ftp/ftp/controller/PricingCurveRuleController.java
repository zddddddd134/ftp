package com.bank.ftp.ftp.controller;

import com.bank.ftp.common.response.Result;
import com.bank.ftp.ftp.dto.PricingCurveRuleDTO;
import com.bank.ftp.ftp.entity.PricingCurveRule;
import com.bank.ftp.ftp.service.rule.PricingCurveRuleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "定价曲线规则管理", description = "定价曲线匹配规则相关接口")
@RestController
@RequestMapping("/ftp/rule/curve")
@RequiredArgsConstructor
public class PricingCurveRuleController {

    private final PricingCurveRuleService pricingCurveRuleService;

    @Operation(summary = "获取所有定价曲线规则")
    @GetMapping("/list")
    public Result<List<PricingCurveRule>> getAllRules() {
        return Result.success(pricingCurveRuleService.getAllRules());
    }

    @Operation(summary = "获取启用的定价曲线规则")
    @GetMapping("/active")
    public Result<List<PricingCurveRule>> getActiveRules() {
        return Result.success(pricingCurveRuleService.getActiveRules());
    }

    @Operation(summary = "根据ID获取定价曲线规则")
    @GetMapping("/{id}")
    public Result<PricingCurveRule> getRuleById(@PathVariable Long id) {
        return Result.success(pricingCurveRuleService.getRuleById(id));
    }

    @Operation(summary = "创建定价曲线规则")
    @PostMapping
    public Result<PricingCurveRule> createRule(@Valid @RequestBody PricingCurveRuleDTO ruleDTO) {
        return Result.success(pricingCurveRuleService.createRule(ruleDTO));
    }

    @Operation(summary = "更新定价曲线规则")
    @PutMapping("/{id}")
    public Result<PricingCurveRule> updateRule(@PathVariable Long id, @Valid @RequestBody PricingCurveRuleDTO ruleDTO) {
        return Result.success(pricingCurveRuleService.updateRule(id, ruleDTO));
    }

    @Operation(summary = "删除定价曲线规则")
    @DeleteMapping("/{id}")
    public Result<Void> deleteRule(@PathVariable Long id) {
        pricingCurveRuleService.deleteRule(id);
        return Result.success();
    }
}
