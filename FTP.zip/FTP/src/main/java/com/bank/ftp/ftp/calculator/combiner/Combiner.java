package com.bank.ftp.ftp.calculator.combiner;

import com.bank.ftp.ftp.entity.BusinessTransaction;
import com.bank.ftp.ftp.entity.CombinationPricingRule;

import java.math.BigDecimal;

/**
 * 组合定价器接口
 */
public interface Combiner {
    /**
     * 组合定价计算
     * @param transaction 业务交易
     * @param rule 组合定价规则
     * @return 最终FTP价格
     */
    BigDecimal combine(BusinessTransaction transaction, CombinationPricingRule rule);
}
