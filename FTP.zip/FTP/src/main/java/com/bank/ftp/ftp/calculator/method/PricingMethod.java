package com.bank.ftp.ftp.calculator.method;

import com.bank.ftp.ftp.entity.BusinessTransaction;

import java.math.BigDecimal;

/**
 * 定价方法接口
 */
public interface PricingMethod {
    /**
     * 计算FTP价格
     * @param transaction 业务交易
     * @return FTP价格
     */
    BigDecimal calculateFtpPrice(BusinessTransaction transaction);

    /**
     * 获取定价方法名称
     * @return 方法名称
     */
    String getMethodName();
}
