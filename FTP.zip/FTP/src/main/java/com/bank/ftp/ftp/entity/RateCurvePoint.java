package com.bank.ftp.ftp.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "ftp_rate_curve_point")
public class RateCurvePoint implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "curve_id", nullable = false)
    private Long curveId;

    @Column(name = "term", nullable = false)
    private Integer term;

    @Column(name = "term_unit", length = 10)
    private String termUnit = "day";

    @Column(name = "term_display", length = 50)
    private String termDisplay;

    @Column(name = "rate", nullable = false, precision = 10, scale = 6)
    private BigDecimal rate;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_time", updatable = false)
    @CreationTimestamp
    private LocalDateTime createdTime;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_time")
    @UpdateTimestamp
    private LocalDateTime updatedTime;
}
