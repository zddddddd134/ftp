-- 公共参数模块表结构

-- 币种表
CREATE TABLE IF NOT EXISTS param_currency (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '币种ID',
    currency_code VARCHAR(10) NOT NULL UNIQUE COMMENT '币种编码',
    currency_name VARCHAR(50) NOT NULL COMMENT '币种名称',
    currency_symbol VARCHAR(10) COMMENT '币种符号',
    decimal_places INT DEFAULT 2 COMMENT '小数位数',
    is_default INT DEFAULT 0 COMMENT '是否默认：0-否，1-是',
    status INT DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted INT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='币种表';

-- 汇率表
CREATE TABLE IF NOT EXISTS param_exchange_rate (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '汇率ID',
    source_currency_id BIGINT NOT NULL COMMENT '源币种ID',
    target_currency_id BIGINT NOT NULL COMMENT '目标币种ID',
    exchange_rate DECIMAL(20, 8) NOT NULL COMMENT '汇率',
    rate_date DATE NOT NULL COMMENT '汇率日期',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    UNIQUE KEY uk_currency_date (source_currency_id, target_currency_id, rate_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='汇率表';

-- 统计口径表
CREATE TABLE IF NOT EXISTS param_caliber (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '口径ID',
    caliber_code VARCHAR(50) NOT NULL UNIQUE COMMENT '口径编码',
    caliber_name VARCHAR(100) NOT NULL COMMENT '口径名称',
    description VARCHAR(500) COMMENT '口径描述',
    caliber_rule TEXT COMMENT '口径规则定义',
    status INT DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted INT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='统计口径表';

-- 机构表
CREATE TABLE IF NOT EXISTS param_organization (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '机构ID',
    org_code VARCHAR(50) NOT NULL UNIQUE COMMENT '机构编码',
    org_name VARCHAR(100) NOT NULL COMMENT '机构名称',
    org_type VARCHAR(20) COMMENT '机构类型',
    parent_id BIGINT DEFAULT 0 COMMENT '父机构ID',
    level INT DEFAULT 1 COMMENT '机构层级',
    sort_order INT DEFAULT 0 COMMENT '排序',
    status INT DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted INT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除',
    INDEX idx_parent_id (parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='机构表';
