-- 资金转移定价模块表结构

-- 利率曲线主表
CREATE TABLE IF NOT EXISTS ftp_rate_curve (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '曲线ID',
    curve_code VARCHAR(50) NOT NULL UNIQUE COMMENT '曲线编码',
    curve_name VARCHAR(100) NOT NULL COMMENT '曲线名称',
    curve_type VARCHAR(20) NOT NULL COMMENT '曲线类型：treasury-国债，shibor-Shibor，deposit-存款，loan-贷款等',
    currency_id BIGINT NOT NULL COMMENT '币种ID',
    description VARCHAR(500) COMMENT '曲线描述',
    status INT  DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted INT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='利率曲线主表';

-- 利率曲线点数表
CREATE TABLE IF NOT EXISTS ftp_rate_curve_point (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '点ID',
    curve_id BIGINT NOT NULL COMMENT '曲线ID',
    term INT NOT NULL COMMENT '期限（天）',
    term_unit VARCHAR(10) DEFAULT 'day' COMMENT '期限单位：day-天，month-月，year-年',
    term_display VARCHAR(50) COMMENT '期限显示名称',
    rate DECIMAL(10, 6) NOT NULL COMMENT '利率值',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_curve_id (curve_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='利率曲线点数表';

-- 产品类型表
CREATE TABLE IF NOT EXISTS ftp_product_type (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '产品类型ID',
    product_code VARCHAR(50) NOT NULL UNIQUE COMMENT '产品编码',
    product_name VARCHAR(100) NOT NULL COMMENT '产品名称',
    product_category VARCHAR(50) COMMENT '产品大类：deposit-存款，loan-贷款等',
    description VARCHAR(500) COMMENT '产品描述',
    status INT  DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted INT  DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='产品类型表';

-- 业务交易表
CREATE TABLE IF NOT EXISTS ftp_business_transaction (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '交易ID',
    transaction_no VARCHAR(50) NOT NULL UNIQUE COMMENT '交易编号',
    product_type_id BIGINT NOT NULL COMMENT '产品类型ID',
    org_id BIGINT COMMENT '机构ID',
    currency_id BIGINT NOT NULL COMMENT '币种ID',
    amount DECIMAL(20, 2) NOT NULL COMMENT '交易金额',
    direction VARCHAR(10) NOT NULL COMMENT '方向：in-流入（存款），out-流出（贷款）',
    start_date DATE NOT NULL COMMENT '起息日',
    end_date DATE COMMENT '到期日',
    term INT COMMENT '期限（天）',
    interest_rate DECIMAL(10, 6) COMMENT '合同利率',
    status INT  DEFAULT 1 COMMENT '状态：1-正常，2-逾期',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_transaction_no (transaction_no),
    INDEX idx_product_type (product_type_id),
    INDEX idx_org_id (org_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='业务交易表';

-- 定价方法匹配规则表
CREATE TABLE IF NOT EXISTS ftp_pricing_method_rule (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '规则ID',
    rule_code VARCHAR(50) NOT NULL UNIQUE COMMENT '规则编码',
    rule_name VARCHAR(100) NOT NULL COMMENT '规则名称',
    pricing_method VARCHAR(50) NOT NULL COMMENT '定价方法：duration-期限匹配，pool-资金池，maturity-到期日匹配等',
    product_type_ids TEXT COMMENT '适用产品类型ID列表（JSON格式）',
    org_ids TEXT COMMENT '适用机构ID列表（JSON格式）',
    amount_min DECIMAL(20, 2) COMMENT '金额下限',
    amount_max DECIMAL(20, 2) COMMENT '金额上限',
    term_min INT COMMENT '期限下限（天）',
    term_max INT COMMENT '期限上限（天）',
    priority INT DEFAULT 0 COMMENT '优先级，数字越大优先级越高',
    status INT  DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted INT  DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='定价方法匹配规则表';

-- 定价曲线匹配规则表
CREATE TABLE IF NOT EXISTS ftp_pricing_curve_rule (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '规则ID',
    rule_code VARCHAR(50) NOT NULL UNIQUE COMMENT '规则编码',
    rule_name VARCHAR(100) NOT NULL COMMENT '规则名称',
    curve_id BIGINT NOT NULL COMMENT '利率曲线ID',
    product_type_ids TEXT COMMENT '适用产品类型ID列表（JSON格式）',
    org_ids TEXT COMMENT '适用机构ID列表（JSON格式）',
    amount_min DECIMAL(20, 2) COMMENT '金额下限',
    amount_max DECIMAL(20, 2) COMMENT '金额上限',
    term_min INT COMMENT '期限下限（天）',
    term_max INT COMMENT '期限上限（天）',
    priority INT DEFAULT 0 COMMENT '优先级，数字越大优先级越高',
    status INT  DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted INT  DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='定价曲线匹配规则表';

-- 调整项规则表
CREATE TABLE IF NOT EXISTS ftp_adjustment_rule (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '规则ID',
    rule_code VARCHAR(50) NOT NULL UNIQUE COMMENT '规则编码',
    rule_name VARCHAR(100) NOT NULL COMMENT '规则名称',
    adjustment_type VARCHAR(50) NOT NULL COMMENT '调整类型：liquidity-流动性，credit-信用，option-期权等',
    adjustment_value DECIMAL(10, 6) NOT NULL COMMENT '调整值（基点或百分比）',
    adjustment_mode VARCHAR(20) DEFAULT 'add' COMMENT '调整方式：add-加法，multiply-乘法',
    product_type_ids TEXT COMMENT '适用产品类型ID列表（JSON格式）',
    org_ids TEXT COMMENT '适用机构ID列表（JSON格式）',
    amount_min DECIMAL(20, 2) COMMENT '金额下限',
    amount_max DECIMAL(20, 2) COMMENT '金额上限',
    term_min INT COMMENT '期限下限（天）',
    term_max INT COMMENT '期限上限（天）',
    priority INT DEFAULT 0 COMMENT '优先级，数字越大优先级越高',
    status INT DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted INT  DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='调整项规则表';

-- 组合定价规则表
CREATE TABLE IF NOT EXISTS ftp_combination_pricing_rule (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '组合规则ID',
    rule_code VARCHAR(50) NOT NULL UNIQUE COMMENT '规则编码',
    rule_name VARCHAR(100) NOT NULL COMMENT '规则名称',
    method_rule_ids TEXT COMMENT '定价方法规则ID列表（JSON格式）',
    curve_rule_ids TEXT COMMENT '定价曲线规则ID列表（JSON格式）',
    adjustment_rule_ids TEXT COMMENT '调整项规则ID列表（JSON格式）',
    product_type_ids TEXT COMMENT '适用产品类型ID列表（JSON格式）',
    org_ids TEXT COMMENT '适用机构ID列表（JSON格式）',
    priority INT DEFAULT 0 COMMENT '优先级，数字越大优先级越高',
    status INT  DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted INT  DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='组合定价规则表';

-- 规则版本表
CREATE TABLE IF NOT EXISTS ftp_rule_version (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '版本ID',
    rule_type VARCHAR(50) NOT NULL COMMENT '规则类型：method-定价方法，curve-定价曲线，adjustment-调整项，combination-组合定价',
    rule_id BIGINT NOT NULL COMMENT '规则ID',
    rule_code VARCHAR(50) NOT NULL COMMENT '规则编码',
    version_no INT NOT NULL COMMENT '版本号',
    rule_content TEXT NOT NULL COMMENT '规则内容（JSON格式）',
    description VARCHAR(500) COMMENT '版本描述',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='规则版本表';

-- 定价任务表
CREATE TABLE IF NOT EXISTS ftp_pricing_task (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '任务ID',
    task_code VARCHAR(50) NOT NULL UNIQUE COMMENT '任务编码',
    task_name VARCHAR(100) NOT NULL COMMENT '任务名称',
    task_type VARCHAR(20) NOT NULL COMMENT '任务类型：manual-手动，schedule-定时',
    pricing_date DATETIME(6) NOT NULL COMMENT '定价日期',
    transaction_ids TEXT COMMENT '交易ID列表（JSON格式，空表示全部）',
    status INT  DEFAULT 1 COMMENT '状态：1-待执行，2-执行中，3-成功，4-失败',
    progress INT DEFAULT 0 COMMENT '进度（0-100）',
    total_count INT DEFAULT 0 COMMENT '总记录数',
    success_count INT DEFAULT 0 COMMENT '成功记录数',
    fail_count INT DEFAULT 0 COMMENT '失败记录数',
    error_message TEXT COMMENT '错误信息',
    start_time DATETIME COMMENT '开始时间',
    end_time DATETIME COMMENT '结束时间',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='定价任务表';

-- FTP计算结果表
CREATE TABLE IF NOT EXISTS ftp_calculation_result (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '结果ID',
    task_id BIGINT NOT NULL COMMENT '任务ID',
    transaction_id BIGINT NOT NULL COMMENT '交易ID',
    transaction_no VARCHAR(50) NOT NULL COMMENT '交易编号',
    pricing_date DATE NOT NULL COMMENT '定价日期',
    base_rate DECIMAL(10, 6) COMMENT '基准利率',
    adjustment_items TEXT COMMENT '调整项明细（JSON格式）',
    total_adjustment DECIMAL(10, 6) COMMENT '总调整值',
    final_ftp_rate DECIMAL(10, 6) NOT NULL COMMENT '最终FTP利率',
    ftp_cost DECIMAL(20, 2) COMMENT 'FTP成本/收益',
    curve_id BIGINT COMMENT '使用的曲线ID',
    pricing_method VARCHAR(50) COMMENT '使用的定价方法',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_task_id (task_id),
    INDEX idx_transaction_id (transaction_id),
    INDEX idx_pricing_date (pricing_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='FTP计算结果表';

-- 转移定价记录表
CREATE TABLE IF NOT EXISTS ftp_transfer_pricing_record (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '记录ID',
    transaction_id BIGINT NOT NULL COMMENT '交易ID',
    transaction_no VARCHAR(50) NOT NULL COMMENT '交易编号',
    pricing_date DATETIME(6) NOT NULL COMMENT '定价日期',
    org_id BIGINT COMMENT '机构ID',
    product_type_id BIGINT COMMENT '产品类型ID',
    amount DECIMAL(20, 2) NOT NULL COMMENT '金额',
    direction VARCHAR(10) NOT NULL COMMENT '方向：in-流入，out-流出',
    ftp_rate DECIMAL(10, 6) NOT NULL COMMENT 'FTP利率',
    ftp_amount DECIMAL(20, 2) COMMENT 'FTP金额',
    term INT COMMENT '期限（天）',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_transaction_id (transaction_id),
    INDEX idx_pricing_date (pricing_date),
    INDEX idx_org_id (org_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='转移定价记录表';
