-- 报表集成模块表结构

-- 报表定义表
CREATE TABLE IF NOT EXISTS rpt_definition (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '报表ID',
    report_code VARCHAR(50) NOT NULL UNIQUE COMMENT '报表编码',
    report_name VARCHAR(100) NOT NULL COMMENT '报表名称',
    description VARCHAR(500) COMMENT '报表描述',
    template_id BIGINT COMMENT '报表模板ID',
    data_source_config TEXT COMMENT '数据源配置',
    status INT DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted INT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='报表定义表';

-- 报表参数表
CREATE TABLE IF NOT EXISTS rpt_parameter (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '参数ID',
    report_id BIGINT NOT NULL COMMENT '报表ID',
    param_name VARCHAR(50) NOT NULL COMMENT '参数名称',
    param_code VARCHAR(50) NOT NULL COMMENT '参数编码',
    param_type VARCHAR(20) NOT NULL COMMENT '参数类型：string-字符串，number-数字，date-日期，select-下拉框',
    param_default_value VARCHAR(200) COMMENT '参数默认值',
    param_options TEXT COMMENT '参数选项（JSON格式）',
    required INT DEFAULT 0 COMMENT '是否必填：0-否，1-是',
    sort_order INT DEFAULT 0 COMMENT '排序',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='报表参数表';

-- 报表模板表
CREATE TABLE IF NOT EXISTS rpt_template (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '模板ID',
    template_name VARCHAR(100) NOT NULL COMMENT '模板名称',
    template_type VARCHAR(20) NOT NULL COMMENT '模板类型：excel-Excel，pdf-PDF',
    template_file LONGBLOB COMMENT '模板文件',
    file_name VARCHAR(200) COMMENT '文件名',
    status INT DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted INT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='报表模板表';

-- 报表调度表
CREATE TABLE IF NOT EXISTS rpt_schedule (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '调度ID',
    report_id BIGINT NOT NULL COMMENT '报表ID',
    schedule_name VARCHAR(100) NOT NULL COMMENT '调度名称',
    cron_expression VARCHAR(100) NOT NULL COMMENT 'Cron表达式',
    param_values TEXT COMMENT '参数值（JSON格式）',
    output_format VARCHAR(20) DEFAULT 'excel' COMMENT '输出格式：excel-Excel，pdf-PDF',
    email_recipients VARCHAR(500) COMMENT '邮件接收人',
    status INT DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    last_execution_time DATETIME COMMENT '最后执行时间',
    next_execution_time DATETIME COMMENT '下次执行时间',
    created_by BIGINT COMMENT '创建人',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_by BIGINT COMMENT '更新人',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted INT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='报表调度表';
