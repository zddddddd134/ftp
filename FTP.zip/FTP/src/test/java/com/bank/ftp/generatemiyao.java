package com.bank.ftp;
import io.jsonwebtoken.security.Keys;
import java.util.Base64;

public class generatemiyao {
    public static void main(String[] args) {
        var key = Keys.secretKeyFor(io.jsonwebtoken.SignatureAlgorithm.HS512);
        String secret = Base64.getEncoder().encodeToString(key.getEncoded());
        System.out.println("密钥：");
        System.out.println(secret);
    }
}
