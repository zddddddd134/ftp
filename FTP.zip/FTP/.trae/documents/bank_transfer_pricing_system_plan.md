# 银行内部资金转移定价系统开发计划

## 项目概述

本项目旨在开发一个银行内部资金转移定价（FTP, Funds Transfer Pricing）系统。该系统是银行内部管理资金成本和收益的核心工具，通过对不同资金来源和运用的精确计价，帮助银行优化资产负债结构，提升盈利能力。

## 当前状态分析

当前项目目录 `d:\ZDD\shixi\FTP` 为空，需要从零开始构建整个系统。这为我们提供了完全按照需求设计架构的机会。

## 系统功能需求

系统采用模块化设计，共分为4个主要功能模块，具备良好的扩展性以便后续新增模块。

### 1. 系统管理模块
- 用户管理：用户增删改查、角色权限管理
- 密码配置：密码策略设置、密码修改、密码重置
- 系统配置：系统参数管理、日志管理

### 2. 公共参数模块
- 币种管理：币种信息维护、汇率管理
- 口径管理：统计口径定义、口径规则配置
- 机构管理：机构信息维护、机构层级管理
- 其他公共参数：可扩展的公共参数配置

### 3. 报表集成模块
- 参数设置：报表参数配置、参数模板管理
- 报表设置：报表定义、报表权限配置
- 报表生成：报表调度、报表导出

### 4. 资金转移定价模块（核心模块）
#### 4.1 规则管理（可扩展）
- 定价方法匹配规则：定义不同业务场景下的定价方法选择规则
- 定价曲线匹配规则：定义业务与利率曲线的匹配规则
- 调整项规则：定义FTP价格的调整项规则（如流动性调整、信用调整等）
- 组合定价：支持多种定价规则的组合应用
- 规则优先级：规则执行顺序管理
- 规则版本管理：规则变更历史记录

#### 4.2 定价管理
- 定价任务管理：定价任务创建、调度、执行
- 批量定价：支持大规模交易数据的批量定价计算
- 定价过程监控：定价任务进度监控、异常处理

#### 4.3 结果查询
- FTP结果查询：多维度查询FTP计算结果
- 结果分析：定价结果统计分析
- 结果导出：支持多种格式的结果导出

#### 4.4 期限匹配
- 将资产和负债按期限进行匹配，准确反映银行的期限错配风险

#### 4.5 利率曲线管理
- 支持多种基准利率曲线的管理和应用
- 曲线插值计算

## 技术架构设计

### 1. 技术栈
- **后端框架**: Spring Boot 3.x
- **数据库**: MySQL 8.x
- **ORM**: Spring Data JPA
- **构建工具**: Maven
- **Java版本**: JDK 17+

### 2. 项目结构（模块化设计）
```
d:\ZDD\shixi\FTP/
├── src/
│   ├── main/
│   │   ├── java/com/bank/ftp/
│   │   │   ├── FtpApplication.java                  # 主程序入口
│   │   │   ├── common/                              # 公共模块
│   │   │   │   ├── constant/                        # 常量定义
│   │   │   │   ├── exception/                       # 异常处理
│   │   │   │   ├── util/                            # 工具类
│   │   │   │   ├── response/                        # 统一响应格式
│   │   │   │   └── annotation/                      # 自定义注解
│   │   │   ├── config/                              # 配置类
│   │   │   │   ├── SecurityConfig.java              # 安全配置
│   │   │   │   └── JpaConfig.java                   # JPA配置
│   │   │   ├── system/                              # 系统管理模块
│   │   │   │   ├── controller/
│   │   │   │   ├── service/
│   │   │   │   ├── repository/
│   │   │   │   ├── entity/
│   │   │   │   └── dto/
│   │   │   ├── parameter/                           # 公共参数模块
│   │   │   │   ├── controller/
│   │   │   │   ├── service/
│   │   │   │   ├── repository/
│   │   │   │   ├── entity/
│   │   │   │   └── dto/
│   │   │   ├── report/                              # 报表集成模块
│   │   │   │   ├── controller/
│   │   │   │   ├── service/
│   │   │   │   ├── repository/
│   │   │   │   ├── entity/
│   │   │   │   └── dto/
│   │   │   └── ftp/                                 # 资金转移定价模块
│   │   │       ├── controller/
│   │   │       ├── service/
│   │   │       │   ├── rule/                        # 规则管理服务
│   │   │       │   ├── pricing/                     # 定价管理服务
│   │   │       │   └── result/                      # 结果查询服务
│   │   │       ├── repository/
│   │   │       ├── entity/
│   │   │       ├── dto/
│   │   │       ├── calculator/                      # FTP计算引擎
│   │   │       │   ├── method/                      # 定价方法实现
│   │   │       │   ├── matcher/                     # 规则匹配器
│   │   │       │   ├── adjuster/                    # 调整项计算器
│   │   │       │   └── combiner/                    # 组合定价器
│   │   │       └── rule/                            # 规则引擎相关
│   │   └── resources/
│   │       ├── application.yml                      # 主配置文件
│   │       ├── application-dev.yml                  # 开发环境配置
│   │       ├── application-prod.yml                 # 生产环境配置
│   │       └── db/migration/                        # 数据库迁移脚本
│   └── test/                                        # 单元测试和集成测试
├── pom.xml                                          # Maven配置文件
└── docs/                                            # 文档
```

### 3. 核心数据模型（实体类）

#### 3.1 系统管理模块实体
- **User**: 用户实体
- **Role**: 角色实体
- **Permission**: 权限实体
- **PasswordPolicy**: 密码策略实体
- **SystemConfig**: 系统配置实体

#### 3.2 公共参数模块实体
- **Currency**: 币种实体
- **ExchangeRate**: 汇率实体
- **Caliber**: 统计口径实体
- **Organization**: 机构实体

#### 3.3 报表集成模块实体
- **ReportDefinition**: 报表定义实体
- **ReportParameter**: 报表参数实体
- **ReportTemplate**: 报表模板实体
- **ReportSchedule**: 报表调度实体

#### 3.4 资金转移定价模块实体
- **RateCurve**: 利率曲线实体
- **RateCurvePoint**: 利率曲线上的点实体
- **ProductType**: 产品类型实体
- **BusinessTransaction**: 业务交易实体
- **PricingMethodRule**: 定价方法匹配规则实体
- **PricingCurveRule**: 定价曲线匹配规则实体
- **AdjustmentRule**: 调整项规则实体
- **CombinationPricingRule**: 组合定价规则实体
- **RuleVersion**: 规则版本实体
- **PricingTask**: 定价任务实体
- **FTPCalculationResult**: FTP计算结果实体
- **TransferPricingRecord**: 资金转移定价记录实体

### 4. 核心服务模块

#### 4.1 系统管理模块服务
- **UserService**: 用户管理服务
- **RoleService**: 角色权限管理服务
- **PasswordService**: 密码管理服务
- **SystemConfigService**: 系统配置服务

#### 4.2 公共参数模块服务
- **CurrencyService**: 币种管理服务
- **CaliberService**: 口径管理服务
- **OrganizationService**: 机构管理服务

#### 4.3 报表集成模块服务
- **ReportDefinitionService**: 报表定义服务
- **ReportParameterService**: 报表参数服务
- **ReportScheduleService**: 报表调度服务
- **ReportGeneratorService**: 报表生成服务

#### 4.4 资金转移定价模块服务
- **PricingMethodRuleService**: 定价方法匹配规则服务
- **PricingCurveRuleService**: 定价曲线匹配规则服务
- **AdjustmentRuleService**: 调整项规则服务
- **CombinationPricingRuleService**: 组合定价规则服务
- **RuleVersionService**: 规则版本管理服务
- **RateCurveService**: 利率曲线管理服务
- **PricingTaskService**: 定价任务管理服务
- **FtpCalculatorEngine**: FTP计算引擎（核心）
- **FtpResultService**: FTP结果查询服务

## 实施计划

### 第一阶段：基础架构搭建
1. 初始化Spring Boot Maven项目，配置pom.xml依赖
2. 配置application.yml（MySQL数据库连接、JPA、多环境配置）
3. 创建数据库表结构和迁移脚本
4. 实现公共模块（common包）：统一响应、异常处理、工具类
5. 搭建Spring Security安全框架
6. 实现系统管理模块基础实体和Repository

### 第二阶段：系统管理模块开发
1. 实现用户管理功能（CRUD、角色权限）
2. 实现密码配置功能（密码策略、密码修改/重置）
3. 实现系统配置功能
4. 开发系统管理模块REST API

### 第三阶段：公共参数模块开发
1. 实现币种管理功能
2. 实现口径管理功能
3. 实现机构管理功能
4. 开发公共参数模块REST API

### 第四阶段：资金转移定价模块 - 规则管理开发
1. 实现定价方法匹配规则功能
2. 实现定价曲线匹配规则功能
3. 实现调整项规则功能
4. 实现组合定价功能
5. 实现规则版本管理
6. 开发规则管理REST API

### 第五阶段：资金转移定价模块 - 核心引擎开发
1. 实现FTP计算引擎核心框架
2. 实现规则匹配器（matcher）
3. 实现定价方法（method）
4. 实现调整项计算器（adjuster）
5. 实现组合定价器（combiner）
6. 实现利率曲线管理功能（含插值计算）
7. 实现定价任务管理功能（创建、调度、执行）
8. 实现期限匹配算法

### 第六阶段：资金转移定价模块 - 定价与结果查询
1. 实现批量定价功能
2. 实现定价过程监控
3. 实现FTP结果查询功能（多维度查询）
4. 实现结果分析功能
5. 实现结果导出功能
6. 开发资金转移定价模块REST API

### 第七阶段：报表集成模块开发
1. 实现报表定义功能
2. 实现报表参数设置功能
3. 实现报表调度功能
4. 实现报表生成功能
5. 开发报表集成模块REST API

### 第八阶段：集成与测试
1. 系统集成测试
2. 性能优化
3. API文档编写（Swagger）
4. 用户验收测试

## 扩展性设计原则

为支持后续新增模块和规则，系统将遵循以下设计原则：
1. **模块化架构**：各模块低耦合高内聚，便于独立开发和扩展
2. **策略模式**：定价方法、规则匹配器等采用策略模式，便于新增实现
3. **配置化设计**：尽量通过配置而非硬编码实现业务规则
4. **接口抽象**：核心功能通过接口定义，便于扩展新实现
5. **数据库设计预留扩展字段**：关键表预留扩展字段支持未来需求

## 数据库设计要点

### 核心表结构

#### 系统管理模块表
1. **sys_user**: 用户表
2. **sys_role**: 角色表
3. **sys_permission**: 权限表
4. **sys_user_role**: 用户角色关联表
5. **sys_role_permission**: 角色权限关联表
6. **sys_password_policy**: 密码策略表
7. **sys_config**: 系统配置表

#### 公共参数模块表
8. **param_currency**: 币种表
9. **param_exchange_rate**: 汇率表
10. **param_caliber**: 统计口径表
11. **param_organization**: 机构表

#### 报表集成模块表
12. **rpt_definition**: 报表定义表
13. **rpt_parameter**: 报表参数表
14. **rpt_template**: 报表模板表
15. **rpt_schedule**: 报表调度表

#### 资金转移定价模块表
16. **ftp_rate_curve**: 利率曲线主表
17. **ftp_rate_curve_point**: 利率曲线点数表
18. **ftp_product_type**: 产品类型表
19. **ftp_business_transaction**: 业务交易表
20. **ftp_pricing_method_rule**: 定价方法匹配规则表
21. **ftp_pricing_curve_rule**: 定价曲线匹配规则表
22. **ftp_adjustment_rule**: 调整项规则表
23. **ftp_combination_pricing_rule**: 组合定价规则表
24. **ftp_rule_version**: 规则版本表
25. **ftp_pricing_task**: 定价任务表
26. **ftp_calculation_result**: FTP计算结果表
27. **ftp_transfer_pricing_record**: 转移定价记录表

## 预期成果

1. 一个功能完整的银行内部资金转移定价系统
2. 支持多种金融产品的FTP计算
3. 提供灵活的配置选项
4. 具备良好的扩展性
5. 符合银行业务规范的计算精度

## 关键技术点

1. 金融计算精度控制
2. 大数据量处理能力
3. 利率曲线插值算法
4. 期限匹配算法
5. 并发处理机制

## 风险评估

1. 计算精度问题：需确保金融计算的准确性
2. 性能问题：大量数据处理时的性能表现
3. 业务规则变更：需考虑未来业务规则调整的灵活性
4. 数据安全：敏感财务数据的安全保护

## 成功标准

1. 系统能够准确计算各类业务的FTP价格
2. 计算性能满足银行实时处理需求
3. 系统具备良好的可维护性和扩展性
4. 用户界面友好，操作简便
5. 通过银行业务验证测试