# 银行内部资金转移定价系统

[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](LICENSE)
[![Java Version](https://img.shields.io/badge/java-17%2B-green.svg)](https://www.oracle.com/java/technologies/javase/jdk17-archive-downloads.html)
[![Spring Boot](https://img.shields.io/badge/spring--boot-3.2.0-brightgreen.svg)](https://spring.io/projects/spring-boot)
[![Build Status](https://img.shields.io/badge/build-passing-brightgreen.svg)](#)

## 项目简介

银行内部资金转移定价（FTP, Funds Transfer Pricing）系统是银行内部管理资金成本和收益的核心工具。系统通过对不同资金来源和运用的精确计价，帮助银行优化资产负债结构，提升盈利能力。

### 主要特性

- ✅ **模块化架构**：系统采用清晰的模块化设计，便于维护和扩展
- ✅ **灵活配置**：支持多种定价方法和规则配置
- ✅ **高性能计算**：高效的FTP计算引擎，支持批量处理
- ✅ **完整报表**：提供丰富的报表功能和数据分析
- ✅ **安全可靠**：完善的安全机制和权限控制
- ✅ **易于集成**：标准化API接口，便于与其他系统集成

## 系统架构

### 技术栈

- **后端框架**: Spring Boot 3.x
- **数据库**: MySQL 8.x
- **ORM**: Spring Data JPA
- **构建工具**: Maven
- **Java版本**: JDK 17+
- **API文档**: Swagger/OpenAPI
- **安全框架**: Spring Security
- **报表引擎**: Apache POI

### 系统模块

```
├── 系统管理模块
│   ├── 用户管理
│   ├── 角色权限
│   ├── 密码策略
│   └── 系统配置
├── 公共参数模块
│   ├── 币种管理
│   ├── 汇率管理
│   ├── 口径管理
│   └── 机构管理
├── FTP计算模块
│   ├── 规则管理
│   ├── 利率曲线管理
│   ├── 定价任务管理
│   └── FTP计算引擎
└── 报表集成模块
    ├── 报表定义
    ├── 报表参数
    ├── 报表调度
    └── 报表生成
```

## 快速开始

### 环境要求

- JDK 17 或更高版本
- Maven 3.6.0 或更高版本
- MySQL 8.0 或更高版本
- Git

### 本地开发环境搭建

1. **克隆项目**
   ```bash
   git clone https://github.com/your-org/ftp-system.git
   cd ftp-system
   ```

2. **创建数据库**
   ```sql
   CREATE DATABASE ftp_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'ftp_user'@'localhost' IDENTIFIED BY 'StrongPassword123!';
   GRANT ALL PRIVILEGES ON ftp_system.* TO 'ftp_user'@'localhost';
   FLUSH PRIVILEGES;
   ```

3. **配置数据库连接**
   修改 `src/main/resources/application-dev.yml`:
   ```yaml
   spring:
     datasource:
       url: jdbc:mysql://localhost:3306/ftp_system?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=Asia/Shanghai
       username: ftp_user
       password: StrongPassword123!
   ```

4. **编译项目**
   ```bash
   mvn clean compile
   ```

5. **运行项目**
   ```bash
   mvn spring-boot:run
   ```

6. **访问系统**
   - 应用启动后访问：`http://localhost:8080`
   - API文档：`http://localhost:8080/swagger-ui.html`

### Docker部署

1. **构建镜像**
   ```bash
   mvn clean package -DskipTests
   docker build -t bank/ftp-system:latest .
   ```

2. **运行容器**
   ```bash
   docker run -d \
     --name ftp-system \
     -p 8080:8080 \
     -e SPRING_PROFILES_ACTIVE=docker \
     -e DB_HOST=mysql-container \
     -e DB_PORT=3306 \
     -e DB_NAME=ftp_system \
     -e DB_USER=ftp_user \
     -e DB_PASSWORD=StrongPassword123! \
     bank/ftp-system:latest
   ```

## API接口

系统提供完整的RESTful API接口，支持：

- 用户认证和授权
- 业务数据管理
- FTP计算操作
- 报表生成和导出
- 系统配置管理

详细API文档请参考：[接口文档](./docs/api_documentation.md)

## 配置说明

### 主要配置文件

- `application.yml`: 主配置文件
- `application-dev.yml`: 开发环境配置
- `application-test.yml`: 测试环境配置
- `application-prod.yml`: 生产环境配置

### 重要配置项

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/ftp_system
    username: ftp_user
    password: StrongPassword123!
  jpa:
    hibernate:
      ddl-auto: validate  # 生产环境使用validate
  flyway:
    enabled: true  # 启用数据库迁移

server:
  port: 8080
  servlet:
    context-path: /api

springdoc:
  swagger-ui:
    path: /swagger-ui.html
```

## 数据库设计

系统包含完整的数据库表结构设计，涵盖：

- 系统管理相关表
- 公共参数相关表
- FTP计算相关表
- 报表集成相关表

详细表结构请参考：[数据库设计文档](./docs/database_schema.md)

## 测试

### 単元测试
```bash
mvn test
```

### 集成测试
```bash
mvn verify
```

### 测试覆盖率
- 単元测试覆盖率：>80%
- 重要业务逻辑覆盖率：100%

## 部署

### 前端 + 后端分离部署（推荐）

系统支持前后端分离部署，前端通过Nginx提供静态资源服务，后端API通过反向代理访问。

#### 1. 构建后端服务

1. **打包应用**
   ```bash
   mvn clean package -DskipTests
   ```

2. **启动后端服务**
   ```bash
   java -jar target/ftp-system-1.0.0.jar --spring.profiles.active=prod
   ```
   后端服务默认运行在 `http://localhost:8080`

#### 2. 部署前端应用

前端文件位于 `frontend/` 目录下，包含：
- `index.html` - 主页面
- `css/` - 样式文件
- `js/` - JavaScript文件
- `images/` - 图片资源

将前端文件部署到Web服务器（如Nginx）的静态资源目录。

#### 3. Nginx配置

使用项目根目录下的 `nginx.conf` 配置文件：

```nginx
# FTP Bank System Nginx Configuration
# This configuration serves the frontend and proxies API requests to the backend

events {
    worker_connections 1024;
}

http {
    include       mime.types;
    default_type  application/octet-stream;
    
    # Log format
    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';
    
    access_log  logs/access.log  main;
    
    sendfile        on;
    keepalive_timeout  65;
    
    # Upstream server for backend API
    upstream backend {
        server localhost:8080;
    }
    
    # Main server block
    server {
        listen       80;
        server_name  localhost;
        
        # Serve static files (frontend)
        location / {
            root   html;
            index  index.html index.htm;
            try_files $uri $uri/ /index.html;
        }
        
        # Proxy API requests to backend
        location /api/ {
            proxy_pass http://backend/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            
            # Increase timeout for potentially long-running requests
            proxy_connect_timeout 60s;
            proxy_send_timeout 60s;
            proxy_read_timeout 60s;
        }
        
        # Additional security headers
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header X-XSS-Protection "1; mode=block" always;
        add_header X-Content-Type-Options "nosniff" always;
    }
}
```

#### 4. 启动Nginx

1. 将 `frontend` 目录下的所有文件复制到 Nginx 的 `html` 目录
2. 替换 Nginx 的默认配置文件为上面的配置
3. 启动 Nginx 服务

访问 `http://localhost` 即可使用前端界面，API 请求会自动代理到后端服务。

### 传统单体部署

如果不需要前后端分离，也可以直接部署后端应用：

1. **打包应用**
   ```bash
   mvn clean package -DskipTests
   ```

2. **部署JAR包**
   ```bash
   java -jar target/ftp-system-1.0.0.jar --spring.profiles.active=prod
   ```

3. **使用系统服务**（Linux）
   参考：[部署指南](./docs/deployment_guide.md)

### Docker Compose部署

支持前后端分离的Docker Compose部署：

```yaml
version: '3.8'
services:
  mysql:
    image: mysql:8.0
    environment:
      MYSQL_ROOT_PASSWORD: RootPassword123!
      MYSQL_DATABASE: ftp_system
    ports:
      - "3306:3306"
  
  backend:
    build: .
    depends_on:
      - mysql
    environment:
      - SPRING_PROFILES_ACTIVE=docker
      - DB_HOST=mysql
    ports:
      - "8080:8080"
  
  nginx:
    image: nginx:alpine
    depends_on:
      - backend
    volumes:
      - ./frontend:/usr/share/nginx/html:ro
      - ./nginx.conf:/etc/nginx/nginx.conf
    ports:
      - "80:80"
```

## 文档

- [接口文档](./docs/api_documentation.md)
- [数据库设计](./docs/database_schema.md)
- [系统架构](./docs/system_architecture.md)
- [开发规范](./docs/development_standards.md)
- [部署指南](./docs/deployment_guide.md)
- [测试策略](./docs/testing_strategy.md)
- [用户手册](./docs/user_manual.md)
- [流程图规范](./docs/process_flow_diagrams.md)

## 项目结构

```
src/
├── main/
│   ├── java/com/bank/ftp/
│   │   ├── FtpApplication.java
│   │   ├── common/          # 公共模块
│   │   ├── config/          # 配置类
│   │   ├── system/          # 系统管理模块
│   │   ├── parameter/       # 公共参数模块
│   │   ├── report/          # 报表集成模块
│   │   └── ftp/             # FTP计算模块
│   └── resources/
│       ├── application.yml
│       ├── application-dev.yml
│       ├── application-prod.yml
│       └── db/migration/     # 数据库迁移脚本
├── test/                     # 単元测试
└── docs/                     # 文档
```

## 贡献

欢迎提交Issue和Pull Request来改进项目。

### 开发规范

- 代码风格遵循 [开发规范](./docs/development_standards.md)
- 提交信息使用约定式提交格式
- 所有功能需要相应的测试覆盖

### 贡献步骤

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 版本发布

项目遵循语义化版本控制 (SemVer)。

- `MAJOR` 版本：不兼容的API更改
- `MINOR` 版本：向下兼容的功能添加
- `PATCH` 版本：向下兼容的问题修正

## 作者

- **开发团队** - 银行科技部

## 许可证

该项目采用 Apache License 2.0 许可证 - 详见 [LICENSE](LICENSE) 文件。

## 致谢

- 感谢所有为项目做出贡献的开发者
- 感谢使用的开源框架和工具的支持

---

## 支持

如果你觉得这个项目有用，请给它一个 ⭐ Star！

遇到问题请查看 [用户手册](./docs/user_manual.md) 或提交 Issue。

**联系方式**：
- 邮箱: support@bank.com
- 电话: 400-XXX-XXXX