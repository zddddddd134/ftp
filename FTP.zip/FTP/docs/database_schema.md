# 银行内部资金转移定价系统 - 数据库表结构文档

## 1. 系统管理模块表

### 1.1 用户表 (sys_user)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 用户ID |
| username | VARCHAR | 50 | NOT NULL | UK | | 用户名 |
| password | VARCHAR | 255 | NOT NULL | | | 密码 |
| real_name | VARCHAR | 50 | | | | 真实姓名 |
| email | VARCHAR | 100 | | | | 邮箱 |
| phone | VARCHAR | 20 | | | | 手机号 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| last_login_time | DATETIME | | | | | 最后登录时间 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 1.2 角色表 (sys_role)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 角色ID |
| role_name | VARCHAR | 50 | NOT NULL | | | 角色名称 |
| role_code | VARCHAR | 50 | NOT NULL | UK | | 角色编码 |
| description | VARCHAR | 200 | | | | 角色描述 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 1.3 权限表 (sys_permission)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 权限ID |
| permission_name | VARCHAR | 50 | NOT NULL | | | 权限名称 |
| permission_code | VARCHAR | 100 | NOT NULL | UK | | 权限编码 |
| resource_type | VARCHAR | 20 | | | | 资源类型：menu-菜单，button-按钮，api-接口 |
| resource_url | VARCHAR | 200 | | | | 资源URL |
| parent_id | BIGINT | | | | 0 | 父权限ID |
| sort_order | INT | | | | 0 | 排序 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 1.4 用户角色关联表 (sys_user_role)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | ID |
| user_id | BIGINT | | NOT NULL | | | 用户ID |
| role_id | BIGINT | | NOT NULL | | | 角色ID |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |

### 1.5 角色权限关联表 (sys_role_permission)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | ID |
| role_id | BIGINT | | NOT NULL | | | 角色ID |
| permission_id | BIGINT | | NOT NULL | | | 权限ID |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |

### 1.6 密码策略表 (sys_password_policy)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 策略ID |
| policy_name | VARCHAR | 50 | NOT NULL | | | 策略名称 |
| min_length | INT | | | | 8 | 最小长度 |
| max_length | INT | | | | 20 | 最大长度 |
| require_upper | TINYINT | | | | 1 | 需要大写字母：0-否，1-是 |
| require_lower | TINYINT | | | | 1 | 需要小写字母：0-否，1-是 |
| require_digit | TINYINT | | | | 1 | 需要数字：0-否，1-是 |
| require_special | TINYINT | | | | 0 | 需要特殊字符：0-否，1-是 |
| password_expire_days | INT | | | | 90 | 密码过期天数 |
| password_history_count | INT | | | | 5 | 密码历史记录数 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |

### 1.7 系统配置表 (sys_config)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 配置ID |
| config_key | VARCHAR | 100 | NOT NULL | UK | | 配置键 |
| config_value | VARCHAR | 500 | | | | 配置值 |
| config_name | VARCHAR | 100 | | | | 配置名称 |
| description | VARCHAR | 200 | | | | 配置描述 |
| config_type | VARCHAR | 20 | | | string | 配置类型：string-字符串，number-数字，boolean-布尔值 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |

## 2. 公共参数模块表

### 2.1 币种表 (param_currency)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 币种ID |
| currency_code | VARCHAR | 10 | NOT NULL | UK | | 币种编码 |
| currency_name | VARCHAR | 50 | NOT NULL | | | 币种名称 |
| currency_symbol | VARCHAR | 10 | | | | 币种符号 |
| decimal_places | INT | | | | 2 | 小数位数 |
| is_default | TINYINT | | | | 0 | 是否默认：0-否，1-是 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 2.2 汇率表 (param_exchange_rate)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 汇率ID |
| source_currency_id | BIGINT | | NOT NULL | | | 源币种ID |
| target_currency_id | BIGINT | | NOT NULL | | | 目标币种ID |
| exchange_rate | DECIMAL | 20,8 | NOT NULL | | | 汇率 |
| rate_date | DATE | | NOT NULL | | | 汇率日期 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |

### 2.3 统计口径表 (param_caliber)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 口径ID |
| caliber_code | VARCHAR | 50 | NOT NULL | UK | | 口径编码 |
| caliber_name | VARCHAR | 100 | NOT NULL | | | 口径名称 |
| description | VARCHAR | 500 | | | | 口径描述 |
| caliber_rule | TEXT | | | | | 口径规则定义 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 2.4 机构表 (param_organization)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 机构ID |
| org_code | VARCHAR | 50 | NOT NULL | UK | | 机构编码 |
| org_name | VARCHAR | 100 | NOT NULL | | | 机构名称 |
| org_type | VARCHAR | 20 | | | | 机构类型 |
| parent_id | BIGINT | | | | 0 | 父机构ID |
| level | INT | | | | 1 | 机构层级 |
| sort_order | INT | | | | 0 | 排序 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

## 3. 报表集成模块表

### 3.1 报表定义表 (rpt_definition)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 报表ID |
| report_code | VARCHAR | 50 | NOT NULL | UK | | 报表编码 |
| report_name | VARCHAR | 100 | NOT NULL | | | 报表名称 |
| description | VARCHAR | 500 | | | | 报表描述 |
| template_id | BIGINT | | | | | 报表模板ID |
| data_source_config | TEXT | | | | | 数据源配置 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 3.2 报表参数表 (rpt_parameter)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 参数ID |
| report_id | BIGINT | | NOT NULL | | | 报表ID |
| param_name | VARCHAR | 50 | NOT NULL | | | 参数名称 |
| param_code | VARCHAR | 50 | NOT NULL | | | 参数编码 |
| param_type | VARCHAR | 20 | NOT NULL | | | 参数类型：string-字符串，number-数字，date-日期，select-下拉框 |
| param_default_value | VARCHAR | 200 | | | | 参数默认值 |
| param_options | TEXT | | | | | 参数选项（JSON格式） |
| required | TINYINT | | | | 0 | 是否必填：0-否，1-是 |
| sort_order | INT | | | | 0 | 排序 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |

### 3.3 报表模板表 (rpt_template)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 模板ID |
| template_name | VARCHAR | 100 | NOT NULL | | | 模板名称 |
| template_type | VARCHAR | 20 | NOT NULL | | | 模板类型：excel-Excel，pdf-PDF |
| template_file | LONGBLOB | | | | | 模板文件 |
| file_name | VARCHAR | 200 | | | | 文件名 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 3.4 报表调度表 (rpt_schedule)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 调度ID |
| report_id | BIGINT | | NOT NULL | | | 报表ID |
| schedule_name | VARCHAR | 100 | NOT NULL | | | 调度名称 |
| cron_expression | VARCHAR | 100 | NOT NULL | | | Cron表达式 |
| param_values | TEXT | | | | | 参数值（JSON格式） |
| output_format | VARCHAR | 20 | | | excel | 输出格式：excel-Excel，pdf-PDF |
| email_recipients | VARCHAR | 500 | | | | 邮件接收人 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| last_execution_time | DATETIME | | | | | 最后执行时间 |
| next_execution_time | DATETIME | | | | | 下次执行时间 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

## 4. 资金转移定价模块表

### 4.1 利率曲线主表 (ftp_rate_curve)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 曲线ID |
| curve_code | VARCHAR | 50 | NOT NULL | UK | | 曲线编码 |
| curve_name | VARCHAR | 100 | NOT NULL | | | 曲线名称 |
| curve_type | VARCHAR | 20 | NOT NULL | | | 曲线类型：treasury-国债，shibor-Shibor，deposit-存款，loan-贷款等 |
| currency_id | BIGINT | | NOT NULL | | | 币种ID |
| description | VARCHAR | 500 | | | | 曲线描述 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 4.2 利率曲线点数表 (ftp_rate_curve_point)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 点ID |
| curve_id | BIGINT | | NOT NULL | | | 曲线ID |
| term | INT | | NOT NULL | | | 期限（天） |
| term_unit | VARCHAR | 10 | | | day | 期限单位：day-天，month-月，year-年 |
| term_display | VARCHAR | 50 | | | | 期限显示名称 |
| rate | DECIMAL | 10,6 | NOT NULL | | | 利率值 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |

### 4.3 产品类型表 (ftp_product_type)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 产品类型ID |
| product_code | VARCHAR | 50 | NOT NULL | UK | | 产品编码 |
| product_name | VARCHAR | 100 | NOT NULL | | | 产品名称 |
| product_category | VARCHAR | 50 | | | | 产品大类：deposit-存款，loan-贷款等 |
| description | VARCHAR | 500 | | | | 产品描述 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 4.4 业务交易表 (ftp_business_transaction)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 交易ID |
| transaction_no | VARCHAR | 50 | NOT NULL | UK | | 交易编号 |
| product_type_id | BIGINT | | NOT NULL | | | 产品类型ID |
| org_id | BIGINT | | | | | 机构ID |
| currency_id | BIGINT | | NOT NULL | | | 币种ID |
| amount | DECIMAL | 20,2 | NOT NULL | | | 交易金额 |
| direction | VARCHAR | 10 | NOT NULL | | | 方向：in-流入（存款），out-流出（贷款） |
| start_date | DATE | | NOT NULL | | | 起息日 |
| end_date | DATE | | | | | 到期日 |
| term | INT | | | | | 期限（天） |
| interest_rate | DECIMAL | 10,6 | | | | 合同利率 |
| status | VARCHAR | 20 | | | normal | 状态：normal-正常，overdue-逾期 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |

### 4.5 定价方法匹配规则表 (ftp_pricing_method_rule)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 规则ID |
| rule_code | VARCHAR | 50 | NOT NULL | UK | | 规则编码 |
| rule_name | VARCHAR | 100 | NOT NULL | | | 规则名称 |
| pricing_method | VARCHAR | 50 | NOT NULL | | | 定价方法：duration-期限匹配，pool-资金池，maturity-到期日匹配等 |
| product_type_ids | TEXT | | | | | 适用产品类型ID列表（JSON格式） |
| org_ids | TEXT | | | | | 适用机构ID列表（JSON格式） |
| amount_min | DECIMAL | 20,2 | | | | 金额下限 |
| amount_max | DECIMAL | 20,2 | | | | 金额上限 |
| term_min | INT | | | | | 期限下限（天） |
| term_max | INT | | | | | 期限上限（天） |
| priority | INT | | | | 0 | 优先级，数字越大优先级越高 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 4.6 定价曲线匹配规则表 (ftp_pricing_curve_rule)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 规则ID |
| rule_code | VARCHAR | 50 | NOT NULL | UK | | 规则编码 |
| rule_name | VARCHAR | 100 | NOT NULL | | | 规则名称 |
| curve_id | BIGINT | | NOT NULL | | | 利率曲线ID |
| product_type_ids | TEXT | | | | | 适用产品类型ID列表（JSON格式） |
| org_ids | TEXT | | | | | 适用机构ID列表（JSON格式） |
| amount_min | DECIMAL | 20,2 | | | | 金额下限 |
| amount_max | DECIMAL | 20,2 | | | | 金额上限 |
| term_min | INT | | | | | 期限下限（天） |
| term_max | INT | | | | | 期限上限（天） |
| priority | INT | | | | 0 | 优先级，数字越大优先级越高 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 4.7 调整项规则表 (ftp_adjustment_rule)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 规则ID |
| rule_code | VARCHAR | 50 | NOT NULL | UK | | 规则编码 |
| rule_name | VARCHAR | 100 | NOT NULL | | | 规则名称 |
| adjustment_type | VARCHAR | 50 | NOT NULL | | | 调整类型：liquidity-流动性，credit-信用，option-期权等 |
| adjustment_value | DECIMAL | 10,6 | NOT NULL | | | 调整值（基点或百分比） |
| adjustment_mode | VARCHAR | 20 | | | add | 调整方式：add-加法，multiply-乘法 |
| product_type_ids | TEXT | | | | | 适用产品类型ID列表（JSON格式） |
| org_ids | TEXT | | | | | 适用机构ID列表（JSON格式） |
| amount_min | DECIMAL | 20,2 | | | | 金额下限 |
| amount_max | DECIMAL | 20,2 | | | | 金额上限 |
| term_min | INT | | | | | 期限下限（天） |
| term_max | INT | | | | | 期限上限（天） |
| priority | INT | | | | 0 | 优先级，数字越大优先级越高 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 4.8 组合定价规则表 (ftp_combination_pricing_rule)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 组合规则ID |
| rule_code | VARCHAR | 50 | NOT NULL | UK | | 规则编码 |
| rule_name | VARCHAR | 100 | NOT NULL | | | 规则名称 |
| method_rule_ids | TEXT | | | | | 定价方法规则ID列表（JSON格式） |
| curve_rule_ids | TEXT | | | | | 定价曲线规则ID列表（JSON格式） |
| adjustment_rule_ids | TEXT | | | | | 调整项规则ID列表（JSON格式） |
| product_type_ids | TEXT | | | | | 适用产品类型ID列表（JSON格式） |
| org_ids | TEXT | | | | | 适用机构ID列表（JSON格式） |
| priority | INT | | | | 0 | 优先级，数字越大优先级越高 |
| status | TINYINT | | | | 1 | 状态：0-禁用，1-启用 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |
| deleted | TINYINT | | | | 0 | 删除标记：0-未删除，1-已删除 |

### 4.9 规则版本表 (ftp_rule_version)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 版本ID |
| rule_type | VARCHAR | 50 | NOT NULL | | | 规则类型：method-定价方法，curve-定价曲线，adjustment-调整项，combination-组合定价 |
| rule_id | BIGINT | | NOT NULL | | | 规则ID |
| rule_code | VARCHAR | 50 | NOT NULL | | | 规则编码 |
| version_no | INT | | NOT NULL | | | 版本号 |
| rule_content | TEXT | | NOT NULL | | | 规则内容（JSON格式） |
| description | VARCHAR | 500 | | | | 版本描述 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |

### 4.10 定价任务表 (ftp_pricing_task)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 任务ID |
| task_code | VARCHAR | 50 | NOT NULL | UK | | 任务编码 |
| task_name | VARCHAR | 100 | NOT NULL | | | 任务名称 |
| task_type | VARCHAR | 20 | NOT NULL | | | 任务类型：manual-手动，schedule-定时 |
| pricing_date | DATE | | NOT NULL | | | 定价日期 |
| transaction_ids | TEXT | | | | | 交易ID列表（JSON格式，空表示全部） |
| status | VARCHAR | 20 | | | pending | 状态：pending-待执行，running-执行中，success-成功，failed-失败 |
| progress | INT | | | | 0 | 进度（0-100） |
| total_count | INT | | | | 0 | 总记录数 |
| success_count | INT | | | | 0 | 成功记录数 |
| fail_count | INT | | | | 0 | 失败记录数 |
| error_message | TEXT | | | | | 错误信息 |
| start_time | DATETIME | | | | | 开始时间 |
| end_time | DATETIME | | | | | 结束时间 |
| created_by | BIGINT | | | | | 创建人 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |
| updated_by | BIGINT | | | | | 更新人 |
| updated_time | DATETIME | | | | CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |

### 4.11 FTP计算结果表 (ftp_calculation_result)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 结果ID |
| task_id | BIGINT | | NOT NULL | | | 任务ID |
| transaction_id | BIGINT | | NOT NULL | | | 交易ID |
| transaction_no | VARCHAR | 50 | NOT NULL | | | 交易编号 |
| pricing_date | DATE | | NOT NULL | | | 定价日期 |
| base_rate | DECIMAL | 10,6 | | | | 基准利率 |
| adjustment_items | TEXT | | | | | 调整项明细（JSON格式） |
| total_adjustment | DECIMAL | 10,6 | | | | 总调整值 |
| final_ftp_rate | DECIMAL | 10,6 | NOT NULL | | | 最终FTP利率 |
| ftp_cost | DECIMAL | 20,2 | | | | FTP成本/收益 |
| curve_id | BIGINT | | | | | 使用的曲线ID |
| pricing_method | VARCHAR | 50 | | | | 使用的定价方法 |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |

### 4.12 转移定价记录表 (ftp_transfer_pricing_record)
| 字段名 | 类型 | 长度 | 是否为空 | 主键 | 默认值 | 说明 |
|--------|------|------|----------|------|--------|------|
| id | BIGINT | | NOT NULL | PK | | 记录ID |
| transaction_id | BIGINT | | NOT NULL | | | 交易ID |
| transaction_no | VARCHAR | 50 | NOT NULL | | | 交易编号 |
| pricing_date | DATE | | NOT NULL | | | 定价日期 |
| org_id | BIGINT | | | | | 机构ID |
| product_type_id | BIGINT | | | | | 产品类型ID |
| amount | DECIMAL | 20,2 | NOT NULL | | | 金额 |
| direction | VARCHAR | 10 | NOT NULL | | | 方向：in-流入，out-流出 |
| ftp_rate | DECIMAL | 10,6 | NOT NULL | | | FTP利率 |
| ftp_amount | DECIMAL | 20,2 | | | | FTP金额 |
| term | INT | | | | | 期限（天） |
| created_time | DATETIME | | | | CURRENT_TIMESTAMP | 创建时间 |

## 索引说明

### sys_user 表
- `idx_username`: username 字段索引
- `idx_last_login_time`: last_login_time 字段索引

### sys_role 表
- `idx_role_code`: role_code 字段索引

### sys_permission 表
- `idx_permission_code`: permission_code 字段索引
- `idx_parent_id`: parent_id 字段索引

### sys_user_role 表
- `uk_user_role`: (user_id, role_id) 唯一索引

### sys_role_permission 表
- `uk_role_permission`: (role_id, permission_id) 唯一索引

### param_currency 表
- `idx_currency_code`: currency_code 字段索引
- `idx_is_default`: is_default 字段索引

### param_exchange_rate 表
- `uk_currency_date`: (source_currency_id, target_currency_id, rate_date) 唯一索引
- `idx_rate_date`: rate_date 字段索引
- `idx_source_currency`: source_currency_id 字段索引

### param_caliber 表
- `idx_caliber_code`: caliber_code 字段索引

### param_organization 表
- `idx_org_code`: org_code 字段索引
- `idx_parent_id`: parent_id 字段索引

### rpt_definition 表
- `idx_report_code`: report_code 字段索引

### rpt_parameter 表
- `idx_report_id`: report_id 字段索引

### rpt_template 表
- `idx_template_name`: template_name 字段索引

### rpt_schedule 表
- `idx_report_id`: report_id 字段索引

### ftp_rate_curve 表
- `idx_curve_code`: curve_code 字段索引

### ftp_rate_curve_point 表
- `idx_curve_id`: curve_id 字段索引

### ftp_product_type 表
- `idx_product_code`: product_code 字段索引

### ftp_business_transaction 表
- `idx_transaction_no`: transaction_no 字段索引
- `idx_product_type`: product_type_id 字段索引
- `idx_org_id`: org_id 字段索引

### ftp_pricing_method_rule 表
- `idx_rule_code`: rule_code 字段索引

### ftp_pricing_curve_rule 表
- `idx_rule_code`: rule_code 字段索引

### ftp_adjustment_rule 表
- `idx_rule_code`: rule_code 字段索引

### ftp_combination_pricing_rule 表
- `idx_rule_code`: rule_code 字段索引

### ftp_calculation_result 表
- `idx_task_id`: task_id 字段索引
- `idx_transaction_id`: transaction_id 字段索引
- `idx_pricing_date`: pricing_date 字段索引

### ftp_transfer_pricing_record 表
- `idx_transaction_id`: transaction_id 字段索引
- `idx_pricing_date`: pricing_date 字段索引
- `idx_org_id`: org_id 字段索引