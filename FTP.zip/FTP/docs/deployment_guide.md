# 银行内部资金转移定价系统 - 部署指南

## 1. 环境准备

### 1.1 系统要求
- **操作系统**: Windows/Linux/macOS
- **Java版本**: JDK 17 或更高版本
- **内存**: 最少 4GB RAM（推荐 8GB）
- **磁盘空间**: 至少 2GB 可用空间
- **数据库**: MySQL 8.0 或更高版本

### 1.2 软件依赖
- **Maven**: 3.6.0 或更高版本
- **Git**: 2.0 或更高版本
- **Docker**: 20.10 或更高版本（可选）
- **Docker Compose**: 1.25 或更高版本（可选）

### 1.3 环境变量配置
```bash
# Java环境变量
JAVA_HOME=/path/to/jdk-17
PATH=$JAVA_HOME/bin:$PATH

# Maven环境变量
MAVEN_HOME=/path/to/apache-maven
PATH=$MAVEN_HOME/bin:$PATH
```

## 2. 数据库准备

### 2.1 创建数据库
```sql
-- 创建FTP系统数据库
CREATE DATABASE ftp_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 创建数据库用户并授权
CREATE USER 'ftp_user'@'%' IDENTIFIED BY 'StrongPassword123!';
GRANT ALL PRIVILEGES ON ftp_system.* TO 'ftp_user'@'%';
FLUSH PRIVILEGES;
```

### 2.2 数据库配置
编辑 `src/main/resources/application-prod.yml`:
```yaml
spring:
  datasource:
    url: jdbc:mysql://your-db-host:3306/ftp_system?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true
    username: ftp_user
    password: StrongPassword123!
    driver-class-name: com.mysql.cj.jdbc.Driver
    hikari:
      maximum-pool-size: 20
      minimum-idle: 5
      connection-timeout: 30000
      idle-timeout: 600000
      max-lifetime: 1800000
```

## 3. 项目构建

### 3.1 源码获取
```bash
# 克隆项目
git clone https://github.com/your-org/ftp-system.git
cd ftp-system

# 或者下载指定版本
wget https://github.com/your-org/ftp-system/archive/v1.0.0.tar.gz
tar -xzf v1.0.0.tar.gz
cd ftp-system-1.0.0
```

### 3.2 依赖安装
```bash
# 使用Maven下载依赖
mvn clean dependency:resolve
```

### 3.3 项目编译
```bash
# 编译项目
mvn clean compile

# 打包（包含测试）
mvn clean package

# 跳过测试打包
mvn clean package -DskipTests

# 查看依赖树
mvn dependency:tree
```

## 4. 配置文件说明

### 4.1 配置文件结构
```
src/main/resources/
├── application.yml          # 主配置文件
├── application-dev.yml      # 开发环境配置
├── application-test.yml     # 测试环境配置
└── application-prod.yml     # 生产环境配置
```

### 4.2 主配置文件 (application.yml)
```yaml
spring:
  application:
    name: ftp-system
  profiles:
    active: prod  # 根据环境修改
  jpa:
    hibernate:
      ddl-auto: validate  # 生产环境使用validate，开发环境可使用update
    show-sql: false
  flyway:
    enabled: true
    baseline-on-migrate: true
    locations: classpath:db/migration

server:
  port: 8080
  servlet:
    context-path: /api

springdoc:
  swagger-ui:
    enabled: false  # 生产环境禁用

logging:
  level:
    root: INFO
    com.bank.ftp: INFO
```

### 4.3 生产环境配置 (application-prod.yml)
```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/ftp_system?useUnicode=true&characterEncoding=utf-8&useSSL=true&serverTimezone=Asia/Shanghai
    username: ${DB_USERNAME:ftp_user}
    password: ${DB_PASSWORD:StrongPassword123!}
    driver-class-name: com.mysql.cj.jdbc.Driver
    hikari:
      maximum-pool-size: 20
      minimum-idle: 5
      connection-timeout: 30000
      idle-timeout: 600000
      max-lifetime: 1800000
      leak-detection-threshold: 60000

logging:
  level:
    root: WARN
    com.bank.ftp: INFO
  file:
    name: /var/log/ftp-system/ftp-system.log
    max-size: 100MB
    max-history: 30

management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics
  endpoint:
    health:
      show-details: never
```

## 5. 部署方式

### 5.1 传统部署

#### 5.1.1 直接运行JAR包
```bash
# 启动应用（前台运行）
java -jar target/ftp-system-1.0.0.jar

# 启动应用（后台运行）
nohup java -jar target/ftp-system-1.0.0.jar > /var/log/ftp-system.log 2>&1 &

# 指定配置文件启动
java -jar target/ftp-system-1.0.0.jar --spring.profiles.active=prod

# 指定JVM参数启动
java -Xms512m -Xmx2g -jar target/ftp-system-1.0.0.jar
```

#### 5.1.2 使用系统服务（Linux）
创建系统服务文件 `/etc/systemd/system/ftp-system.service`:
```ini
[Unit]
Description=Bank FTP System
After=network.target

[Service]
Type=simple
User=ftp-user
Group=ftp-group
WorkingDirectory=/opt/ftp-system
ExecStart=/usr/bin/java -Xms512m -Xmx2g -jar /opt/ftp-system/ftp-system-1.0.0.jar
SuccessExitStatus=143
TimeoutStopSec=10
Restart=on-failure
RestartSec=30

[Install]
WantedBy=multi-user.target
```

启动服务：
```bash
# 重新加载systemd配置
sudo systemctl daemon-reload

# 启动服务
sudo systemctl start ftp-system

# 设置开机自启
sudo systemctl enable ftp-system

# 查看服务状态
sudo systemctl status ftp-system

# 查看服务日志
sudo journalctl -u ftp-system -f
```

### 5.2 Docker部署

#### 5.2.1 构建Docker镜像
```dockerfile
# Dockerfile
FROM openjdk:17-jdk-slim

LABEL maintainer="dev-team@bank.com"
LABEL version="1.0.0"
LABEL description="Bank Internal Funds Transfer Pricing System"

WORKDIR /app

# 创建应用用户
RUN groupadd -r ftpgroup && useradd -r -g ftpgroup ftpuser

# 复制应用JAR文件
COPY target/ftp-system-1.0.0.jar app.jar

# 更改文件所有者
RUN chown ftpuser:ftpgroup app.jar
USER ftpuser

# 暴露端口
EXPOSE 8080

# JVM参数优化
ENV JAVA_OPTS="-Xms512m -Xmx2g -XX:+UseG1GC -XX:MaxGCPauseMillis=200"

# 启动命令
ENTRYPOINT ["sh", "-c", "java $JAVA_OPTS -jar app.jar"]

HEALTHCHECK --interval=30s --timeout=3s --start-period=60s --retries=3 \
  CMD curl -f http://localhost:8080/actuator/health || exit 1
```

构建镜像：
```bash
# 构建应用
mvn clean package -DskipTests

# 构建Docker镜像
docker build -t bank/ftp-system:1.0.0 .

# 查看镜像
docker images bank/ftp-system
```

#### 5.2.2 运行Docker容器
```bash
# 单独运行容器
docker run -d \
  --name ftp-system \
  -p 8080:8080 \
  -e SPRING_PROFILES_ACTIVE=prod \
  -e DB_HOST=mysql-host \
  -e DB_PORT=3306 \
  -e DB_NAME=ftp_system \
  -e DB_USER=ftp_user \
  -e DB_PASSWORD=StrongPassword123! \
  -v /var/log/ftp-system:/var/log/ftp-system \
  bank/ftp-system:1.0.0

# 查看容器日志
docker logs -f ftp-system
```

#### 5.2.3 Docker Compose部署
创建 `docker-compose.yml`:
```yaml
version: '3.8'

services:
  mysql:
    image: mysql:8.0
    container_name: ftp-mysql
    environment:
      MYSQL_ROOT_PASSWORD: RootPassword123!
      MYSQL_DATABASE: ftp_system
      MYSQL_USER: ftp_user
      MYSQL_PASSWORD: StrongPassword123!
    ports:
      - "3306:3306"
    volumes:
      - mysql_data:/var/lib/mysql
      - ./conf/mysql.cnf:/etc/mysql/conf.d/custom.cnf
    networks:
      - ftp-network
    restart: unless-stopped

  ftp-system:
    build: .
    container_name: ftp-application
    depends_on:
      - mysql
    environment:
      - SPRING_PROFILES_ACTIVE=docker
      - DB_HOST=mysql
      - DB_PORT=3306
      - DB_NAME=ftp_system
      - DB_USER=ftp_user
      - DB_PASSWORD=StrongPassword123!
    ports:
      - "8080:8080"
    volumes:
      - ./logs:/var/log/ftp-system
    networks:
      - ftp-network
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/actuator/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s

volumes:
  mysql_data:

networks:
  ftp-network:
    driver: bridge
```

使用Docker Compose启动：
```bash
# 启动服务
docker-compose up -d

# 查看服务状态
docker-compose ps

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

### 5.3 Kubernetes部署

#### 5.3.1 部署YAML文件
创建 `k8s-deployment.yaml`:
```yaml
---
apiVersion: v1
kind: Namespace
metadata:
  name: ftp-system
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: ftp-config
  namespace: ftp-system
data:
  application-prod.yml: |
    spring:
      datasource:
        url: jdbc:mysql://ftp-mysql:3306/ftp_system
        username: ftp_user
        password: ${DB_PASSWORD}
    server:
      port: 8080
---
apiVersion: v1
kind: Secret
metadata:
  name: ftp-secrets
  namespace: ftp-system
type: Opaque
data:
  db-password: U3Ryb25nUGFzc3dvcmQxMjMh  # Base64 encoded
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ftp-system
  namespace: ftp-system
spec:
  replicas: 2
  selector:
    matchLabels:
      app: ftp-system
  template:
    metadata:
      labels:
        app: ftp-system
    spec:
      containers:
      - name: ftp-system
        image: bank/ftp-system:1.0.0
        ports:
        - containerPort: 8080
        env:
        - name: SPRING_PROFILES_ACTIVE
          value: "k8s"
        - name: DB_PASSWORD
          valueFrom:
            secretKeyRef:
              name: ftp-secrets
              key: db-password
        volumeMounts:
        - name: config-volume
          mountPath: /app/config
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        livenessProbe:
          httpGet:
            path: /actuator/health
            port: 8080
          initialDelaySeconds: 60
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /actuator/health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
      volumes:
      - name: config-volume
        configMap:
          name: ftp-config
---
apiVersion: v1
kind: Service
metadata:
  name: ftp-service
  namespace: ftp-system
spec:
  selector:
    app: ftp-system
  ports:
    - protocol: TCP
      port: 80
      targetPort: 8080
  type: LoadBalancer
```

部署到Kubernetes：
```bash
# 应用部署配置
kubectl apply -f k8s-deployment.yaml

# 查看部署状态
kubectl get pods -n ftp-system

# 查看服务
kubectl get svc -n ftp-system

# 查看日志
kubectl logs -f deployment/ftp-system -n ftp-system
```

## 6. 启动脚本

### 6.1 Linux启动脚本
创建 `/opt/ftp-system/start.sh`:
```bash
#!/bin/bash

# FTP System 启动脚本
APP_NAME="ftp-system"
APP_JAR="/opt/ftp-system/ftp-system-1.0.0.jar"
LOG_DIR="/var/log/ftp-system"
PID_FILE="/var/run/${APP_NAME}.pid"
CONFIG_DIR="/opt/ftp-system/config"

# 创建日志目录
mkdir -p $LOG_DIR

# JVM参数
JVM_OPTS="-Xms512m -Xmx2g"
JVM_OPTS="$JVM_OPTS -XX:+UseG1GC -XX:MaxGCPauseMillis=200"
JVM_OPTS="$JVM_OPTS -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=$LOG_DIR"
JVM_OPTS="$JVM_OPTS -Dlogging.file.path=$LOG_DIR"

# 应用参数
APP_OPTS="--spring.config.location=file:$CONFIG_DIR/"
APP_OPTS="$APP_OPTS --spring.profiles.active=prod"

# 检查进程是否运行
if [ -f $PID_FILE ]; then
    PID=$(cat $PID_FILE)
    if kill -0 $PID 2>/dev/null; then
        echo "$APP_NAME is already running (PID: $PID)"
        exit 1
    fi
fi

echo "Starting $APP_NAME..."

# 启动应用
nohup java $JVM_OPTS -jar $APP_JAR $APP_OPTS >> $LOG_DIR/start.log 2>&1 &
START_PID=$!

# 等待应用启动
sleep 5

# 获取实际PID
ACTUAL_PID=$(pgrep -f "$APP_JAR")
if [ ! -z "$ACTUAL_PID" ]; then
    echo $ACTUAL_PID > $PID_FILE
    echo "$APP_NAME started successfully (PID: $ACTUAL_PID)"
else
    echo "Failed to start $APP_NAME"
    exit 1
fi
```

### 6.2 Windows启动脚本
创建 `start.bat`:
```batch
@echo off
setlocal

set APP_NAME=ftp-system
set APP_JAR=%~dp0ftp-system-1.0.0.jar
set LOG_DIR=%~dp0logs
set CONFIG_DIR=%~dp0config

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

set JVM_OPTS=-Xms512m -Xmx2g
set JVM_OPTS=%JVM_OPTS% -XX:+UseG1GC -XX:MaxGCPauseMillis=200
set JVM_OPTS=%JVM_OPTS% -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=%LOG_DIR%

set APP_OPTS=--spring.config.location=file:%CONFIG_DIR%/
set APP_OPTS=%APP_OPTS% --spring.profiles.active=prod

echo Starting %APP_NAME%...

java %JVM_OPTS% -jar %APP_JAR% %APP_OPTS% > %LOG_DIR%\start.log 2>&1

if %ERRORLEVEL% EQU 0 (
    echo %APP_NAME% started successfully
) else (
    echo Failed to start %APP_NAME%
    exit /b 1
)

endlocal
```

## 7. 验证部署

### 7.1 健康检查
```bash
# 检查应用是否启动
curl -I http://localhost:8080/api/actuator/health

# 检查API文档
curl -s http://localhost:8080/api/v3/api-docs | jq .

# 检查数据库连接
curl -s http://localhost:8080/api/actuator/db | jq .
```

### 7.2 功能验证
```bash
# 测试系统管理模块
curl -X GET http://localhost:8080/api/system/user/list \
  -H "Content-Type: application/json"

# 测试公共参数模块
curl -X GET http://localhost:8080/api/parameter/currency/list \
  -H "Content-Type: application/json"

# 测试FTP计算模块
curl -X GET http://localhost:8080/api/ftp/rule/method/list \
  -H "Content-Type: application/json"
```

## 8. 监控配置

### 8.1 Prometheus配置
在 `prometheus.yml` 中添加：
```yaml
scrape_configs:
  - job_name: 'ftp-system'
    static_configs:
      - targets: ['localhost:8080']
    metrics_path: '/actuator/prometheus'
    scrape_interval: 15s
```

### 8.2 日志配置
应用日志配置在 `logback-spring.xml`:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <include resource="org/springframework/boot/logging/logback/defaults.xml"/>
    
    <springProfile name="dev">
        <root level="INFO">
            <appender-ref ref="CONSOLE"/>
        </root>
    </springProfile>
    
    <springProfile name="prod">
        <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
            <file>/var/log/ftp-system/ftp-system.log</file>
            <encoder>
                <pattern>%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n</pattern>
            </encoder>
            <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
                <fileNamePattern>/var/log/ftp-system/ftp-system.%d{yyyy-MM-dd}.%i.log</fileNamePattern>
                <timeBasedFileNamingAndTriggeringPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedFNATP">
                    <maxFileSize>100MB</maxFileSize>
                </timeBasedFileNamingAndTriggeringPolicy>
                <maxHistory>30</maxHistory>
            </rollingPolicy>
        </appender>
        
        <root level="INFO">
            <appender-ref ref="FILE"/>
        </root>
    </springProfile>
</configuration>
```

## 9. 故障排除

### 9.1 常见问题
1. **数据库连接失败**
   ```bash
   # 检查数据库服务
   telnet mysql-host 3306
   
   # 检查数据库配置
   mysql -h mysql-host -u ftp_user -p
   ```

2. **端口占用**
   ```bash
   # 检查端口占用
   netstat -tlnp | grep 8080
   lsof -i :8080
   
   # 杀死占用进程
   kill -9 $(lsof -t -i:8080)
   ```

3. **内存不足**
   ```bash
   # 检查内存使用
   free -h
   jstat -gc <pid>
   ```

### 9.2 日志分析
```bash
# 实时查看日志
tail -f /var/log/ftp-system/ftp-system.log

# 查找错误日志
grep ERROR /var/log/ftp-system/ftp-system.log

# 查找特定时间段的日志
sed -n '/2023-10-01 10:00/,/2023-10-01 11:00/p' /var/log/ftp-system/ftp-system.log
```

## 10. 备份与恢复

### 10.1 数据库备份
```bash
# 完整备份
mysqldump -u ftp_user -p ftp_system > ftp_system_backup_$(date +%Y%m%d_%H%M%S).sql

# 增量备份（使用binlog）
mysqlbinlog --start-datetime="2023-10-01 00:00:00" --stop-datetime="2023-10-02 00:00:00" /var/log/mysql/mysql-bin.000001
```

### 10.2 应用备份
```bash
# 备份配置文件
tar -czf config_backup_$(date +%Y%m%d_%H%M%S).tar.gz /opt/ftp-system/config/

# 备份日志文件
tar -czf logs_backup_$(date +%Y%m%d_%H%M%S).tar.gz /var/log/ftp-system/
```

### 10.3 恢复步骤
```bash
# 恢复数据库
mysql -u ftp_user -p ftp_system < ftp_system_backup_YYYYMMDD_HHMMSS.sql

# 恢复配置
tar -xzf config_backup_YYYYMMDD_HHMMSS.tar.gz -C /opt/ftp-system/

# 重启应用
systemctl restart ftp-system
```

## 11. 性能调优

### 11.1 JVM调优参数
```bash
# 生产环境JVM参数示例
-Xms2g -Xmx2g
-XX:+UseG1GC
-XX:MaxGCPauseMillis=200
-XX:G1HeapRegionSize=16m
-XX:G1NewSizePercent=30
-XX:G1MaxNewSizePercent=40
-XX:G1MixedGCLiveThresholdPercent=90
-XX:InitiatingHeapOccupancyPercent=35
-XX:+PrintGC -XX:+PrintGCDetails -XX:+PrintGCTimeStamps
-Xloggc:/var/log/ftp-system/gc.log
```

### 11.2 数据库连接池调优
```yaml
spring:
  datasource:
    hikari:
      maximum-pool-size: 20  # 根据并发量调整
      minimum-idle: 10       # 保持最小连接数
      connection-timeout: 30000
      idle-timeout: 600000   # 10分钟
      max-lifetime: 1800000  # 30分钟
      leak-detection-threshold: 60000
```

### 11.3 应用层缓存配置
```yaml
spring:
  cache:
    type: redis
    redis:
      time-to-live: 3600000  # 1小时
  redis:
    host: localhost
    port: 6379
    timeout: 2000ms
    lettuce:
      pool:
        max-active: 20
        max-idle: 10
        min-idle: 5
```

以上部署指南涵盖了从环境准备到生产部署的全过程，确保系统能够稳定可靠地运行。