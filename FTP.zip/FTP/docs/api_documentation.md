# 银行内部资金转移定价系统 - 接口文档

## 1. 系统管理模块

### 1.1 用户管理接口

#### 获取所有用户
- **接口路径**: `GET /api/system/user/list`
- **请求参数**: 无
- **返回示例**:
```json
{
  "code": 200,
  "message": "操作成功",
  "data": [
    {
      "id": 1,
      "username": "admin",
      "realName": "管理员",
      "email": "admin@example.com",
      "phone": "13800138000",
      "status": 1,
      "lastLoginTime": "2023-10-01T10:00:00"
    }
  ]
}
```

#### 创建用户
- **接口路径**: `POST /api/system/user`
- **请求参数**:
```json
{
  "username": "testuser",
  "password": "password123",
  "realName": "测试用户",
  "email": "test@example.com",
  "phone": "13800138001",
  "status": 1
}
```
- **返回示例**:
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 2,
    "username": "testuser",
    "realName": "测试用户",
    "email": "test@example.com",
    "phone": "13800138001",
    "status": 1
  }
}
```

#### 更新用户
- **接口路径**: `PUT /api/system/user/{id}`
- **请求参数**:
```json
{
  "realName": "更新的测试用户",
  "email": "updated@example.com",
  "status": 1
}
```

#### 删除用户
- **接口路径**: `DELETE /api/system/user/{id}`

#### 重置密码
- **接口路径**: `POST /api/system/user/{id}/reset-password`
- **请求参数**: `newPassword=password123`

#### 修改密码
- **接口路径**: `POST /api/system/user/{id}/change-password`
- **请求参数**: `oldPassword=oldpass123&newPassword=newpass123`

### 1.2 角色管理接口

#### 获取所有角色
- **接口路径**: `GET /api/system/role/list`

#### 创建角色
- **接口路径**: `POST /api/system/role`
- **请求参数**:
```json
{
  "roleName": "管理员",
  "roleCode": "ADMIN",
  "description": "系统管理员角色",
  "status": 1
}
```

#### 更新角色
- **接口路径**: `PUT /api/system/role/{id}`
- **请求参数**:
```json
{
  "roleName": "更新的角色",
  "description": "更新的角色描述",
  "status": 1
}
```

#### 删除角色
- **接口路径**: `DELETE /api/system/role/{id}`

### 1.3 密码策略管理接口

#### 获取当前激活的密码策略
- **接口路径**: `GET /api/system/password-policy/active`

#### 创建密码策略
- **接口路径**: `POST /api/system/password-policy`
- **请求参数**:
```json
{
  "policyName": "强密码策略",
  "minLength": 8,
  "maxLength": 20,
  "requireUpper": 1,
  "requireLower": 1,
  "requireDigit": 1,
  "requireSpecial": 1,
  "passwordExpireDays": 90,
  "passwordHistoryCount": 5,
  "status": 1
}
```

#### 激活密码策略
- **接口路径**: `POST /api/system/password-policy/{id}/activate`

#### 验证密码
- **接口路径**: `POST /api/system/password-policy/validate`
- **请求参数**: `password=testPassword123!`

### 1.4 系统配置管理接口

#### 获取所有系统配置
- **接口路径**: `GET /api/system/config/list`

#### 根据配置键获取系统配置
- **接口路径**: `GET /api/system/config/key/{configKey}`

#### 创建系统配置
- **接口路径**: `POST /api/system/config`
- **请求参数**:
```json
{
  "configKey": "max_login_attempts",
  "configValue": "5",
  "configName": "最大登录尝试次数",
  "description": "账户锁定前的最大登录尝试次数",
  "configType": "number"
}
```

#### 更新系统配置
- **接口路径**: `PUT /api/system/config/{id}`
- **请求参数**: 同创建

#### 删除系统配置
- **接口路径**: `DELETE /api/system/config/{id}`

## 2. 公共参数模块

### 2.1 币种管理接口

#### 获取所有币种
- **接口路径**: `GET /api/parameter/currency/list`

#### 获取启用的币种
- **接口路径**: `GET /api/parameter/currency/active`

#### 创建币种
- **接口路径**: `POST /api/parameter/currency`
- **请求参数**:
```json
{
  "currencyCode": "CNY",
  "currencyName": "人民币",
  "currencySymbol": "¥",
  "decimalPlaces": 2,
  "isDefault": 1,
  "status": 1
}
```

#### 设置默认币种
- **接口路径**: `POST /api/parameter/currency/{id}/set-default`

### 2.2 汇率管理接口

#### 获取所有汇率
- **接口路径**: `GET /api/parameter/exchange-rate/list`

#### 根据日期获取汇率
- **接口路径**: `GET /api/parameter/exchange-rate/date/{rateDate}`

#### 创建汇率
- **接口路径**: `POST /api/parameter/exchange-rate`
- **请求参数**:
```json
{
  "sourceCurrencyId": 1,
  "targetCurrencyId": 2,
  "exchangeRate": 6.5,
  "rateDate": "2023-10-01"
}
```

### 2.3 口径管理接口

#### 获取所有口径
- **接口路径**: `GET /api/parameter/caliber/list`

#### 创建口径
- **接口路径**: `POST /api/parameter/caliber`
- **请求参数**:
```json
{
  "caliberCode": "BASE",
  "caliberName": "基础口径",
  "description": "基础统计口径",
  "caliberRule": "{\"type\":\"basic\",\"formula\":\"sum\"}",
  "status": 1
}
```

### 2.4 机构管理接口

#### 获取机构树
- **接口路径**: `GET /api/parameter/organization/tree`

#### 创建机构
- **接口路径**: `POST /api/parameter/organization`
- **请求参数**:
```json
{
  "orgCode": "ORG001",
  "orgName": "总行",
  "orgType": "HEAD_OFFICE",
  "parentId": 0,
  "level": 1,
  "sortOrder": 0,
  "status": 1
}
```

## 3. 资金转移定价模块

### 3.1 规则管理接口

#### 3.1.1 定价方法规则管理

##### 获取所有定价方法规则
- **接口路径**: `GET /api/ftp/rule/method/list`

##### 创建定价方法规则
- **接口路径**: `POST /api/ftp/rule/method`
- **请求参数**:
```json
{
  "ruleCode": "METHOD001",
  "ruleName": "期限匹配定价规则",
  "pricingMethod": "duration_matching",
  "productTypeIds": [1, 2],
  "orgIds": [1],
  "amountMin": 10000,
  "amountMax": 1000000,
  "termMin": 1,
  "termMax": 365,
  "priority": 10,
  "status": 1
}
```

#### 3.1.2 定价曲线规则管理

##### 获取所有定价曲线规则
- **接口路径**: `GET /api/ftp/rule/curve/list`

##### 创建定价曲线规则
- **接口路径**: `POST /api/ftp/rule/curve`
- **请求参数**:
```json
{
  "ruleCode": "CURVE001",
  "ruleName": "国债曲线规则",
  "curveId": 1,
  "productTypeIds": [1],
  "orgIds": [1],
  "amountMin": 10000,
  "amountMax": 1000000,
  "termMin": 1,
  "termMax": 365,
  "priority": 10,
  "status": 1
}
```

#### 3.1.3 调整项规则管理

##### 获取所有调整项规则
- **接口路径**: `GET /api/ftp/rule/adjustment/list`

##### 创建调整项规则
- **接口路径**: `POST /api/ftp/rule/adjustment`
- **请求参数**:
```json
{
  "ruleCode": "ADJUST001",
  "ruleName": "流动性调整规则",
  "adjustmentType": "liquidity",
  "adjustmentValue": 0.005,
  "adjustmentMode": "add",
  "productTypeIds": [1],
  "orgIds": [1],
  "amountMin": 10000,
  "amountMax": 1000000,
  "termMin": 1,
  "termMax": 365,
  "priority": 10,
  "status": 1
}
```

#### 3.1.4 组合定价规则管理

##### 获取所有组合定价规则
- **接口路径**: `GET /api/ftp/rule/combination/list`

##### 创建组合定价规则
- **接口路径**: `POST /api/ftp/rule/combination`
- **请求参数**:
```json
{
  "ruleCode": "COMBO001",
  "ruleName": "综合定价规则",
  "methodRuleIds": [1],
  "curveRuleIds": [1],
  "adjustmentRuleIds": [1],
  "productTypeIds": [1],
  "orgIds": [1],
  "priority": 10,
  "status": 1
}
```

#### 3.1.5 规则版本管理

##### 获取规则版本列表
- **接口路径**: `GET /api/ftp/rule/version/rule/{ruleType}/{ruleId}`

##### 创建规则版本
- **接口路径**: `POST /api/ftp/rule/version`
- **请求参数**:
```json
{
  "ruleType": "method",
  "ruleId": 1,
  "ruleCode": "METHOD001",
  "versionNo": 2,
  "ruleContent": "{\"method\":\"duration_matching\",\"params\":{\"algorithm\":\"linear\"}}",
  "description": "更新算法为线性插值"
}
```

### 3.2 定价管理接口

#### 执行批量定价
- **接口路径**: `POST /api/ftp/pricing/batch`
- **请求参数**:
```json
{
  "transactionIds": [1, 2, 3],
  "taskName": "批量定价任务",
  "async": true
}
```

#### 获取任务监控信息
- **接口路径**: `GET /api/ftp/pricing/monitor/{taskId}`

#### 获取任务进度
- **接口路径**: `GET /api/ftp/pricing/progress/{taskId}`

#### 根据任务ID获取结果
- **接口路径**: `GET /api/ftp/pricing/results/task/{taskId}`

#### 多维度查询结果
- **接口路径**: `POST /api/ftp/pricing/results/query`
- **请求参数**:
```json
{
  "taskId": 1,
  "transactionId": null,
  "transactionNo": null,
  "pricingDate": "2023-10-01",
  "page": 0,
  "size": 10
}
```

#### 生成分析报告
- **接口路径**: `GET /api/ftp/pricing/analysis/{taskId}`

#### 导出结果为Excel
- **接口路径**: `GET /api/ftp/pricing/export/excel/{taskId}`

#### 导出结果为CSV
- **接口路径**: `GET /api/ftp/pricing/export/csv/{taskId}`

## 4. 报表集成模块

### 4.1 报表定义管理接口

#### 获取所有报表定义
- **接口路径**: `GET /api/report/definition/list`

#### 创建报表定义
- **接口路径**: `POST /api/report/definition`
- **请求参数**:
```json
{
  "reportCode": "FTP_REPORT_001",
  "reportName": "FTP定价结果报表",
  "description": "展示FTP定价结果的详细报表",
  "templateId": 1,
  "dataSourceConfig": "{\"type\":\"ftp_result\",\"query\":\"SELECT * FROM ftp_calculation_result WHERE task_id = ?\"}",
  "status": 1
}
```

### 4.2 报表参数管理接口

#### 根据报表ID获取参数列表
- **接口路径**: `GET /api/report/parameter/report/{reportId}`

#### 创建报表参数
- **接口路径**: `POST /api/report/parameter`
- **请求参数**:
```json
{
  "reportId": 1,
  "paramName": "任务ID",
  "paramCode": "taskId",
  "paramType": "number",
  "paramDefaultValue": "1",
  "required": 1,
  "sortOrder": 1
}
```

### 4.3 报表模板管理接口

#### 上传报表模板
- **接口路径**: `POST /api/report/template`
- **请求参数**: multipart/form-data
  - templateName: 模板名称
  - templateType: excel
  - file: 文件
  - status: 1

#### 下载报表模板文件
- **接口路径**: `GET /api/report/template/download/{id}`

### 4.4 报表调度管理接口

#### 创建报表调度
- **接口路径**: `POST /api/report/schedule`
- **请求参数**:
```json
{
  "reportId": 1,
  "scheduleName": "每日FTP报表",
  "cronExpression": "0 0 2 * * ?",
  "paramValues": "{\"taskId\":\"1\"}",
  "outputFormat": "excel",
  "emailRecipients": "admin@example.com,user@example.com",
  "status": 1
}
```

### 4.5 报表生成接口

#### 生成报表
- **接口路径**: `POST /api/report/generate/{reportId}`
- **请求参数**:
```json
{
  "taskId": 1,
  "startDate": "2023-10-01",
  "endDate": "2023-10-31"
}
```

## 错误码说明

| 错误码 | 说明 |
|--------|------|
| 200 | 操作成功 |
| 400 | 请求参数错误 |
| 401 | 未授权 |
| 403 | 禁止访问 |
| 404 | 资源不存在 |
| 500 | 服务器内部错误 |

## 认证方式

所有接口需要在请求头中携带认证信息：
```
Authorization: Bearer {token}
```