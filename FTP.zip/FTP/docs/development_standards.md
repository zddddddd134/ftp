# 银行内部资金转移定价系统 - 开发规范文档

## 1. 项目结构规范

### 1.1 标准项目结构
```
d:\ZDD\shixi\FTP\
├── src/
│   ├── main/
│   │   ├── java/com/bank/ftp/
│   │   │   ├── FtpApplication.java
│   │   │   ├── common/                 # 公共模块
│   │   │   │   ├── constant/           # 常量定义
│   │   │   │   ├── exception/          # 异常处理
│   │   │   │   ├── util/               # 工具类
│   │   │   │   ├── response/           # 统一响应格式
│   │   │   │   └── annotation/         # 自定义注解
│   │   │   ├── config/                 # 配置类
│   │   │   ├── system/                 # 系统管理模块
│   │   │   │   ├── controller/
│   │   │   │   ├── service/
│   │   │   │   ├── repository/
│   │   │   │   ├── entity/
│   │   │   │   └── dto/
│   │   │   ├── parameter/              # 公共参数模块
│   │   │   │   ├── controller/
│   │   │   │   ├── service/
│   │   │   │   ├── repository/
│   │   │   │   ├── entity/
│   │   │   │   └── dto/
│   │   │   ├── report/                 # 报表集成模块
│   │   │   │   ├── controller/
│   │   │   │   ├── service/
│   │   │   │   ├── repository/
│   │   │   │   ├── entity/
│   │   │   │   └── dto/
│   │   │   └── ftp/                    # 资金转移定价模块
│   │   │       ├── controller/
│   │   │       ├── service/
│   │   │       │   ├── rule/           # 规则管理服务
│   │   │       │   ├── pricing/        # 定价管理服务
│   │   │       │   └── result/         # 结果查询服务
│   │   │       ├── repository/
│   │   │       ├── entity/
│   │   │       ├── dto/
│   │   │       ├── calculator/         # FTP计算引擎
│   │   │       │   ├── method/         # 定价方法实现
│   │   │       │   ├── matcher/        # 规则匹配器
│   │   │       │   ├── adjuster/       # 调整项计算器
│   │   │       │   └── combiner/       # 组合定价器
│   │   │       └── rule/               # 规则引擎相关
│   │   └── resources/
│   │       ├── application.yml
│   │       ├── application-dev.yml
│   │       ├── application-prod.yml
│   │       └── db/migration/           # 数据库迁移脚本
│   └── test/                           # 单元测试
├── docs/                               # 文档
├── target/                             # 编译输出
└── pom.xml
```

### 1.2 包命名规范
- 顶级包名: `com.bank.ftp`
- 控制器: `controller`
- 服务层: `service`
- 数据访问层: `repository`
- 实体类: `entity`
- 数据传输对象: `dto`
- 工具类: `util`
- 配置类: `config`
- 异常类: `exception`
- 常量类: `constant`

## 2. 代码规范

### 2.1 Java代码规范

#### 2.1.1 命名规范
```java
// 类名使用帕斯卡命名法
public class UserService {
    // 常量使用全大写下划线分隔
    public static final String DEFAULT_STATUS = "active";
    
    // 变量和方法使用驼峰命名法
    private Long userId;
    
    public User getUserById(Long id) {
        // ...
        return user;
    }
}
```

#### 2.1.2 类结构规范
```java
/**
 * 用户服务类
 * 提供用户相关的业务操作
 *
 * @author System
 * @since 1.0.0
 */
@Service
@RequiredArgsConstructor
public class UserService {
    
    // 1. 私有常量
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);
    
    // 2. 注入的依赖
    private final UserRepository userRepository;
    
    // 3. 私有变量
    private String cacheKey;
    
    // 4. 构造函数（如果需要）
    
    // 5. 公共方法
    public User getUserById(Long id) {
        // 方法实现
    }
    
    // 6. 私有方法
    private void validateUser(User user) {
        // 验证逻辑
    }
}
```

#### 2.1.3 注释规范
```java
/**
 * 获取用户信息
 * 根据用户ID查询用户详细信息
 *
 * @param id 用户ID，不允许为空
 * @return 用户对象，如果用户不存在返回null
 * @throws BusinessException 当用户ID无效时抛出
 */
public User getUserById(Long id) {
    // 简单注释说明复杂逻辑
    // 验证用户ID的有效性
    if (id == null || id <= 0) {
        throw new BusinessException("用户ID不能为空或小于等于0");
    }
    
    // 查询用户信息
    return userRepository.findById(id)
            .orElse(null);
}
```

### 2.2 Controller层规范

#### 2.2.1 REST API设计规范
```java
@Tag(name = "用户管理", description = "用户管理相关接口")
@RestController
@RequestMapping("/system/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @Operation(summary = "获取所有用户", description = "返回系统中所有用户的信息")
    @GetMapping("/list")
    public Result<List<User>> getAllUsers() {
        return Result.success(userService.getAllUsers());
    }

    @Operation(summary = "根据ID获取用户")
    @GetMapping("/{id}")
    public Result<User> getUserById(@PathVariable Long id) {
        return Result.success(userService.getUserById(id));
    }

    @Operation(summary = "创建用户")
    @PostMapping
    public Result<User> createUser(@Valid @RequestBody UserDTO userDTO) {
        return Result.success(userService.createUser(userDTO));
    }
}
```

#### 2.2.2 参数验证规范
```java
@Data
public class UserDTO {
    private Long id;

    @NotBlank(message = "用户名不能为空")
    @Size(min = 3, max = 20, message = "用户名长度必须在3-20之间")
    private String username;

    @NotBlank(message = "密码不能为空")
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d@$!%*?&]{8,}$", 
             message = "密码必须包含大小写字母和数字，且长度不少于8位")
    private String password;

    @Email(message = "邮箱格式不正确")
    private String email;
}
```

### 2.3 Service层规范

#### 2.3.1 事务管理规范
```java
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true) // 默认只读事务
public class UserService {

    private final UserRepository userRepository;

    /**
     * 查询方法保持只读
     */
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    /**
     * 修改方法使用读写事务
     */
    @Transactional
    public User createUser(UserDTO userDTO) {
        if (userRepository.existsByUsername(userDTO.getUsername())) {
            throw new BusinessException("用户名已存在");
        }

        User user = new User();
        BeanUtils.copyProperties(userDTO, user);
        user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        user.setStatus(1);
        return userRepository.save(user);
    }

    /**
     * 新增方法使用Propagation.REQUIRED
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public User updateUser(Long id, UserDTO userDTO) {
        User user = getUserById(id);
        // 更新逻辑
        return userRepository.save(user);
    }
}
```

#### 2.3.2 异常处理规范
```java
@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new BusinessException("用户不存在"));
    }

    @Transactional
    public User createUser(UserDTO userDTO) {
        try {
            // 检查用户名是否已存在
            if (userRepository.existsByUsername(userDTO.getUsername())) {
                throw new BusinessException("用户名已存在");
            }

            User user = new User();
            BeanUtils.copyProperties(userDTO, user);
            return userRepository.save(user);
        } catch (DataIntegrityViolationException e) {
            // 处理数据库约束违反异常
            throw new BusinessException("数据完整性错误：" + e.getMessage());
        } catch (Exception e) {
            // 记录错误日志
            log.error("创建用户失败，用户信息：{}", userDTO, e);
            throw new BusinessException("创建用户失败");
        }
    }
}
```

### 2.4 Entity层规范

#### 2.4.1 JPA实体规范
```java
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "sys_user")
public class User extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "username", nullable = false, unique = true, length = 50)
    private String username;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "real_name", length = 50)
    private String realName;

    @Column(name = "email", length = 100)
    @Email
    private String email;

    @Column(name = "status")
    private Integer status = 1;

    @Column(name = "last_login_time")
    private LocalDateTime lastLoginTime;
}
```

#### 2.4.2 基础实体类
```java
@Data
@MappedSuperclass
public class BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_time", updatable = false)
    @CreationTimestamp
    private LocalDateTime createdTime;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_time")
    @UpdateTimestamp
    private LocalDateTime updatedTime;

    @Column(name = "deleted")
    private Integer deleted = 0;
}
```

### 2.5 Repository层规范

#### 2.5.1 Repository接口规范
```java
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    boolean existsByUsername(String username);
    
    // 自定义查询方法
    @Query("SELECT u FROM User u WHERE u.status = :status AND u.deleted = 0")
    List<User> findByStatus(@Param("status") Integer status);
    
    // 使用原生SQL查询
    @Query(value = "SELECT * FROM sys_user WHERE username LIKE %:keyword%", nativeQuery = true)
    List<User> findByKeyword(@Param("keyword") String keyword);
}
```

## 3. 数据库规范

### 3.1 命名规范
- 表名: 使用复数形式，下划线分隔，前缀统一（如sys_, param_, ftp_, rpt_）
- 字段名: 使用下划线分隔的小写字母
- 索引名: idx_表名_字段名
- 外键名: fk_当前表_引用表
- 唯一约束: uk_表名_字段名

### 3.2 字段类型规范
```sql
-- 主键
id BIGINT AUTO_INCREMENT PRIMARY KEY

-- 时间戳
created_time DATETIME DEFAULT CURRENT_TIMESTAMP
updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP

-- 逻辑删除标记
deleted TINYINT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'

-- 状态字段
status TINYINT DEFAULT 1 COMMENT '状态：0-禁用，1-启用'

-- 金额字段
amount DECIMAL(20,2) NOT NULL COMMENT '金额'

-- 利率字段
rate DECIMAL(10,6) NOT NULL COMMENT '利率'
```

### 3.3 数据库迁移脚本规范
```sql
-- V1__init_system_tables.sql
-- 文件名格式：V{版本号}__{描述}.sql

-- 系统管理模块表结构
CREATE TABLE sys_user (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '用户ID',
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(255) NOT NULL COMMENT '密码',
    status TINYINT DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted TINYINT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 创建索引
CREATE INDEX idx_username ON sys_user(username);
CREATE INDEX idx_status ON sys_user(status);
```

## 4. 配置规范

### 4.1 application.yml规范
```yaml
spring:
  application:
    name: ftp-system
  profiles:
    active: dev
  datasource:
    url: jdbc:mysql://localhost:3306/ftp_system?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=Asia/Shanghai
    username: root
    password: root
    driver-class-name: com.mysql.cj.jdbc.Driver
  jpa:
    hibernate:
      ddl-auto: validate
    show-sql: true
    properties:
      hibernate:
        dialect: org.hibernate.dialect.MySQLDialect
        format_sql: true
  flyway:
    enabled: true
    baseline-on-migrate: true
    locations: classpath:db/migration

server:
  port: 8080
  servlet:
    context-path: /api

springdoc:
  api-docs:
    path: /v3/api-docs
  swagger-ui:
    path: /swagger-ui.html

logging:
  level:
    com.bank.ftp: debug
    org.hibernate.SQL: debug
```

### 4.2 环境配置规范
- `application.yml`: 主配置文件
- `application-dev.yml`: 开发环境配置
- `application-test.yml`: 测试环境配置
- `application-prod.yml`: 生产环境配置

## 5. 测试规范

### 5.1 单元测试规范
```java
@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.yml")
class UserServiceTest {

    @Autowired
    private UserService userService;

    @MockBean
    private UserRepository userRepository;

    @Test
    @DisplayName("根据ID获取用户 - 成功")
    void getUserById_Success() {
        // Given
        Long userId = 1L;
        User mockUser = new User();
        mockUser.setId(userId);
        mockUser.setUsername("testuser");

        when(userRepository.findById(userId)).thenReturn(Optional.of(mockUser));

        // When
        User result = userService.getUserById(userId);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(userId);
        assertThat(result.getUsername()).isEqualTo("testuser");
        
        verify(userRepository, times(1)).findById(userId);
    }

    @Test
    @DisplayName("根据ID获取用户 - 用户不存在")
    void getUserById_UserNotFound() {
        // Given
        Long userId = 999L;
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        // When & Then
        assertThatThrownBy(() -> userService.getUserById(userId))
                .isInstanceOf(BusinessException.class)
                .hasMessage("用户不存在");
    }
}
```

### 5.2 集成测试规范
```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = "classpath:application-test.yml")
class UserControllerIntegrationTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    @DisplayName("获取所有用户 - 集成测试")
    void getAllUsers_IntegrationTest() {
        // When
        ResponseEntity<Result<List<User>>> response = restTemplate
                .getForEntity("/api/system/user/list", 
                             new ParameterizedTypeReference<Result<List<User>>>() {});

        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getCode()).isEqualTo(200);
    }
}
```

## 6. 安全规范

### 6.1 认证授权规范
```java
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )
            .authorizeHttpRequests(authorize -> authorize
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers("/api/test/**").permitAll()
                .anyRequest().authenticated()
            )
            .oauth2ResourceServer(oauth2 -> oauth2
                .jwt(jwt -> jwt.jwtDecoder(jwtDecoder()))
            );
        
        return http.build();
    }
}
```

### 6.2 输入验证规范
```java
@PostMapping("/user")
public Result<User> createUser(@Valid @RequestBody UserDTO userDTO) {
    // DTO已包含验证注解
    return Result.success(userService.createUser(userDTO));
}

@Data
public class UserDTO {
    @NotBlank(message = "用户名不能为空")
    @Pattern(regexp = "^[a-zA-Z0-9_]{3,20}$", message = "用户名只能包含字母、数字和下划线，长度3-20位")
    private String username;

    @NotBlank(message = "邮箱不能为空")
    @Email(message = "邮箱格式不正确")
    private String email;
}
```

## 7. 日志规范

### 7.1 日志记录规范
```java
@Slf4j
@Service
public class UserService {
    
    public User getUserById(Long id) {
        log.info("开始查询用户，ID: {}", id);
        
        User user = userRepository.findById(id).orElse(null);
        
        if (user == null) {
            log.warn("用户不存在，ID: {}", id);
            return null;
        }
        
        log.debug("查询到用户信息: {}", user.getUsername());
        log.info("查询用户成功，ID: {}", id);
        
        return user;
    }
    
    @Transactional
    public User createUser(UserDTO userDTO) {
        try {
            log.info("开始创建用户，用户名: {}", userDTO.getUsername());
            
            User user = new User();
            BeanUtils.copyProperties(userDTO, user);
            User savedUser = userRepository.save(user);
            
            log.info("创建用户成功，ID: {}", savedUser.getId());
            return savedUser;
        } catch (Exception e) {
            log.error("创建用户失败，用户名: {}", userDTO.getUsername(), e);
            throw e;
        }
    }
}
```

## 8. 异常处理规范

### 8.1 自定义异常规范
```java
@Getter
public class BusinessException extends RuntimeException {
    private Integer code;

    public BusinessException(String message) {
        super(message);
        this.code = 500;
    }

    public BusinessException(Integer code, String message) {
        super(message);
        this.code = code;
    }
}
```

### 8.2 全局异常处理器规范
```java
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(BusinessException.class)
    public Result<Void> handleBusinessException(BusinessException e) {
        log.error("业务异常：{}", e.getMessage());
        return Result.error(e.getCode(), e.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<Void> handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        FieldError fieldError = e.getBindingResult().getFieldError();
        String message = fieldError != null ? fieldError.getDefaultMessage() : "参数验证失败";
        log.error("参数验证异常：{}", message);
        return Result.error(400, message);
    }

    @ExceptionHandler(Exception.class)
    public Result<Void> handleException(Exception e) {
        log.error("系统异常：", e);
        return Result.error(500, "系统异常，请联系管理员");
    }
}
```

## 9. 文档规范

### 9.1 API文档规范
使用Swagger注解进行API文档标注：

```java
@Tag(name = "用户管理", description = "用户管理相关接口")
@RestController
@RequestMapping("/system/user")
@RequiredArgsConstructor
public class UserController {

    @Operation(summary = "获取所有用户", description = "返回系统中所有用户的信息，需要管理员权限")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "获取成功"),
        @ApiResponse(responseCode = "401", description = "未授权"),
        @ApiResponse(responseCode = "403", description = "禁止访问")
    })
    @GetMapping("/list")
    public Result<List<User>> getAllUsers() {
        return Result.success(userService.getAllUsers());
    }
}
```

### 9.2 代码注释规范
- 类级别的注释：说明类的职责和用途
- 方法级别的注释：说明方法功能、参数、返回值和异常
- 复杂逻辑的行内注释：解释实现思路
- 不要过度注释：代码本身应该具有自解释性

## 10. 部署规范

### 10.1 构建配置
```xml
<build>
    <plugins>
        <plugin>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-maven-plugin</artifactId>
            <configuration>
                <excludes>
                    <exclude>
                        <groupId>org.projectlombok</groupId>
                        <artifactId>lombok</artifactId>
                    </exclude>
                </excludes>
            </configuration>
        </plugin>
        <!-- 代码质量检查 -->
        <plugin>
            <groupId>org.jacoco</groupId>
            <artifactId>jacoco-maven-plugin</artifactId>
            <version>0.8.7</version>
            <executions>
                <execution>
                    <goals>
                        <goal>prepare-agent</goal>
                    </goals>
                </execution>
                <execution>
                    <id>report</id>
                    <phase>test</phase>
                    <goals>
                        <goal>report</goal>
                    </goals>
                </execution>
            </executions>
        </plugin>
    </plugins>
</build>
```

### 10.2 Docker部署
```dockerfile
FROM openjdk:17-jdk-slim

WORKDIR /app

COPY target/*.jar app.jar

EXPOSE 8080

ENTRYPOINT ["java", "-jar", "/app/app.jar"]
```

以上规范确保了代码的一致性、可读性和可维护性，所有开发人员应严格遵守。